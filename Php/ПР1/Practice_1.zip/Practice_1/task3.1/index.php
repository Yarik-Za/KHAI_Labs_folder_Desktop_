<?php

$letter = 'Н';
    $letter = mb_strtolower($letter);

    switch ($letter) {
        case 'а':
        case 'е':
        case 'є':
        case 'и':
        case 'і':
        case 'ї':
        case 'о':
        case 'у':
        case 'ю':
        case 'я':
            echo "$letter — голосна літера.<br>";
            break;
        
        // Робота з приголосними буквами
        default:
            echo "$letter — приголосна літера.<br>";
            break;
    }
?>
