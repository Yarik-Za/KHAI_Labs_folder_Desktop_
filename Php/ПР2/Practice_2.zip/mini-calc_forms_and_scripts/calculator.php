<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Результат обчислення за допомогою калькулятора</title>
</head>
<body>
<?php
$err_msg ="<h2>Виникла помилка!</h2>";
date_default_timezone_set('Europe/Kiev'); // встановлюємо часовий пояс

// Перевіряємо наявність всіх необхідних даних
if (isset($_POST['number1'], $_POST['number2'], $_POST['operation'])) {
    $number1 = $_POST['number1'];
    $number2 = $_POST['number2'];
    $operation = $_POST['operation'];

    // Перевірка коректності введених чисел
    if (is_numeric($number1) && is_numeric($number2)) {
        $number1 = (float)$number1;
        $number2 = (float)$number2;
        $result = '';

        // Виконання обраної операції
        switch ($operation) {
            case 'addition':
                $result = $number1 + $number2;
                break;
            case 'subtraction':
                $result = $number1 - $number2;
                break;
            case 'multiplication':
                $result = $number1 * $number2;
                break;
            case 'division':
                if ($number2 != 0) {
                    $result = $number1 / $number2;
                } else {
                    $result = "Помилка: ділення на нуль.";
                }
                break;
                case 'exponentiation':
                    $result = pow($number1, $number2);
                    break;
                default:
                    $result = "Невідома операція.";
                
        }

        echo "<h2>Результат обчислення:</h2>";
        echo "<u>Результат: $result</u>";
    } else {
        echo $err_msg;
        echo "Помилка: введіть коректні числові значення.";
    }
} else {
    echo $err_msg;
    echo "Помилка: відсутні обов'язкові дані.";
}
?>

<footer>
    <hr>
        <p>Дата генерації: <?php echo date('H:i:s  d.m.Y'); ?></br>
        Виконавець: Зайченко Ярослав Ігорович, 632п</p>
    </footer>
    </body>
    </html>