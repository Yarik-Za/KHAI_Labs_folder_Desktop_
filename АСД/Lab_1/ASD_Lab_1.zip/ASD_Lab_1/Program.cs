﻿using System;
using System.Text;

namespace ASD_Lab_1
{
    internal class Program
    {
        static void PressEnter()
        {
            while (true)
            {
                Console.WriteLine("Для продовження натисніть Enter...");
                var key = Console.ReadKey(intercept: true);
                if (key.Key == ConsoleKey.Enter)
                {
                    Console.Clear();
                    break; // Выход из цикла, если нажата клавиша Enter
                }
                else Console.WriteLine("Була натиснута інша клавіша");
                Console.Clear();
            }
        }
        static void Main(string[] args)
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            Console.InputEncoding = System.Text.Encoding.GetEncoding(1251);
            Console.OutputEncoding = System.Text.Encoding.GetEncoding(1251);

            Queue list = new Queue();

            char choice;
            do
            {
                Console.WriteLine("Лінійний двонаправлений список символів");
                Console.WriteLine("\nМеню:");
                Console.WriteLine("1. Додати символ до списку");
                Console.WriteLine("2. Видалити перший символ зі списку");
                Console.WriteLine("3. Знайти найбільший символ у списку");
                Console.WriteLine("4. Переглянути перший символ у списку");
                Console.WriteLine("5. Перевірити, чи список порожній");
                Console.WriteLine("6. Вивести структуру на екран");
                Console.WriteLine("7. Підрахувати кількість елементів у списку");
                Console.WriteLine("0. Вийти");

                Console.Write("Введіть номер операції: ");
                choice = Console.ReadKey().KeyChar;
                Console.WriteLine();
                Console.Clear();
                try
                {
                    switch (choice)
                    {
                        case '1':
                            Console.Write("Введіть символ для додавання: ");
                            char itemToAdd = Console.ReadKey().KeyChar;
                            list.EnQueue(itemToAdd);
                            Console.WriteLine("\nСимвол " + itemToAdd + " додано до списку.");
                            PressEnter();
                            break;

                        case '2':
                            char removedItem = list.DeQueue();
                            Console.WriteLine("Видалено: " + removedItem);
                            PressEnter();
                            break;

                        case '3':
                            char maxItem = list.FindMax();
                            Console.WriteLine("Найбільший елемент: " + maxItem);
                            PressEnter();
                            break;

                        case '4':
                            char firstItem = list.Peek();
                            Console.WriteLine("Перший елемент: " + firstItem);
                            PressEnter();
                            break;

                        case '5':
                            bool isEmpty = list.IsEmpty();
                            Console.WriteLine("Список порожній: " + isEmpty);
                            PressEnter();
                            break;

                        case '6':
                            Console.Write("Список: ");
                            Console.WriteLine(list.ToString());
                            PressEnter();
                            break;

                        case '7':
                            int itemCount = list.Count();
                            Console.WriteLine("Кількість елементів у списку: " + itemCount);
                            PressEnter();
                            break;

                        case '0':
                            break;

                        default:
                            Console.WriteLine("Неправильний вибір. Спробуйте ще раз.");
                            break;
                    }
                }
                catch (InvalidOperationException ex)
                {
                    Console.WriteLine("Помилка: " + ex.Message);
                }

            } while (choice != '0');
        }

    }
}