package org.example;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        String line="0+123sdf-12312+0124012";
        int PlusMinusCount=0;
        int NextZeroCount=0;
        for (int i=0; i<line.length();i++){
            if(line.charAt(i)=='+'||line.charAt(i)=='-')
                PlusMinusCount++;
            if (i<line.length()-1&&line.charAt(i+1)=='0'){
                NextZeroCount++;
            }
        }
        System.out.println("+/- = "+PlusMinusCount);
        System.out.println("Next 0 = "+ NextZeroCount);
    }
}