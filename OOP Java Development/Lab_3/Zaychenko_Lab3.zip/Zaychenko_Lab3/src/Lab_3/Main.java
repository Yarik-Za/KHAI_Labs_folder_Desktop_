package Lab_3;

import Lab_3.EnumPrntState;
import Lab_3.PrintersTypesClasses.InkjetPrnt;
import Lab_3.PrintersTypesClasses.LEDPrnt;
import Lab_3.PrintersTypesClasses.LaserPrnt;
import Lab_3.PrintersTypesClasses.MatrixPrnt;

public class Main {
    public static void main(String[] args) {
        String testDoc = "AaBbCcDdEeFf 1234567890 !@#$%^&*()_+";
        try {
            MatrixPrnt matrixPrinter = new MatrixPrnt("Matrix Model 1", "A4", 5.5, 100.0, 30,
                    "Normal", "COM PORT", EnumPrntState.READY.getEnumState());

            System.out.println(matrixPrinter.getProperties());
            System.out.println(matrixPrinter.getState());

            System.out.println("Initial Ink Level: " + matrixPrinter.getInkLevel());
            System.out.println("Is Ink Low? " + matrixPrinter.isLowInk());

            System.out.println(matrixPrinter.print(testDoc)); // Друк документа
            System.out.println("After printing, Ink Level: " + matrixPrinter.getInkLevel());
            System.out.println("Is Ink Low? " + matrixPrinter.isLowInk());

            matrixPrinter.reloadInk(); // Перезавантаження чорнила
            System.out.println("After reloading ink, Ink Level: " + matrixPrinter.getInkLevel());
            System.out.println("Is Ink Low? " + matrixPrinter.isLowInk());

            matrixPrinter.disconnect(); // Відключення принтера
            System.out.println("After disconnecting, Printer State: " + matrixPrinter.getState());

            matrixPrinter.error(); // Стан помилки
            System.out.println("After error, Printer State: " + matrixPrinter.getState());

            matrixPrinter.connect(); // Підключення принтера
            System.out.println("After connecting, Printer State: " + matrixPrinter.getState());


            LEDPrnt ledPrinter = new LEDPrnt("LED Model 1", "A4", 4.0, 150.0, 50,
                    "High Quality", "Wi-Fi", EnumPrntState.READY.getEnumState());

            System.out.println(ledPrinter.getProperties());
            System.out.println(ledPrinter.getState());

            System.out.println("Initial Toner Level: " + ledPrinter.getInkLevel());
            System.out.println("Is Toner Low? " + ledPrinter.isLowInk());

            System.out.println(ledPrinter.print(testDoc)); // Друк документа
            ledPrinter.enableDuplexPrinting();
            System.out.println(ledPrinter.print(testDoc)); // Друк документа
            System.out.println("After printing, Toner Level: " + ledPrinter.getInkLevel());
            System.out.println("Is Toner Low? " + ledPrinter.isLowInk());

            ledPrinter.reloadInk(); // Перезавантаження тонера
            System.out.println("After reloading toner, Toner Level: " + ledPrinter.getInkLevel());
            System.out.println("Is Toner Low? " + ledPrinter.isLowInk());

            ledPrinter.disconnect(); // Відключення принтера
            System.out.println("After disconnecting, Printer State: " + ledPrinter.getState());

            ledPrinter.error(); // Стан помилки
            System.out.println("After error, Printer State: " + ledPrinter.getState());

            ledPrinter.connect(); // Підключення принтера
            System.out.println("After connecting, Printer State: " + ledPrinter.getState());


            LaserPrnt laserPrinter = new LaserPrnt("Laser Model 1", "A4", 6.0, 200.0, 40,
                    "High Quality", "USB", EnumPrntState.READY.getEnumState());

            System.out.println(laserPrinter.getProperties());
            System.out.println(laserPrinter.getState());

            System.out.println("Initial Ink Level: " + laserPrinter.getInkLevel());
            System.out.println("Is Ink Low? " + laserPrinter.isLowInk());

            System.out.println(laserPrinter.print(testDoc)); // Друк документа
            laserPrinter.enableDuplexPrinting();
            System.out.println(laserPrinter.print(testDoc)); // Друк документа

            System.out.println("After printing, Ink Level: " + laserPrinter.getInkLevel());
            System.out.println("Is Ink Low? " + laserPrinter.isLowInk());

            laserPrinter.reloadInk(); // Перезавантаження чорнила
            System.out.println("After reloading ink, Ink Level: " + laserPrinter.getInkLevel());
            System.out.println("Is Ink Low? " + laserPrinter.isLowInk());

            laserPrinter.disconnect(); // Відключення принтера
            System.out.println("After disconnecting, Printer State: " + laserPrinter.getState());

            laserPrinter.error(); // Стан помилки
            System.out.println("After error, Printer State: " + laserPrinter.getState());

            laserPrinter.connect(); // Підключення принтера
            System.out.println("After connecting, Printer State: " + laserPrinter.getState());


            InkjetPrnt inkjetPrinter = new InkjetPrnt("Inkjet Model 1", "A4", 4.0, 150.0, 20,
                    "Normal", "Wi-Fi", EnumPrntState.READY.getEnumState());

            System.out.println(inkjetPrinter.getProperties());
            System.out.println(inkjetPrinter.getState());

            System.out.println("Initial Ink Level: " + inkjetPrinter.getInkLevel());
            System.out.println("Is Ink Low? " + inkjetPrinter.isLowInk());

            System.out.println(inkjetPrinter.print(testDoc)); // Друк документа

            System.out.println("After printing, Ink Level: " + inkjetPrinter.getInkLevel());
            System.out.println("Is Ink Low? " + inkjetPrinter.isLowInk());

            inkjetPrinter.reloadInk(); // Перезавантаження чорнила
            System.out.println("After reloading ink, Ink Level: " + inkjetPrinter.getInkLevel());
            System.out.println("Is Ink Low? " + inkjetPrinter.isLowInk());

            inkjetPrinter.disconnect(); // Відключення принтера
            System.out.println("After disconnecting, Printer State: " + inkjetPrinter.getState());

            inkjetPrinter.error(); // Стан помилки
            System.out.println("After error, Printer State: " + inkjetPrinter.getState());

            inkjetPrinter.connect(); // Підключення принтера
            System.out.println("After connecting, Printer State: " + inkjetPrinter.getState());


        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}