package org.example;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        String line = "janasnda";
        if(line.length()<10){
            while (line.length()!=12){
                line+="o";
            }
        }
        else{
            line=line.substring(0,6);
        }
        System.out.println(line);
    }
}