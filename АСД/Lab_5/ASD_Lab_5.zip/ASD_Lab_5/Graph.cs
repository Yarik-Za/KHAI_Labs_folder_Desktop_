﻿namespace ASD_Lab5
{
    public class Vershyna
    {
        public int inf;

        public Vershyna(int value)
        {
            inf = value;
        }
    }

    // Клас, що представляє ребро графа
    public class Edge
    {
        public Vershyna Start;
        public Vershyna End;

        public Edge(Vershyna start, Vershyna end)
        {
            Start = start;
            End = end;
        }
    }

    // Клас, що представляє однозв'язний підсписок вершин графа
    public class Pid_sp_Vershyny
    {
        public Vershyna inf;
        public Pid_sp_Vershyny Next;

        public Pid_sp_Vershyny(Vershyna value)
        {
            inf = value;
            Next = null;
        }
    }

    // Клас, що представляє однозв'язний список ребер графа
    public class Edge_LinkedList
    {
        public Edge Data { get; set; }
        public Edge_LinkedList Next { get; set; }

        public Edge_LinkedList(Edge data)
        {
            Data = data;
            Next = null;
        }
    }

    // Клас, що представляє граф
    public class Graph
    {
        public Edge_LinkedList Edges { get; private set; }
        public Pid_sp_Vershyny Vertices { get; private set; }

        // Максимальна допустима кількість зв'язків
        private const int MaxEdges = 50;

        // лічильник кількість зв'язків
        public static int currentEdgeCount;

        // Додавання ребра до графа
        public void AddEdge(Edge edge)
        {
            // Проверка на превышение максимального количества связей
            if (currentEdgeCount >= MaxEdges)
                throw new Exception($"Кількість зв'язків в графі перевищило максимально допустиму кількість - ({MaxEdges}).");

            Edge_LinkedList newEdgeNode = new Edge_LinkedList(edge);
            newEdgeNode.Next = Edges;
            Edges = newEdgeNode;

            // Додавання вершини до циклічного підсписку
            Pid_sp_Vershyny newVertexNode = new Pid_sp_Vershyny(edge.Start);
            newVertexNode.Next = Vertices;
            Vertices = newVertexNode;

            currentEdgeCount++;
        }
    }
}
