package Classes;
import Classes.Puppy;

import javax.swing.*;

public class Testing {
    public static void StartTest(String puppyName){
        // Створення об'єкта класу Цуценя
        Puppy TestMYpuppy = new Puppy(puppyName);

        Actions(TestMYpuppy);
        Diff_Constructors();
    }

    private static void Actions(Puppy object)
    {
        // Виклик методів для демонстрації
        object.askName();
        object.makeSound();
        object.jump();
        object.run();
        object.bite();
    }

    public static void Diff_Constructors(){

        // Створення об'єкта собаки з використанням різних значень статі
        Puppy p1 = new Puppy("Бобік", 3, "brown", Gender.MALE);
        Puppy p2 = new Puppy("Ляля", 2);

        System.out.println(p1.getInfo());
        System.out.println(p2.getInfo());
    }

    public static void AllTest() {
        //перевірка імені
        try {
            System.out.println("Правильне ім'я конструктора");
            Puppy a = new Puppy("ПравильнийЦуцик");
            System.out.println(a.getInfo());
            System.out.println();
        } catch (IllegalArgumentException e) {
            System.out.println("Помилка: " + e.getMessage());
            System.out.println();
        }

        try {
            System.out.println("Мало літер ім'я конструктора");
            Puppy a = new Puppy("По");
            System.out.println(a.getInfo());
            System.out.println();
        } catch (IllegalArgumentException e) {
            System.out.println("Помилка: " + e.getMessage());
            System.out.println();
        }

        try {
            System.out.println("Багато літер ім'я конструктора - 24шт");
            Puppy a = new Puppy("ПоПоПоПоПоПоПоПоПоПоПоПо");
            System.out.println(a.getInfo());
            System.out.println();
        } catch (IllegalArgumentException e) {
            System.out.println("Помилка: " + e.getMessage());
            System.out.println();
        }

        try {
            System.out.println("Не літери ім'я конструктора");
            Puppy a = new Puppy("12_34");
            System.out.println(a.getInfo());
            System.out.println();
        } catch (IllegalArgumentException e) {
            System.out.println("Помилка: " + e.getMessage());
            System.out.println();
        }

        //перевірка віку
        try {
            System.out.println("Правильний вік");
            Puppy a = new Puppy("Мінік",2);
            System.out.println(a.getInfo());
            System.out.println();
        } catch (IllegalArgumentException e) {
            System.out.println("Помилка: " + e.getMessage());
            System.out.println();
        }
        try {
            System.out.println("Вік нуль");
            Puppy a = new Puppy("Мінік",0);
            System.out.println(a.getInfo());
            System.out.println();
        } catch (IllegalArgumentException e) {
            System.out.println("Помилка: " + e.getMessage());
            System.out.println();
        }
        try {
            System.out.println("Вік меньше нуля");
            Puppy a = new Puppy("Мінік",-2);
            System.out.println(a.getInfo());
            System.out.println();
        } catch (IllegalArgumentException e) {
            System.out.println("Помилка: " + e.getMessage());
            System.out.println();
        }

    }

}
