﻿using System.ComponentModel;

namespace Lab_1
{
    public enum TaskType
    {
        Comp,
        Oral,
        Write,
        Default
    };
}
