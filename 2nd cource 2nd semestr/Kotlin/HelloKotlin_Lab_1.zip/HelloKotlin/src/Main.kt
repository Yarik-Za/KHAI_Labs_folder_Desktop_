// Дозволить використовувати короткі імена для ВСІХ функцій із пакету kotlin.math
import kotlin.math.*

fun main() {

    val PT = PracticeTask()
    PT.Action()

    readLine()!!

    // println("Hello World!")
    val i: Int = 6
    val b1 = i.toByte()
    println(b1)

    val b2: Byte = 1 // ОК, літерали перевіряються статично
    println(b2)//⇒ 1

    val i4: Int = b2.toInt() // OK!
    println(i4)//⇒ 1

    val i5: String = b2.toString()
    println(i5)//⇒ 1

    val i6: Double = b2.toDouble()
    println(i6)//⇒ 1.0

    val oneMillion = 1_000_000
    val socialSecurityNumber = 999_99_9999L
    val hexBytes = 0xFF_EC_DE_5E
    val bytes = 0b11010010_01101001_10010100_10010010

    var fish1 = 1
    fish1 = 2
    val aquarium = 1
    //aquarium = 2 //⇒ помилка: val не можна змінювати

    var fish2: Int = 12
    var lakes: Double = 2.5

    val numberOfFish1 = 5
    val numberOfPlants1 = 12
    println("I have $numberOfFish1 fish" + " and $numberOfPlants1 plants") //  I have 5 fish and 12 plants

    println("I have ${numberOfFish1 + numberOfPlants1} fish and plants together")

    println("В этой строке 25 символов".length)

    val numberOfFish2 = 50
    val numberOfPlants2 = 23
    if (numberOfFish2 > numberOfPlants2) {
        println("Хороше співвідношення!")
    } else {
        println("Погане співвідношення")
    }

    // diapazon in conditions

    val fish = 50
    if (fish in 1..100) {
        println(fish)
    } //⇒ 50

    if (numberOfFish2 == 0) {
        println("Пустий резервуар")
    } else if (numberOfFish2 < 40) {
        println("Є риба!")
    } else {
        println("Багато риби!")
    } //⇒ Багато риби!

    when (numberOfFish2) {
        0  -> println("Пустий резервуар")
        in 1..39 -> println("Є риба!")
        else -> println("Багато риби!")
    }//    ⇒ Багато риби!

// elsvis

    print("Введіть ім’я: ")
    val name1 = readLine()
    println("Ваше ім’я: $name1")

    val name:String
    print("Введіть ім’я: ")
    val inputName = readLine()
    //name = inputName // Type mismatch: inferred type is String? but String was expected
    name = inputName.toString()
    println("Ваше ім’я: $name")

    print("Введіть ім’я: ")
    val name3:String = readLine().toString()
    println("Ваше ім’я: $name3")

    print("Enter a number ")
    var variableName1:Int = readLine()!!.toInt()  // readLine() is used to accept the String value and ".toInt()" will convert the string to  Int.
    println("The output is: $variableName1")

    print("Enter a number ")
    var variableName2 = readLine()!!.toDouble()
    println("The output is: $variableName2")


    for(n in 1..9){
        print("${n * n} \t")
    }

    println()

    for(i in 1..9){
        for(j in 1..9){
            print("${i * j} \t")
        }
        println()
    }

    var ii = 10
    while(ii > 0){
        println(ii*ii)
        ii--;
    }

    var iii = -1
    do{
        println(iii*iii)
        iii--;
    }
    while(iii > 0)


    for(n in 1..8){
        if(n == 5) continue;
        println(n * n)
    }


    for(n in 1..5){
        if(n == 5) break;
        println(n * n)
    }


    val rnds = (0..10).random()
    println("Випадкове число від 0 до 9 включно: "+rnds)


    val x = (0..10).random()
    val y = Math.sqrt(x.toDouble());
    println("у = " + String.format("%.3f", y));  //  Виводить корінь числа з трьома знаками після коми

}