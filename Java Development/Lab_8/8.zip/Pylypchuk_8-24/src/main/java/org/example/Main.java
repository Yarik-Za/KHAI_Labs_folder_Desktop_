package org.example;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        int[] numbers;
        String line="123 423 asd 123 4asd 12da";
        String[] words=line.split(" ");
        numbers=new int[words.length];
        int j=0;
        for(String word: words){
            for(int i=0; i<word.length(); i++){
                if(Character.isDigit(word.charAt(i))){
                    if(i+1==word.length())
                    {
                        numbers[j]=Integer.parseInt(word);
                        j++;
                    }
                }
                else
                    break;
            }
        }
        int sum=0;
        for(int number:numbers)
            sum+=number;
        System.out.println(sum);
    }
}