﻿using System.Text;
namespace ASD_Lab_3
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            Console.InputEncoding = System.Text.Encoding.GetEncoding(1251);
            Console.OutputEncoding = System.Text.Encoding.GetEncoding(1251);

            Up_ArLst MyUP = new Up_ArLst();
            int count_SP_UP = 0;
            int rm = 0;
            Console.WriteLine($"Список ArrayList та підсписок Stack <T>");
            do
            {
                try
                {
                    int choise = Menu();
                    switch (choise)
                    {
                        case 1:
                            {
                                rm = Rand_or_manual_inp();
                                MyUP.Add_Down_to_ArLst(Input_El(ref count_SP_UP, rm)); // введення елементів в нижній стек & добавляем на верхний уровень элемент
                                break;
                            }
                        case 2:
                            {
                                int del_el_up = Input_num("Введіть номер верхнього списку для видалення елементу ->", 1, MyUP.UP_ArLst.Count);
                                MyUP.Remove_Down_El(del_el_up - 1); // удаление элемента стека из подсписка по номеру списка
                                break;
                            }
                        case 3:
                            {
                                int peek_N_SP = Input_num("Введіть номер верхнього списку для проглядання елементу ->", 1, MyUP.UP_ArLst.Count);
                                Down down = MyUP.UP_ArLst[peek_N_SP - 1] as Down;
                                if (down != null)
                                {
                                    El_Down topElement = down.Peek();
                                    Console.WriteLine("Верхній елемент: " + topElement.ToString());
                                }
                                else Console.WriteLine("Об'єкт вказаного верхнього списку не є екземпляром класу Down.");
                                break;
                            }
                        case 4:
                            {
                                int quantity_N_SP = Input_num("Введіть номер верхнього списку для кількості елементів підсписку ->", 1, MyUP.UP_ArLst.Count);
                                Down down = MyUP.UP_ArLst[quantity_N_SP - 1] as Down; // Оскільки список MyUP.UP_ArLst індексується з 0, а користувач вводить з 1
                                if (down != null)
                                {
                                    int count = down.Count();
                                    Console.WriteLine("Кількість елементів в підсписку: " + count);
                                }
                                else Console.WriteLine("Об'єкт вказаного верхнього списку не є екземпляром класу Down.");
                                break;
                            }
                        case 5:
                            {
                                int delete_N_SP = Input_num("Введіть номер верхнього списку для кількості елементів підсписку ->", 1, MyUP.UP_ArLst.Count);
                                Down down = MyUP.UP_ArLst[delete_N_SP - 1] as Down; // Оскільки список MyUP.UP_ArLst індексується з 0, а користувач вводить з 1
                                if (down != null)
                                {
                                    down.Clear();
                                    Console.WriteLine("Підсписок очищено.");
                                }
                                else Console.WriteLine("Об'єкт вказаного верхнього списку не є екземпляром класу Down.");
                                break;
                            }
                        case 6:
                            {
                                Console.WriteLine();
                                // виводимо список на екарн
                                Console.WriteLine(MyUP.ToString());
                                break;
                            }
                        case 7:
                            {
                                MyUP.Reverse_UP();
                                break;
                            }
                        case 8:
                            {
                                foreach (var El in MyUP.UP_ArLst)
                                {
                                    int index = MyUP.UP_ArLst.IndexOf(El);
                                    Console.WriteLine($"Індекс {index}: {El}");
                                }

                                int del_sp = Input_num("Введіть індекс для видалення списку -->", 0, MyUP.UP_ArLst.Count);

                                MyUP.Remove_UP(del_sp);
                                break;
                            }
                        case 0:
                            { Environment.Exit(0); break; }
                    }
                }
                catch (Exception ex) { Console.WriteLine(ex.Message); }
            } while (count_SP_UP < 5);
        }

        public static Down Input_El(ref int count_SP, int mode)
        {
            Console.Write("Введіть кількість елементів для додавання в підсписок: "); //додавання кількості елементів до підсписку
            int push_el_qu = int.Parse(Console.ReadLine());

            Down MyDown = new Down(++count_SP);
            Console.WriteLine();
            for (int i = 0; i < push_el_qu; i++)
            {
                int k = 0;
                if (mode == 1)
                {
                    Random r = new Random();
                    k = r.Next(20);
                }
                else if (mode == 2)
                    k = Input_num("Введіть числа для додавання в підсписок: ", Int32.MinValue, Int32.MaxValue);

                Console.WriteLine("Додано елемент ->" + k.ToString());
                El_Down MyElDown = new El_Down(k, "SP" + count_SP.ToString() + "PSp" + k.ToString());
                MyDown.Add_El_to_Down(MyElDown);
            }
            return MyDown;
        }

        public static int Input_num(string text, int down, int up)
        {
            int input;
            Console.Write(text);
            while (true)
            {
                if (int.TryParse(Console.ReadLine(), out input) && input <= up && input >= down)
                {
                    return input;
                }
                else Console.WriteLine("Помилка введення числа. Спробуйте ще раз");
            }
        }

        public static int Menu()
        {
            Console.WriteLine($"\n---------------[Робота з підсписками]-----------------\n" +
                              $"1 - Додати елементи до підсписку (випадково чи вручну)\n" +
                              $"2 - Видалення елементу в підсписку\n" +
                              $"3 - Глянути елемент підсписку\n" +
                              $"4 - Порахувати кількість елементів в підсписку\n" +
                              $"5 - Видалення Підсписку повністю\n" +
                              $"-----------------[Робота зі списками]-------------------\n" +
                              $"6 - Виведення Структури на екран\n" +
                              $"7 - Перевернути порядок в Списку\n" +
                              $"8 - Видалення Списку повністю\n" +
                              $"0 - Вихід\n");
            return Input_num("Введіть ваш вибір: ", 0, 9);
        }

        public static int Rand_or_manual_inp()
        {
            int inp = 0;
            Console.WriteLine($"Як бажаєте ввести дані?\n" +
                $"1 - випадковим чином\n" +
                $"2 - ввести з клавіатури\n" +
                $"0 - повернутись до головного меню\n");

            switch (Input_num("Введіть ваш вибір: ", 0, 3))
            {
                case 0: { break; }
                case 1: { inp = 1; break; }
                case 2: { inp = 2; break; }

            }
            return inp;
        }
    }
}