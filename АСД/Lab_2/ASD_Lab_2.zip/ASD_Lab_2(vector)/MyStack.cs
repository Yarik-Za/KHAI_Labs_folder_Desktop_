﻿using System;
namespace ASD_Lab_2_vector_
{
    public struct Elem
    {
        public char _inf;
        public Elem(char inf)
        {
            this._inf = inf;
        }
    }

    public class MyStack
    {
        private int _Top;
        private Elem[] _V;

        public MyStack(int count)
        {
            _Top = -1;
            _V = new Elem[count];
        }

        public bool Push(Elem el)
        {
            if (_Top == _V.Length - 1)
            {
                return false; // Стек переполнен
            }

            _Top++;
            _V[_Top] = el;
            return true;
        }

        public bool Pop()
        {
            if (_Top == -1)
            {
                return false; // Стек пуст
            }

            _Top--;
            return true;
        }

        public override string ToString()
        {
            string Res = "";
            for (int i = 0; i <= _Top; i++)
            {
                Res += _V[i]._inf + "\t";
            }
            return Res;
        }

        public string Print()
        {
            if (_Top == -1)
            {
                return "Стек пустий";
            }

            string Res = "";
            int index = 0;
            for (int i = index; i <= _Top; i++)
            {
                Res += $"({i}) {_V[i]._inf} ";
            }
            Res += $"({index})"; // Последний элемент указывает на первый

            return Res;
        }
        public string Print1()
        {
            if (_Top == -1)
            {
                return "Стек пустий";
            }

            string Res = "";
            for (int i = _Top; i >= 0; i--)
            {
                Res += $"({_V[i]._inf}) {_V[i]._inf} ";
            }

            return Res;
        }


        public Elem Peek()
        {
            if (_Top == -1)
            {
                throw new InvalidOperationException("Стек пуст. Невозможно выполнить Peek.");
            }

            return _V[_Top];
        }

        public bool IsEmpty()
        {
            return _Top == -1;
        }

        public int CountEl()
        {
            return _Top + 1;
        }
        public Tuple<MyStack, MyStack> SplitStack()
        {
            if (IsEmpty())
            {
                // Стек пуст, возвращаем два пустых стека
                return new Tuple<MyStack, MyStack>(new MyStack(0), new MyStack(0));
            }

            int count = CountEl();
            int halfCount = count / 2;

            MyStack firstHalf = new MyStack(halfCount);
            MyStack secondHalf = new MyStack(count - halfCount);

            // Перемещаем элементы из исходного стека в первую половину
            for (int i = 0; i < halfCount; i++)
            {
                Elem element = _V[_Top]; // Извлекаем элемент из вершины стека
                firstHalf.Push(element); // Добавляем элемент в первую половину
                _Top--; // Уменьшаем указатель вершины
            }

            // Перемещаем оставшиеся элементы из первой половины во вторую половину
            while (!IsEmpty())
            {
                Elem element = _V[_Top]; // Извлекаем элемент из вершины стека
                secondHalf.Push(element); // Добавляем элемент во вторую половину
                _Top--; // Уменьшаем указатель вершины
            }

            return new Tuple<MyStack, MyStack>(firstHalf, secondHalf);
        }
    }
}