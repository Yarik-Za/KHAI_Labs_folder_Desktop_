﻿namespace _UI_UX__Lab_1
{
    partial class Main_Form
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Show = new Button();
            about_button = new Button();
            exit_button = new Button();
            SuspendLayout();
            // 
            // Show
            // 
            Show.Location = new Point(46, 12);
            Show.Name = "Show";
            Show.Size = new Size(151, 44);
            Show.TabIndex = 0;
            Show.Text = "Показати заставку";
            Show.UseVisualStyleBackColor = true;
            Show.Click += Show_Click;
            // 
            // about_button
            // 
            about_button.Location = new Point(46, 75);
            about_button.Name = "about_button";
            about_button.Size = new Size(151, 44);
            about_button.TabIndex = 1;
            about_button.Text = "Про програму";
            about_button.UseVisualStyleBackColor = true;
            about_button.Click += about_button_Click;
            // 
            // exit_button
            // 
            exit_button.Location = new Point(46, 135);
            exit_button.Name = "exit_button";
            exit_button.Size = new Size(151, 44);
            exit_button.TabIndex = 2;
            exit_button.Text = "Вихід";
            exit_button.UseVisualStyleBackColor = true;
            exit_button.Click += exit_button_Click;
            // 
            // Main_Form
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(251, 191);
            ControlBox = false;
            Controls.Add(exit_button);
            Controls.Add(about_button);
            Controls.Add(Show);
            Name = "Main_Form";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Заставка";
            ResumeLayout(false);
        }

        #endregion

        private Button Show;
        private Button about_button;
        private Button exit_button;
    }
}