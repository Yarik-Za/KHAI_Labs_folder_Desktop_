package Lab_3.PrintersTypesClasses;

// Інтерфейс для підтримки дуплексного друку
public interface DuplexPrinting {
    void enableDuplexPrinting(); // Метод для увімкнення дуплексного друку

     String DPrnt(String doc); // метод зворотнього друку

}




