package com.example.simplealarmclock

import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class AlarmActivity : AppCompatActivity() {
    private var ringtone: Ringtone? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alarm)
        val notificationUri: Uri? = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        ringtone = RingtoneManager.getRingtone(this, notificationUri)
        if (ringtone == null) {
            val ringtoneUri: Uri? = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            ringtone = RingtoneManager.getRingtone(this, ringtoneUri)
        }
        // Запуск звукового сигнала
        ringtone?.play()
        // Показ диалогового окна после начала воспроизведения звука
        showAlertDialog()
    }

    override fun onDestroy() {
        if (ringtone?.isPlaying == true) {
            ringtone?.stop()
        }
        super.onDestroy()
    }

    private fun showAlertDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Прокидайся!!!")
        builder.setMessage("Вже час вставати.\nЩо зробити?")
        builder.setPositiveButton("ОК") { dialog, _ ->
            dialog.dismiss()
            ringtone?.stop() // Остановить звук
            sendResult(Alarm.AlarmStatus.DISABLED)
            finish() // Закрыть активность
        }
        builder.setNegativeButton("Відкласти на 10 хвилин") { dialog, _ ->
            snoozeAlarm() // Отложить будильник на 10 минут
            dialog.dismiss()
            ringtone?.stop() // Остановить звук
            sendResult(Alarm.AlarmStatus.SNOOZED)
            finish() // Закрыть активность
        }
        builder.setCancelable(false)
        val dialog = builder.create()
        dialog.show()
    }

    private fun sendResult(status: Alarm.AlarmStatus) {
        val resultIntent = Intent().apply {
            putExtra("status", status)
        }
        setResult(Activity.RESULT_OK, resultIntent)
    }


    private fun snoozeAlarm() {
        val calendar = Calendar.getInstance().apply { add(Calendar.MINUTE, 10) }// Увеличиваем время на 10 минут
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val alarmIntent = Intent(this, AlarmActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(this, 0, alarmIntent, PendingIntent.FLAG_UPDATE_CURRENT)
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pendingIntent)
        Toast.makeText(this, "Будильник відкладено на 10 хвилин", Toast.LENGTH_SHORT).show()
    }
}


