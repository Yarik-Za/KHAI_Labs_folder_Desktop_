﻿namespace ASD_RR1
{
    public class SortTimeTest
    {
        public static void RunSortingTests()
        {
            int[] inputCounts = { 10000, 50000, 100000 }; // Різні розміри масивів для тестів

            foreach (var count in inputCounts)
            {
                // Генеруємо масиви для різних сценаріїв
                KeyValue[] randomArray = GenerateRandomArray(count);
                KeyValue[] orderedArray = GenerateOrderKeyValueArray(count);
                KeyValue[] reversedArray = GenerateReversedKeyValueArray(count);

                // Тестуємо сортування для різних сценаріївз
                TestSorting(randomArray, "Випадковий");
                TestSorting(orderedArray, "Відсортований");
                TestSorting(reversedArray, "Зворотній");
            }
        }

        private static void TestSorting(KeyValue[] array, string arrayType)
        {
            // Засікаємо час сортування
            System.Diagnostics.Stopwatch watch = new System.Diagnostics.Stopwatch();
            watch.Start();

            // Викликаємо ваш метод сортування
            InsideMSort(array);

            watch.Stop();

            // Виводимо результат
            Console.WriteLine($"Сортування {arrayType,-15}\t масиву з {array.Length, -10}\t елементами виконанно за:\t{watch.ElapsedTicks} одиниць");
        }

        static KeyValue[] GenerateRandomArray(int length)
        {
            Random random = new Random();
            KeyValue[] array = new KeyValue[length];

            for (int i = 0; i < length; i++)
            {
                array[i] = new KeyValue
                {
                    Key = random.Next(-1000, 1000), // Генеруємо випадкові числа в діапазоні (-1000, 1000)
                    Value = (char)random.Next(32, 127) // Генеруємо випадковий символ з ASCII-таблиці
                };
            }
            return array;
        }

        public static KeyValue[] GenerateOrderKeyValueArray(int input_count)
        {
            Random random = new Random();
            KeyValue[] array = new KeyValue[input_count];

            for (int i = 0; i < input_count; i++)
            {
                array[i] = new KeyValue
                {
                    Key = i,
                    Value = (char)random.Next(32, 127)
                };
            }
            return array;
        }

        public static KeyValue[] GenerateReversedKeyValueArray(int input_count)
        {
            Random random = new Random();
            KeyValue[] array = new KeyValue[input_count];

            for (int i = input_count - 1; i >= 0; i--)
            {
                array[i] = new KeyValue
                {
                    Key = i + 1,
                    Value = (char)random.Next(32, 127)
                };
            }
            return array;
        }

        public static void InsideMSort(KeyValue[] array)
        {
            int iteration = 1;

            int N = array.Length;
            int t = (int)Math.Ceiling(Math.Log2(N));
            int p = (int)Math.Pow(2, t - 1); // початкова установка p   M1

            do
            {
                int q = (int)Math.Pow(2, t - 1); // початкова установка q, r, d   M2
                int r = 0;
                int d = p;

                do
                {
                    for (int i = 0; i <= N - d - 1; i++) // цикл по i   M3
                    {

                        if (i + d < N && i < N - d && array[i].Key > array[i + d].Key && ((i & p) == r)) // порівняння\обмін елементів масиву   M4
                        {
                            KeyValue temp_swap = array[i];
                            array[i] = array[i + d];
                            array[i + d] = temp_swap;

                        }
                    }

                    if (q != p)
                    {
                        d = q - p;
                        q /= 2;
                        r = p;
                    }
                    else
                    {
                        break; // вихід з циклу, якщо q=p
                    }
                } while (q > 0);// цикл по q   M5

                p /= 2;
                iteration++;
            } while (p > 0);// цикл по p   M6
        }
    }
}
