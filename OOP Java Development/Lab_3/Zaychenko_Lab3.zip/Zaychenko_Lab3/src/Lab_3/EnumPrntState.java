package Lab_3;

public enum EnumPrntState {
    READY("Connected; Ready"),        // Готовий
    PRINTING("Printing"),  // Друк
    ERROR("Stopped; Error"),        // Помилка
    OFFLINE("Disconnected; Offline");    // Відключений

    // Змінна для зберігання назви стану
    private final String state;

    // Конструктор
    EnumPrntState(String state) {
        this.state = state;
    }

    // Метод для отримання назви стану
    public String getEnumState() {
        return state;
    }
}
