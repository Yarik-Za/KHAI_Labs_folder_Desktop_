package org.example;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        String line="apspfacxcoaskfmoasmoi";
        char First = 0;
        String Message="";
        if(!line.contains("x")&&!line.contains("w")) {
            Message="No x and w";
        } else if(!line.contains("x")){
            Message="No x";
        } else if (!line.contains("w")) {
            Message="No w";
        }
        for(int i=0; i<line.length(); i++) {
            if (line.charAt(i) == 'x' || line.charAt(i) == 'w') {
                First = line.charAt(i);
                break;
            }
        }
        System.out.println(First);
        System.out.println(Message);
    }
}