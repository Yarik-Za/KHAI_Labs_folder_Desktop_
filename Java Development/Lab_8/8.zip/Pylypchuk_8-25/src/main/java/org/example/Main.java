package org.example;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        String line="   daskldl      kaslkdak   ";
        int count=0; int maxcount=0;
        for(int i=0; i<line.length(); i++){
            if(line.charAt(i)==' '){
                count++;
            }
            else{
                if(count>maxcount){
                    maxcount=count;
                }
                count=0;
            }
        }
        if(count>maxcount){
            maxcount=count;
        }
        System.out.println(maxcount);
    }
}