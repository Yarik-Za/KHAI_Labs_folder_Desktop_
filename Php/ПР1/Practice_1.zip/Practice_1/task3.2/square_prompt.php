<?php
// PHP функція для генерації HTML та базової структури сторінки
function generateSquares() {
    echo "<!DOCTYPE html>";
    echo "<html lang='en'>";
    echo "<head>";
    echo "<meta charset='UTF-8'>";
    echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
    echo "<style>";
    echo "body { background-color: black; margin: 0; padding: 0; overflow: hidden; }";
    echo ".square { position: absolute; background-color: red; }";
    echo "</style>";
    echo "<title>Random Squares</title>";
    echo "</head>";
    echo "<body>";

    echo "</body>";
    echo "</html>";
}

// Викликаємо функцію, щоб створити HTML-сторінку
generateSquares();
?>

<script>
// Функція для запиту кількості квадратів
function input_num() {
    // Запитуємо у користувача кількість квадратів
    let n = prompt("Введіть кількість квадратів:", "10");

    // Перетворюємо введене значення на ціле число
    n = parseInt(n);

    // Перевіряємо, чи введене число є коректним
    if (isNaN(n) || n <= 0) {
        alert("Будь ласка, введіть коректне число.");
        return null; // Повертаємо null у разі некоректного введення
    } else {
        return n; // Повертаємо число, якщо введення коректне
    }
}

// Функція для створення квадратів
function generateSquares(n) {
    for (let i = 0; i < n; i++) {
        const square = document.createElement('div');
        const size = Math.floor(Math.random() * 100) + 20; // випадковий розмір від 20 до 120 пікселів
        const x = Math.floor(Math.random() * window.innerWidth); // випадкова позиція по осі X
        const y = Math.floor(Math.random() * window.innerHeight); // випадкова позиція по осі Y
        square.style.width = size + 'px';
        square.style.height = size + 'px';
        square.style.left = x + 'px';
        square.style.top = y + 'px';
        square.classList.add('square');
        document.body.appendChild(square);
    }
}

// Виклик функції для запиту кількості квадратів та створення квадратів
let numOfSquares = input_num();
if (numOfSquares !== null) {
    generateSquares(numOfSquares);
}
</script>
