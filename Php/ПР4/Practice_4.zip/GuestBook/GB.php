<?php
session_start();

// Устанавливаем блокировку на 10 секунд для отладки
$lockDuration = 10; // время блокировки в секундах

function renderLockedPage($remainingTime) {
    echo "
    <!DOCTYPE html>
    <html lang='uk'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Форма заблокована</title>
    </head>
    <body>
        <h1>Гостьова книга</h1>
        <p>Форма заблокована через перевищення ліміту спроб.</p>
        <p>Час до розблокування: <span id='timer' data-remaining-time='$remainingTime'></span>.</p>
        <footer><p>Виконав: Зайченко Ярослав Ігорович</п></footer>
        <script>
            let remainingTime = $remainingTime;
            function updateTimer() {
                if (remainingTime <= 0) {
                    document.getElementById('timer').textContent = 'Форма розблокована';
                    setTimeout(function() { window.location.href = 'GB.php?action=unblock'; }, 5000);
                    return;
                }
                const minutes = Math.floor(remainingTime / 60);
                const seconds = remainingTime % 60;
                document.getElementById('timer').textContent = minutes + ' хвилин ' + seconds + ' секунд';
                remainingTime--;
            }
            if (remainingTime > 0) {
                updateTimer();
                setInterval(updateTimer, 1000);
            }
        </script>
    </body>
    </html>";
}

// Сброс блокировки
if (isset($_GET['action']) && $_GET['action'] === 'unblock') {
    unset($_SESSION['attempts']);
    setcookie('form_blocked', '', time() - 3600, '/');
    setcookie('form_blocked_time', '', time() - 3600, '/');
    header('Location: GuestBook_mainform.html');
    exit;
}

if (isset($_COOKIE['form_blocked'])) {
    $blockedTime = $_COOKIE['form_blocked_time'];
    $remainingTime = $blockedTime - time();

    if ($remainingTime <= 0) {
        setcookie('form_blocked', '', time() - 3600, '/');
        setcookie('form_blocked_time', '', time() - 3600, '/');
        echo "<h1>Гостьова книга</h1>";
        echo "<p>Форма розблокована. Ви можете відправити повідомлення.</p>";
        echo "<script>setTimeout(function() { window.location.href = 'GB.php?action=unblock'; }, 5000);</script>";
        echo "<footer><p>Виконав: Зайченко Ярослав Ігорович</п></footer>";
        exit;
    } else {
        renderLockedPage($remainingTime);
        exit;
    }
}

if (!isset($_SESSION['attempts'])) {
    $_SESSION['attempts'] = 0;
}

// Обработка формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $message = $_POST['message'] ?? '';

    // Удаляем HTML-теги из сообщения
    $cleanedMessage = strip_tags($message);

    // Проверяем email на корректность
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['attempts']++;

        if ($_SESSION['attempts'] >= 3) {
            setcookie('form_blocked', '1', time() + $lockDuration, '/');
            setcookie('form_blocked_time', time() + $lockDuration, time() + $lockDuration, '/');
            renderLockedPage($lockDuration);
        } else {
            echo "<h1>Гостьова книга</h1>";
            echo "<p>Некоректна електронна адреса. Спроба {$_SESSION['attempts']} з 3.</п>";
        }
        exit;
    }

    // Успешная валидация
    $_SESSION['attempts'] = 0; // Сбрасываем счетчик

    // Сохраняем запись в файл
    $record = "$email|" . str_replace("|", "/", $cleanedMessage) . "|" . date('Y-m-d H:i:s') . "\n";
    if (file_put_contents('guests.txt', $record, FILE_APPEND) === false) {
        echo "<h1>Гостьова книга</h1>";
        echo "<p>Помилка: не вдалося записати дані у файл.</p>";
    } else {
        echo "<h1>Гостьова книга</h1>";
        echo "<p>Повідомлення успішно відправлено!</p>";
        echo "<footer><p>Виконав: Зайченко Ярослав Ігорович</p></footer>";
    }
}
?>
