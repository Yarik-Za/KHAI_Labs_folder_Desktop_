package Lab_2.Classes.Storages;

public class VehiclesStorage extends AbstractStorage {
    public VehiclesStorage() {
        super();
    }

    // Перевизначення методу displayInformation
    @Override
    public String getFullInformation() {
        // Виводимо інформацію про всі транспортні засоби, які містяться у списку
        StringBuilder info = new StringBuilder();

        for (Object temp_vehicle : super.list){
            info.append(temp_vehicle.toString()).append('\n');
        }
        return info.toString();
    }
}
