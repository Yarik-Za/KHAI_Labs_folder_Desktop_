package org.example;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        String line="abcdefghijk";
        if(line.substring(0,3).equals("abc")){
            line=line.replace("abc", "www");
        }
        else {
            line=line.replace(line.substring(line.length()-4),"zzz");
        }
        System.out.println(line);
    }
}