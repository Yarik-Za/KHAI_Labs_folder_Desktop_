import PracticeTask;
fun main() {
    println("Hello World!")
    val PT = PracticeTask()
    PT.Action()
}