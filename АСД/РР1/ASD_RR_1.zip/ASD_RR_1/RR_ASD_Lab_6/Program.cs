﻿using ASD_RR1;
using System.Text;

Console.OutputEncoding = Encoding.UTF8;
Console.InputEncoding = Encoding.UTF8;

Console.WriteLine("Для виходу введіть \"0\"\n");

while (true)
{
    try
    {
        int length = 0;

        UI.Menu();

        switch (UI.Input_range("Введіть ваш вибір: ", 2, 0))
        {
            case 0: Environment.Exit(0); break;
            case 1:
                Console.Write("Введіть кількість елементів масиву: ");
                string input = Console.ReadLine();

                if (input == "-0") Environment.Exit(0);

                if (int.TryParse(input, out int temp) && temp >= 2)
                {
                    length = temp;
                    KeyValue[] array = GenerateRandomArray(length);

                    // Виведення початкового масиву
                    PrintArr("Початковий масив: ", array);

                    // Сортування масиву
                    SortAlgorithm.MSort(array);

                    // Виведення відсортованого масиву
                    PrintArr("Відсортований масив: ", array);
                }
                else
                {
                    Console.WriteLine("Помилка введення кількості елементів масиву");
                }

                Console.ReadLine();

                break;
          
            case 2:
                SortTimeTest.RunSortingTests();
                UI.PressEnter();
                break;
        }


    }
    catch (Exception ex) { Console.WriteLine(ex.Message); }
}
static int BigNumInp()
{
    Console.WriteLine("Введіть кількість елементів більше 10 000");
    while (true)
    {
        if (int.TryParse(Console.ReadLine(), out int temp_inp))
        {
            if (temp_inp >= 10000)
                return temp_inp;
            else { Console.Clear(); Console.WriteLine("Помилка, введіть ще раз"); }
        }
    }
}

static KeyValue[] GenerateRandomArray(int length)
{
    Random random = new Random();
    KeyValue[] array = new KeyValue[length];

    for (int i = 0; i < length; i++)
    {
        array[i] = new KeyValue
        {
            Key = random.Next(-1000, 1000), // Генеруємо випадкові числа в діапазоні (-1000, 1000)
            Value = (char)random.Next(32, 127) // Генеруємо випадковий символ з ASCII-таблиці
        };
    }

    return array;
}
static void PrintArr(string message, KeyValue[] array)
{
    Console.WriteLine(message);
    foreach (var item in array)
    {
        Console.WriteLine($"Key: {item.Key}, Value: {item.Value}");
    }
}
void TimeTests(int choise)
{
    switch (choise)
    {
        case 1: break;

        case 2: break;

        case 3: break;

    }
}

