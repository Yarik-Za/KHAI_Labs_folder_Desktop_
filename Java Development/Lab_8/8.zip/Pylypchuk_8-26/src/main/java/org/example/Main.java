package org.example;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        String[] array={"asf12dla","af321dxa","alsm3111falla","alsmfalladas"};
        int[] subarray={Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MAX_VALUE,Integer.MAX_VALUE};
        for (int j=0; j<array.length;j++) {
            int count=0;
            for(int i=0; i<array[j].length();i++){
                if(Character.isDigit(array[j].charAt(i)))
                    count++;
            }
            subarray[j]=count;
        }
        for (int i=array.length-1; i>-1;i--) {
            if((i-1>-1)&&subarray[i]<subarray[i-1]){
                String temp=array[i];
                array[i]=array[i-1];
                array[i-1]=temp;
                int subtemp=subarray[i];
                subarray[i]=subarray[i-1];
                subarray[i-1]=subtemp;
            }
        }
        for(String line:array)
            System.out.println(line);
    }
}