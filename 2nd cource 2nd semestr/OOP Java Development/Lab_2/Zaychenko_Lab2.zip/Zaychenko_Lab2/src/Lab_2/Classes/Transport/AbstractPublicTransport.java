package Lab_2.Classes.Transport;

import java.util.Arrays;

public abstract class AbstractPublicTransport {
    // Властивості
    protected EnumTransportType type;
    protected String modelType; // модель
    protected String manufacturer; // иробник
    protected String number; // номер маршруту
    protected String[] route = new String[2]; // маршрут
    protected int capacity; // місткість
    protected Driver driver; // закріплений водій
    protected String stopped; // зупинка

    // Конструктор
    public AbstractPublicTransport(EnumTransportType tt, String modelType, String manufacturer, String number, String route_start, String route_end, int capacity) {
        this.type = tt;
        setModelType(modelType);
        setManufacturer(manufacturer);
        setNumber(number);
        setRoute(route_start, route_end);
        setCapacity(capacity);
        this.stopped = route_end;
    }

    // Методи доступу до властивостей
    public String getModelType() {
        return modelType;
    }

    public void setModelType(String modelType) {
        this.modelType = modelType;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String[] getRoute() {
        return route;
    }

    public void setRoute(String route1, String route2) {
        this.route[0] = route1;
        this.route[1] = route2;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public Driver getAssignedDriver() {
        return driver;
    }

    public void setAssignedDriver(Driver assignedDriver) {
        this.driver = assignedDriver;
    }

    // Методи поведінки
    public void Movement() // метод руху
    {
        if (this.stopped == this.route[0]) {
            this.stopped = this.route[1];
        } else if (this.stopped == this.route[1]) {
            this.stopped = this.route[0];
        }
    }

    public abstract void assignDriver(Driver driver);

    public abstract void assignModel();

    @Override
    public String toString() {
        return "Model: " + this.type.toString() + ", " + this.modelType + ", Manufacturer: " + this.manufacturer + ", Number: " + this.number + ", Route: " + Arrays.toString(this.route) + ", Capacity: " + this.capacity + ", Driver: " + this.driver + ", Stopped at: " + this.stopped;
    }

}

