﻿namespace ASD_RR1
{
    internal static class UI
    {
        public static void Menu()
        {
            Console.Clear();
            Console.WriteLine(
                $"Меню роботи сортування\n" +
                $"1 - Введення довжини масиву та його автоматичне створення\n" +
                $"2 - Тест часу сортування за різними випадками\n");
            return;
        }

        public static ushort Input_range(string text, ushort up_range, ushort down_range)
        {
            while (true)
            {
                ushort input;

                try
                {
                    Console.Write(text);
                    input = Byte.Parse(Console.ReadLine());

                    if (input > up_range || input < down_range)
                        throw new Exception($"Value should be in range {down_range}-{up_range}.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"{ex.Message}");
                    continue;
                }
                Console.WriteLine();
                return input;
            }
        }

        public static void PressEnter()
        {
            while (true)
            {
                Console.WriteLine("To continiue press Enter...");
                var key = Console.ReadKey(intercept: true);
                if (key.Key == ConsoleKey.Enter)
                {
                    Console.Clear();
                    break; // Выход из цикла, если нажата клавиша Enter
                }
                else Console.WriteLine("Pressed another key");
            }
        }
        public static void PrintColorArr(string message, KeyValue[] array, int highlightIndex1 = -1, int highlightIndex2 = -1)
        {
            Console.WriteLine(message);

            for (int i = 0; i < array.Length; i++)
            {
                if (i == highlightIndex1 || i == highlightIndex2)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write($"Key: {array[i].Key}, Value: {array[i].Value} ");
                    Console.ResetColor();
                }
                else
                {
                    Console.Write($"Key: {array[i].Key}, Value: {array[i].Value} ");
                }
            }
            Console.WriteLine();
        }
    }
}
