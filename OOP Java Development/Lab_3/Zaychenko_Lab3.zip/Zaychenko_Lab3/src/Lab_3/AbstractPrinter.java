package Lab_3;

// Абстрактний клас для принтерів
public abstract class AbstractPrinter {
    protected String modelType;
    protected String paperFormat;
    protected double weight;
    protected double price;
    protected int printSpeed;
    protected String mode;
    protected String interfaceType;
    protected String state;

    // Конструктор
    public AbstractPrinter(String modelType, String paperFormat, double weight, double price, int printSpeed,
                           String mode, String interfaceType, String state) {
        this.modelType = modelType;
        this.paperFormat = paperFormat;
        this.weight = weight;
        this.price = price;
        this.printSpeed = printSpeed;
        this.mode = mode;
        this.interfaceType = interfaceType;
        this.state = state;
    }

    // Методи для визначення та зміни властивостей

    // зміна властивостей
    public void changeProperties(String modelType, String paperFormat, double weight, double price,
                                 int printSpeed, String mode, String interfaceType, String state) {
        this.modelType = modelType;
        this.paperFormat = paperFormat;
        this.weight = weight;
        this.price = price;
        this.printSpeed = printSpeed;
        this.mode = mode;
        this.interfaceType = interfaceType;
        this.state = state;
    }

    // отримання властивостей
    public String getProperties() {
        StringBuilder properties = new StringBuilder();
        properties.append("Model Type: ").append(modelType).append("\n");
        properties.append("Paper Format: ").append(paperFormat).append("\n");
        properties.append("Weight: ").append(weight).append("\n");
        properties.append("Price: ").append(price).append("\n");
        properties.append("Print Speed: ").append(printSpeed).append("\n");
        properties.append("Mode: ").append(mode).append("\n");
        properties.append("Interface Type: ").append(interfaceType).append("\n");
        properties.append("State: ").append(state).append("\n");
        return properties.toString();
    }

    // визначення стану принтера
    public String getState() {
        return state;
    }

    // Дії принтера
    public abstract String print(String document); // Метод для друку документа

    // Метод для підключення принтера
    public void connect() {
        this.state = EnumPrntState.READY.getEnumState();
    }

    // Метод для відключення принтера
    public void disconnect() {
        this.state = EnumPrntState.OFFLINE.getEnumState();
    }

    public void error() {
        this.state = EnumPrntState.ERROR.getEnumState();
    } // Метод для відображення помилки друку

    public static final String RESET = "\033[0m";  // Повернення до стандартних налаштувань


}
