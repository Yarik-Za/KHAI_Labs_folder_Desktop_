package Classes;

//загальні властивості тварин.
public class Animal {
    private String name;
    private int Age;

    // конструктор з параметром ім'я.
    public Animal(String NAME) {
        setName(NAME);
    }

    public Animal(String NAME, int AGE) {
        setName(NAME);
        setAge(AGE);
    }

    // отримання імені тварини.
    public String getName() {
        return this.name;
    }

    public int getAge() {
        return this.Age;
    }

    // Метод-сеттер для імені тварини з перевіркою на відповідність заданим критеріям
    public void setName(String name) throws IllegalArgumentException {

        // Розбиваємо рядок на символи і перевіряємо кожен символ
        for (char c : name.toCharArray()) {
            if (!Character.isLetter(c)) {
                throw new IllegalArgumentException("Ім'я тварини може містити лише літери.");
            }
        }
        if (name.length() < 3 || name.length() > 20) {
            throw new IllegalArgumentException("Ім'я тварини повинно містити від 3 до 15 символів.");
        }
        this.name = name;
    }

    public void setAge(int AGE) throws IllegalArgumentException {
        if (AGE < 0) throw new IllegalArgumentException("Вік тварини не може бути від'ємним.");
        this.Age=AGE;
    }

    // метод звуку
    public void makeSound() {
        System.out.println("Тварина видає звук.");
    }
}
