import Classes.Testing;

import java.util.Scanner;

public class Main { // клас мейн
    public static void main(String[] args) { // початок виконання програми в методі мейн 
        // Створення об'єкта Scanner для зчитування введеного тексту з консолі
        Scanner scanner = new Scanner(System.in);

        boolean end = false;

        while (!end) {
            try {
                // Виведення повідомлення, щоб користувач ввів текст
                System.out.print("Введіть ім'я цуценя:");

                String inputName = scanner.nextLine(); // Зчитування введеного тексту

                Testing.StartTest(inputName); //виклик методу з класу для тестів

                end = true; //все пройшло без помилок - можна виходити
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage()); // виведення тексту помилки
            }
        }
        Testing.AllTest();
    }
}

