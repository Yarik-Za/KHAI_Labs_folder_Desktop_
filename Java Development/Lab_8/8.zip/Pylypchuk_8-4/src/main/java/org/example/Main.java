package org.example;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        String line="";
        for(int i=0; i<10; i+=2){
            line+="a";
            line+=(i+2);
        }
        System.out.println(line);
    }
}