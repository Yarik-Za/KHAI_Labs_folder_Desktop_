using System;
using System.Windows.Forms;

namespace UIExample
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeUI();
        }

        private void InitializeUI()
        {
            // MenuStrip
            MenuStrip menuStrip = new MenuStrip();
            ToolStripMenuItem fileMenu = new ToolStripMenuItem("File");
            ToolStripMenuItem exitMenuItem = new ToolStripMenuItem("Exit");
            exitMenuItem.Click += (sender, e) => Close();
            fileMenu.DropDownItems.Add(exitMenuItem);
            menuStrip.Items.Add(fileMenu);
            Controls.Add(menuStrip);

            // ComboBox for selecting values
            ComboBox valuesComboBox = new ComboBox();
            //valuesComboBox.DropDownStyle = ComboBoxStyle.DropDownList; // Prevents manual input
            valuesComboBox.Items.AddRange(new object[] { "Option 1", "Option 2", "Option 3" });
            valuesComboBox.Location = new System.Drawing.Point(50, 50);
            Controls.Add(valuesComboBox);

            // Panel for more complex UI
            Panel complexPanel = new Panel();
            complexPanel.BorderStyle = BorderStyle.FixedSingle;
            complexPanel.Size = new System.Drawing.Size(200, 150);
            complexPanel.Location = new System.Drawing.Point(50, 100);
            // Add more UI elements to the complexPanel as needed
            Controls.Add(complexPanel);
        }
    }

    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
