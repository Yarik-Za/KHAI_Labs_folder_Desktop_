﻿using System;
using System.Text;

namespace Practice_Task2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            Console.InputEncoding = System.Text.Encoding.GetEncoding(1251);
            Console.OutputEncoding = System.Text.Encoding.GetEncoding(1251);

            double epsilon = 1e-6;

            // Основне рівняння
            //double x0_main = 3.0; // початкове наближення
            double x0_main = -5.0; // початкове наближення
            double root_main = FindRoot(x0_main, epsilon, F_main, FPrime_main);
            Console.WriteLine($"Знайдений корінь основного рівняння: {root_main}");

            // Додаткові рівняння
            SolveAdditionalEquations(epsilon);
        }

        static void SolveAdditionalEquations(double epsilon)
        {
            double x0;
            int maxIterations = 1000;

            // x^3 - 12x + 6 = 0
            double[] initialGuesses = { 1.0, 2.0, 3.0 };
            foreach (double guess in initialGuesses)
            {
                try
                {
                    double root1 = FindRoot(guess, epsilon, F1, FPrime1, maxIterations);
                    Console.WriteLine($"Знайдений корінь рівняння x^3 - 12x + 6 = 0 з початковим наближенням {guess}: {root1}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Не вдалося знайти корінь для x^3 - 12x + 6 = 0 з початковим наближенням {guess}: {ex.Message}");
                }
            }

            // x^2 - 4 = 0
            x0 = 2.0;
            double root2 = FindRoot(x0, epsilon, F2, FPrime2, maxIterations);
            Console.WriteLine($"Знайдений корінь рівняння x^2 - 4 = 0: {root2}");

            // sin(x) = 0
            x0 = 3.0;
            double root3 = FindRoot(x0, epsilon, F3, FPrime3, maxIterations);
            Console.WriteLine($"Знайдений корінь рівняння sin(x) = 0: {root3}");

            // e^x - 3 = 0
            x0 = 1.0;
            double root4 = FindRoot(x0, epsilon, F4, FPrime4, maxIterations);
            Console.WriteLine($"Знайдений корінь рівняння e^x - 3 = 0: {root4}");

            // x^3 + x - 1 = 0
            x0 = 0.5;
            double root5 = FindRoot(x0, epsilon, F5, FPrime5, maxIterations);
            Console.WriteLine($"Знайдений корінь рівняння x^3 + x - 1 = 0: {root5}");
        }

        static double FindRoot(double x0, double epsilon, Func<double, double> F, Func<double, double> FPrime, int maxIterations = 100)
        {
            double x1 = x0;
            double x2;
            int iteration = 0;
            do
            {
                x2 = x1;
                double fValue = F(x2);
                double fPrimeValue = FPrime(x2);

                if (Math.Abs(fPrimeValue) < epsilon)
                {
                    throw new Exception("Похідна близька до нуля. Спробуйте інше початкове наближення.");
                }

                x1 = x2 - fValue / fPrimeValue;

                if (++iteration > maxIterations)
                {
                    throw new Exception("Перевищено максимальну кількість ітерацій.");
                }
            }
            while (Math.Abs(x1 - x2) > epsilon);
            return x1;
        }

        // Основне рівняння
        static double F_main(double x)
        {
            return x * x * x - 3 * x * x - 24 * x - 5;
        }

        static double FPrime_main(double x)
        {
            return 3 * x * x - 6 * x - 24;
        }

        // x^3 - 12x + 6 = 0
        static double F1(double x)
        {
            return x * x * x - 12 * x + 6;
        }

        static double FPrime1(double x)
        {
            return 3 * x * x - 12;
        }

        // x^2 - 4 = 0
        static double F2(double x)
        {
            return x * x - 4;
        }

        static double FPrime2(double x)
        {
            return 2 * x;
        }

        // sin(x) = 0
        static double F3(double x)
        {
            return Math.Sin(x);
        }

        static double FPrime3(double x)
        {
            return Math.Cos(x);
        }

        // e^x - 3 = 0
        static double F4(double x)
        {
            return Math.Exp(x) - 3;
        }

        static double FPrime4(double x)
        {
            return Math.Exp(x);
        }

        // x^3 + x - 1 = 0
        static double F5(double x)
        {
            return x * x * x + x - 1;
        }

        static double FPrime5(double x)
        {
            return 3 * x * x + 1;
        }
    }
}
