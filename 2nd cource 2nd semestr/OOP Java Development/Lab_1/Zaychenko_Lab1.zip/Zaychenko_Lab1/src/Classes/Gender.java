package Classes;

// Оголошення перерахування для статі тварини
public enum Gender {
    MALE,
    FEMALE,
    UNKNOWN;
}
