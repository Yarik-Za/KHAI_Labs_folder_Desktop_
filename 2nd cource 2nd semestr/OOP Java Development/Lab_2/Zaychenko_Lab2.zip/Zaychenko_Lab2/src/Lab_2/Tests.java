package Lab_2;

import Lab_2.Classes.Transport.*;
import Lab_2.Classes.Storages.DriversStorage;
import Lab_2.Classes.Storages.VehiclesStorage;

public class Tests {

    public static void TestActions() {
        try {
            Interface ui = new Interface();

            DriversStorage dl = new DriversStorage();
            VehiclesStorage vl = new VehiclesStorage();

            Driver d1 = new Driver("Ivan", "Ivanovych", "Petrushenko", dl);
            Driver d2 = new Driver("Yan", "Petrovych", "Petrushenko", 56, dl);
            Driver d3 = new Driver("Oleksandr", "Oleksandrovych", "Petrushenko", dl);
            Driver d4 = new Driver("Andriy", "Andriyovych", "Petrushenko", dl);
            Driver d5 = new Driver("Petro", "Petrovych", "Petrushenko", 34, dl);
            Driver d6 = new Driver("Maria", "Ivanivna", "Ivanenko", dl);
            Driver d7 = new Driver("Oksana", "Petrovna", "Petrovych", 23, dl);
            Driver d8 = new Driver("Vasyl", "Vasylivna", "Vasylivych", 34, dl);
            Driver d9 = new Driver("Mykola", "Mykolayivna", "Mykolenko", dl);
            Driver d10 = new Driver("Anna", "Ivanivna", "Ivanenko", 66, dl);

            Bus bus1 = new Bus("Man", "AB1234", "Station A", "Station B", 50, vl);
            Bus bus2 = new Bus("Volvo", "CD5678", "Station C", "Station D", 60, vl);
            Bus bus3 = new Bus("Mercedes", "EF91011", "Station E", "Station F", 70, vl);

            TrolleyBus trolleyBus1 = new TrolleyBus("TrolZa", "TB111", "Station G", "Station H", 40, vl);
            TrolleyBus trolleyBus2 = new TrolleyBus("Skoda", "TB222", "Station I", "Station J", 45, vl);
            TrolleyBus trolleyBus3 = new TrolleyBus("Solaris", "TB333", "Station K", "Station L", 55, vl);

            Tram tram1 = new Tram("Siemens", "TR123", "Station M", "Station N", 60, vl);
            Tram tram2 = new Tram("Bombardier", "TR456", "Station O", "Station P", 65, vl);
            Tram tram3 = new Tram("Alstom", "TR789", "Station Q", "Station R", 70, vl);

            // Виводимо повну інформацію про водіїв та транспортні засоби

            ui.AllObjects(dl);
            ui.AllObjects(vl);

            ui.removeObject(dl, 9);
            ui.removeObject(vl, 8);

            ui.setDriver((AbstractPublicTransport) vl.get(3), (Driver) dl.get(6));

            System.out.println((Object) vl.get(3).toString());


            System.out.println(ui.CompareObj(d1,d3));
            System.out.println(ui.getHash(d6));
        } catch (Exception e) {
            System.out.println(e.getMessage().toString());
        }
    }

    public static void testInterfaceMethods() {
        System.out.println("Testing Lab_2.Interface methods:");

        DriversStorage idl = new DriversStorage();
        VehiclesStorage ivl = new VehiclesStorage();
        Interface interfaceInstance = new Interface();

        // Testing addObj method - ok
        System.out.println("Testing adding driver method:");
        interfaceInstance.CreateDriver(idl);

        System.out.println("Testing adding vehicle method:");
        interfaceInstance.CreateVehicle(ivl);


        // Testing showList method
        System.out.println("Testing showList method drivers:");
        Interface.AllObjects(idl);
        System.out.println("Testing showList method vehicles:");
        Interface.AllObjects(ivl);

        // Testing deleteObj method
        Driver del = new Driver("DeleteName", "Delete sName", "DeleteMname", idl);
        System.out.println("Testing delete driver method:");
        interfaceInstance.deleteObj();

        System.out.println("Testing delete vehicle method:");
        interfaceInstance.deleteObj();
        Tram tram3 = new Tram("Dell", "TR789", "Station D", "Station Delete", 70, ivl);

        // Testing giveDriver method
        System.out.println("Testing giveDriver to vehicle method:");
        interfaceInstance.giveDriver();

        interfaceInstance.getHashedObj();

        interfaceInstance.getComparedObj();


    }

}
