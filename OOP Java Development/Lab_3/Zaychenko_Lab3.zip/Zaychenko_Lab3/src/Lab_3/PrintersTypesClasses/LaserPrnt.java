package Lab_3.PrintersTypesClasses;

import Lab_3.AbstractPrinter;

public class LaserPrnt extends AbstractPrinter implements DuplexPrinting, InkLevelMonitor {
    public LaserPrnt(String modelType, String paperFormat, double weight, double price, int printSpeed, String mode, String interfaceType, String state) {
        super(modelType, paperFormat, weight, price, printSpeed, mode, interfaceType, state);
        this.reloadInk();
    }
    public static final String BOLD = "\033[1m";   // Жирний текст
    @Override
    public String print(String document) {
        if(isLowInk()) throw new RuntimeException("Unable to print. Low Ink");
        decreaseInkLevel(document);
        String res = "";
        res +=BOLD+document+RESET;
        if (duplexPrintingEnabled)
            res+=DPrnt(document);
        return res;
    }

    private boolean duplexPrintingEnabled = false;
    @Override
    public void enableDuplexPrinting() {
        duplexPrintingEnabled = true;
    }

    @Override
    public String DPrnt(String doc) {
        decreaseInkLevel(doc);
        String res = "";
        for (int i = doc.length() - 1; i >= 0; i--) {
            res += doc.charAt(i);
        }
        return BOLD+res+RESET;
    }

    private double inkLevel;
    @Override
    public String getInkLevel() {
        return inkLevel+"%";
    }

    @Override
    public boolean isLowInk() {
        return inkLevel < 20;
    }

    @Override
    public void decreaseInkLevel(String doc) {
        int SymbCount = doc.length();
        double oneSymbInk=0.4;
        double inkSpend = SymbCount*oneSymbInk;
        inkLevel-=inkSpend;
    }

    @Override
    public void reloadInk() {
        inkLevel=100;
    }
}
