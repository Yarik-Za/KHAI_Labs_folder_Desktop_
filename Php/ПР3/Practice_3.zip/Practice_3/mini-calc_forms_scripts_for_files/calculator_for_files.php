<!DOCTYPE html>
<html lang="uk">

<head>
    <meta charset="UTF-8">
    <title>Міні-калькулятор з обробкою файлів</title>
</head>

<body>
    <?php
    date_default_timezone_set('Europe/Kiev');
    $errormsg = "";

    if (!isset($_FILES['file1'], $_FILES['file2'], $_POST['operation'])) {
        $errormsg .= "Помилка: відсутні необхідні файли або не вибрано операцію.<br>";
        exit;
    }

    $file1Path = $_FILES['file1']['tmp_name'];
    $file2Path = $_FILES['file2']['tmp_name'];
    $operation = $_POST['operation'];

    // Встановлення назви операції для відображення
    switch ($operation) {
        case 'addition':
            $operationName = 'Додавання';
            break;
        case 'subtraction':
            $operationName = 'Віднімання';
            break;
        case 'multiplication':
            $operationName = 'Множення';
            break;
        case 'division':
            $operationName = 'Ділення';
            break;
        case 'exponentiation':
            $operationName = 'Піднесення до степеня';
            break;
        default:
            $operationName = 'Невідома операція';
    }

    // Функція для завантаження чисел з файлу
    function loadNumbersFromFile($filePath)
    {
        $content = file_get_contents($filePath);
        if (trim($content) === '') {
            return []; // Повертаємо порожній масив, якщо файл порожній
        }
        $numbers = explode(";", trim($content));
        return array_map('floatval', $numbers);
    }

    // Завантаження чисел з файлів
    $numbers1 = loadNumbersFromFile($file1Path);
    $numbers2 = loadNumbersFromFile($file2Path);

    // Перевірка на порожні файли
    if (empty($numbers1) || empty($numbers2)) {
        $errormsg .= "Помилка: один або обидва файли порожні. Будь ласка, завантажте файли з числами.<br>";
    }

    // Перевірка на однакову кількість чисел у файлах
    if (count($numbers1) !== count($numbers2)) {
        $errormsg .= "Помилка: кількість чисел у файлах не збігається.<br>";
    }
    if (!empty($errormsg)) {
        echo "<h2>Відбулася помилка під час виконання:</h2>";
        echo "$errormsg";
    } else {
        // Якщо всі перевірки пройдено, виконуємо обчислення
        echo "<h2>Результати обчислень:</h2>";
        echo "<h3>Операція, яка виконувалась: $operationName</h3>";

        // Обробка кожної пари чисел
        foreach ($numbers1 as $index => $number1) {
            $number2 = $numbers2[$index];
            $operationResult = '';

            // Виконання обраної операції
            switch ($operation) {
                case 'addition':
                    $operationResult = $number1 + $number2;
                    break;
                case 'subtraction':
                    $operationResult = $number1 - $number2;
                    break;
                case 'multiplication':
                    $operationResult = $number1 * $number2;
                    break;
                case 'division':
                    $operationResult = ($number2 != 0) ? ($number1 / $number2) : "Помилка: ділення на нуль";
                    break;
                case 'exponentiation':
                    $operationResult = pow($number1, $number2);
                    break;
                default:
                    $operationResult = "Невідома операція";
            }

            echo "Результат для пари чисел $number1 і $number2: <u>$operationResult</u><br>";
        }
    }
    ?>

    <footer>
        <hr>
        <p>Дата генерації: <?php echo date('H:i:s d.m.Y'); ?><br>
            Виконавець: Зайченко Ярослав Ігорович, 632п</p>
    </footer>
</body>

</html>