package com.example.simplealarmclock

data class Alarm(val name: String, val time: String, var status: AlarmStatus) {
    enum class AlarmStatus {
        ENABLED,
        DISABLED,
        SNOOZED
    }
}

