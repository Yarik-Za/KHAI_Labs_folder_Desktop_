﻿using System;
using System.Text;

namespace ASD_Lab_2_vector_
{
    internal class Program
    {
        static void PressEnter()
        {
            while (true)
            {
                Console.WriteLine("Для продовження натисніть Enter...");
                var key = Console.ReadKey(intercept: true);
                if (key.Key == ConsoleKey.Enter)
                {
                    Console.Clear();
                    break; // Выход из цикла, если нажата клавиша Enter
                }
                else Console.WriteLine("Була натиснута інша клавіша");
            }
        }

        static void Main(string[] args)
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            Console.InputEncoding = System.Text.Encoding.GetEncoding(1251);
            Console.OutputEncoding = System.Text.Encoding.GetEncoding(1251);

            MyStack stack = new MyStack(10); // Создаем стек с начальной емкостью 10

            Console.WriteLine("Однонаправлений циклічний список символів\n");

            while (true)
            {
                Console.WriteLine("Меню:");
                Console.WriteLine("1. Додати символ до стеку");
                Console.WriteLine("2. Видалити символ зі стеку");
                Console.WriteLine("3. Перевірити наповненість стеку");
                Console.WriteLine("4. Переглянути перший символ у стеку");
                Console.WriteLine("5. Переглянути всі символи у стеку");
                Console.WriteLine("6. Розділити стек на два підсписки");
                Console.WriteLine("7. Порахувати кількість елементів стеку");
                Console.WriteLine("8. Вийти з програми");
                Console.Write("\nВведіть ваш вибір: ");

                char mode = Console.ReadKey().KeyChar;
                Console.WriteLine("\n");

                switch (mode)
                {
                    case '1':
                        Console.Write("Введіть символ для додавання до стеку: ");
                        char input = Console.ReadKey().KeyChar;
                        Elem newElem = new Elem(input);
                        if (stack.Push(newElem))
                        {
                            Console.WriteLine($"\nСимвол '{input}' успішно додано до стеку.");
                        }
                        else
                        {
                            Console.WriteLine("\nСтек переповнений. Неможливо додати символ.");
                        }
                        PressEnter();
                        break;

                    case '2':
                        if (stack.Pop())
                        {
                            Console.WriteLine("Символ видалено зі стеку.");
                        }
                        else
                        {
                            Console.WriteLine("Стек порожній. Неможливо видалити символ.");
                        }
                        PressEnter();
                        break;

                    case '3':
                        if (stack.IsEmpty())
                            Console.WriteLine("Стек пустий");
                        else Console.WriteLine("Стек НЕ пустий");
                        PressEnter();
                        break;
                    case '4':
                        try
                        {
                            Elem firstElement = stack.Peek();
                            Console.WriteLine("Перший символ у стеку: " + (char)firstElement._inf);
                        }
                        catch (InvalidOperationException)
                        {
                            Console.WriteLine("Стек порожній. Неможливо переглянути перший символ.");
                        }
                        PressEnter();
                        break;

                    case '5':
                        Console.WriteLine("Список символів в стеку:");
                        Console.WriteLine(stack.Print());
                        PressEnter();
                        break;

                    case '6':
                        Tuple<MyStack, MyStack> splitResult = stack.SplitStack();

                        MyStack firstHalf = splitResult.Item1;
                        MyStack secondHalf = splitResult.Item2;

                        Console.WriteLine("Стек розділено на два підсписки.");
                        //Console.WriteLine("Перший підсписок:");
                        //Console.WriteLine(firstHalf.ToString());
                        //Console.WriteLine("Другий підсписок:");
                        //Console.WriteLine(secondHalf.ToString());

                        Console.WriteLine("Перший підсписок:");
                        Console.WriteLine(firstHalf.Print());
                        Console.WriteLine("Другий підсписок:");
                        Console.WriteLine(secondHalf.Print());

                        PressEnter();
                        break;

                    case '7':
                        Console.WriteLine("Кількість елементів в стеку: " + stack.CountEl());
                        PressEnter();
                        break;

                    case '8':
                        Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Невідома опція. Будь ласка, виберіть інший варіант.");
                        PressEnter();
                        break;
                }
            }
        }
    }
}