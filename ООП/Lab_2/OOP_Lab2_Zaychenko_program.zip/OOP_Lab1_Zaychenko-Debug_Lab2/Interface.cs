﻿using Microsoft.VisualBasic;
using System.ComponentModel.Design;
using System.Globalization;
using System.Threading.Tasks;
using System.Transactions;

namespace Lab_1
{
    internal class Interface
    {
        private int QuantityMax;
        private int count = Storage.GetTasks().Count;
        Homework new_task = new();
        public void Create()
        {
            TaskType taskType = TaskType.Default;

            #region input

            while (true)
            {
                try
                {
                    QuantityMax = Input("Enter the quantity of hometasks: ", 10, 1);

                    if (count >= QuantityMax) throw new Exception("Reached the max quantity of tasks creation");
                    break;
                }
                catch (Exception ex) { Console.WriteLine(ex.Message); break; }
            }

            //Homework new_task = new();

            while (count < QuantityMax)
            {
                while (true)
                {
                    try
                    {
                        Console.Write("Enter task number: ");
                        int taskNumber;
                        int.TryParse(Console.ReadLine(), out taskNumber);
                        new_task.TaskNumber = taskNumber;
                        break;
                    }
                    catch (Exception ex) { Console.WriteLine(ex.Message); continue; }
                }

                while (true)
                {
                    try
                    {
                        Console.Write($"Enter deadline in format {Homework.DateFormat}: ");
                        string input_date = Console.ReadLine();
                        Console.WriteLine();
                        if (DateTime.TryParseExact(input_date, Homework.DateFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime result))
                        {
                            new_task.Deadline = result; break;
                        }
                        else throw new Exception($"Date input error. Try correct format {Homework.DateFormat}");

                    }
                    catch (Exception ex) { Console.WriteLine(ex.Message); continue; }
                }

                while (true)
                {
                    try
                    {
                        Console.Write("Enter subject: ");
                        string subject = Console.ReadLine();
                        new_task.Subject = subject;
                        break;
                    }
                    catch (Exception ex) { Console.WriteLine(ex.Message); continue; }
                }
                Console.WriteLine();

                while (true)
                {
                    Console.WriteLine($"***[Task Types]****************************************\r\n" +
                        $" 0 - Comp \r\n" +
                        $" 1 - Oral \r\n" +
                        $" 2 - Write");
                    Console.WriteLine($"*******************************************************");

                    while (true)
                    {
                        try
                        {
                            //Console.Write("Select task type: ");
                            //byte select = byte.Parse(Console.ReadLine());
                            //if (select >= 3) throw new Exception("Value should be in range 0-2");

                            byte select;
                            select = Convert.ToByte(Input("Select task type: ", 2, 0));
                            switch (select)
                            {
                                case 0: taskType = TaskType.Comp; break;
                                case 1: taskType = TaskType.Oral; break;
                                case 2: taskType = TaskType.Write; break;
                                default: Console.Write("Input error. Try again"); continue;
                            }
                            break;
                        }
                        catch (Exception ex) { Console.WriteLine($"{ex.Message}"); }
                    }
                    new_task.TaskType = taskType;
                    break;
                }
                //Console.WriteLine($"*******************************************************");
                while (true)
                {
                    try
                    {
                        Console.Write("Enter task description: ");
                        string taskText = Console.ReadLine();
                        Console.WriteLine();
                        new_task.TaskText = taskText;
                        break;
                    }
                    catch (Exception ex) { Console.WriteLine(ex.Message); continue; }
                }
                #endregion

                Homework task = new(new_task.TaskNumber, new_task.Deadline, new_task.Subject, new_task.TaskType, new_task.TaskText);
                Console.WriteLine("Task created successfuly\n++++++++++++++++++++++++++");

                count++;
            }
        }
        public void Output()
        {
            foreach (Homework task in Storage.GetTasks())
            {
                if (!(Storage.GetTasks().Any()))
                    throw new Exception("No tasks exist in ");

                task.IsDone();
                Console.WriteLine("" +
                   $"*****************************************[Index: {Storage.GetTasks().IndexOf(task)}]***\n" +
                   $" Task number: {task.TaskNumber}\n" +
                   $" Task deadline: {task.Deadline.ToString(Homework.DateFormat)}\n" +
                   $" Task subject: {task.Subject}\n" +
                   $" Task description: {task.TaskText}\n" +
                   $" Task type: {task.TaskType}\n" +
                   $" Task done: {task.done}\n" +
                   $" Task expired: {task.IsExpired}\n" +
                   $"*******************************************************\n");
            }
        }

        public void Find()
        {
            while (true)
            {
                Console.WriteLine($"Choose search option: \n" +
                    $" 0 - By task number\n" +
                    $" 1 - By deadline\n" +
                    $" 2 - Return to Menu\n");

                Console.Write("Select option: ");
                byte select = byte.Parse(Console.ReadLine());
                if (select >= 3) Console.WriteLine("Value should be in range 0-2");

                switch (select)
                {
                    case 0: FindByNumber(); break;
                    case 1: FindByDeadline(); break;
                    case 2: return;
                }
                break;
            }
        }

        public void FindByNumber()
        {
            Console.Write("Enter task number: ");
            int inputNumber = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine();

            foreach (Homework task in Storage.GetTasks())
            {
                if (inputNumber == task.TaskNumber)
                {
                    task.IsDone();
                    Console.WriteLine("" +
                           $"*****************************************[Index: {Storage.GetTasks().IndexOf(task)}]***\n" +
                           $" Task number: {task.TaskNumber.ToString()}\n" +
                           $" Task deadline: {task.Deadline.ToString(Homework.DateFormat)}\n" +
                           $" Task subject: {task.Subject}\n" +
                           $" Task description: {task.TaskText}\n" +
                           $" Task type: {task.TaskType}\n" +
                           $" Task done: {task.done}\n" +
                           $" Task expired: {task.IsExpired}\n" +
                           $"*******************************************************\n");
                }
            }
        }

        public void FindByDeadline()
        {
            bool inputDateValid = false;
            while (!inputDateValid)
            {
                Console.Write($"Enter task deadline (in the format {Homework.DateFormat}): ");
                string inputDateString = Console.ReadLine();
                DateTime inputDate;

                if (DateTime.TryParseExact(inputDateString, Homework.DateFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out inputDate))
                {
                    inputDateValid = true;
                }
                else if (!DateTime.TryParseExact(inputDateString, Homework.DateFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out inputDate))
                {
                    Console.WriteLine($"Invalid date format. Please enter the date in {Homework.DateFormat} format.");
                    return;
                }
                Console.WriteLine();

                foreach (Homework task in Storage.GetTasks())
                {
                    if (inputDate == task.Deadline)
                    {
                        task.IsDone();
                        Console.WriteLine("" +
                               $"*****************************************[Index: {Storage.GetTasks().IndexOf(task)}]***\n" +
                               $" Task number: {task.TaskNumber}\n" +
                               $" Task deadline: {task.Deadline.ToString(Homework.DateFormat)}\n" +
                               $" Task subject: {task.Subject}\n" +
                               $" Task description: {task.TaskText}\n" +
                               $" Task type: {task.TaskType}\n" +
                               $" Task done: {task.done}\n" +
                               $" Task expired: {task.IsExpired}\n" +
                               $"*******************************************************\n");
                    }
                }
            }
        }

        public void Delete()
        {
            while (true)
            {
                Console.WriteLine($"Choose delete option: \n" +
                    $" 0 - By task number\n" +
                    $" 1 - By deadline\n" +
                    $" 2 - Return to Menu\n");

                Console.Write("Select option: ");
                byte select = byte.Parse(Console.ReadLine());
                if (select >= 3) throw new Exception("Value should be in range 0-2");

                switch (select)
                {
                    case 0: DeleteByNumber(); break;
                    case 1: DeleteByDeadline(); break;
                    case 2: return;
                }
                break;
            }
        }
        public void DeleteByNumber()
        {
            int inputNumber;
            while (true)
            {
                try
                {
                    Console.Write("Enter task number: ");
                    inputNumber = Convert.ToUInt16(Console.ReadLine());
                    if (inputNumber > 0)
                    {
                        Console.WriteLine(); break;
                    }
                    else throw new Exception("Number shold be above zero");
                }
                catch (Exception ex) { Console.WriteLine(ex.Message); continue; }
            }

            /*for (int i = Storage.Tasks.Count - 1; i >= 0; i--)
            {
                Homework task = Storage.Tasks[i];

                if (inputNumber == task.taskNumber)
                {
                    found = true;
                    Console.WriteLine("" +
                        $"*****************************************[Index: {i}]***\n" +
                        $" Task number: {task.taskNumber}\n" +
                        $" Task deadline: {task.deadline.ToString(Homework.DateFormat)}\n" +
                        $" Task subject: {task.subject}\n" +
                        $" Task description: {task.taskText}\n" +
                        $" Task type: {task.taskType}\n" +
                        $"*******************************************************\n");

                    Storage.Tasks.RemoveAt(i);
                }
            }
            if (!found)
            {
                Console.WriteLine("No tasks found with the specified task number.");
            }
            else
            {
                Console.WriteLine("Task(s) deleted successfully.");
            }*/

            List<Homework> tasksToDelete = new List<Homework>();

            // Find tasks with the same numbers and add them to tasksToDelete list
            for (int i = 0; i < Storage.GetTasks().Count; i++)
            {
                Homework task = Storage.GetTasks()[i];
                if (inputNumber == task.TaskNumber)
                {
                    tasksToDelete.Add(task);
                }
            }

            if (tasksToDelete.Count == 0)
            {
                Console.WriteLine("No tasks found with the specified number.");
                return;
            }

            Console.WriteLine("Tasks with the specified number:");
            for (int i = 0; i < tasksToDelete.Count; i++)
            {
                tasksToDelete[i].IsDone();
                Console.WriteLine($"[{i + 1}] Task number: {tasksToDelete[i].TaskNumber}");
                Console.WriteLine($"    Task deadline: {tasksToDelete[i].Deadline.ToString(Homework.DateFormat)}");
                Console.WriteLine($"    Task subject: {tasksToDelete[i].Subject}");
                Console.WriteLine($"    Task description: {tasksToDelete[i].TaskText}");
                Console.WriteLine($"    Task type: {tasksToDelete[i].TaskType}\n" +
                                  $"    Task done: {tasksToDelete[i].done}\n" +
                                  $"    Task expired: {tasksToDelete[i].IsExpired}\n");

                Console.WriteLine();
            }

            Console.Write("Enter the number of the task to delete: ");
            if (int.TryParse(Console.ReadLine(), out int selectedTaskIndex) && selectedTaskIndex >= 1 && selectedTaskIndex <= tasksToDelete.Count)
            {
                // Remove the selected task
                Storage.GetTasks().Remove(tasksToDelete[selectedTaskIndex - 1]);
                Console.WriteLine("Task deleted successfully.");
            }
            else
            {
                Console.WriteLine("Invalid input. Task was not deleted.");
            }
        }

        //public void DeleteByDeadline_noChoise()
        //{
        //    Console.Write($"Enter task deadline (in the format {Homework.DateFormat}): ");
        //    string inputDateString = Console.ReadLine();
        //    DateTime inputDate;

        //    if (!DateTime.TryParseExact(inputDateString, Homework.DateFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out inputDate))
        //    {
        //        Console.WriteLine($"Invalid date format. Please enter the date in {Homework.DateFormat} format.");
        //        return;
        //    }

        //    Console.WriteLine();

        //    for (int i = Storage.Tasks.Count - 1; i >= 0; i--)
        //    {
        //        Homework task = Storage.Tasks[i];
        //        if (inputDate == task.deadline)
        //        {
        //            Console.WriteLine($"*****************************************[Index: {i}]***");
        //            Console.WriteLine($" Task number: {task.taskNumber}");
        //            Console.WriteLine($" Task deadline: {task.deadline.ToString(Homework.DateFormat)}");
        //            Console.WriteLine($" Task subject: {task.subject}");
        //            Console.WriteLine($" Task description: {task.taskText}");
        //            Console.WriteLine($" Task type: {task.taskType}");
        //            Console.WriteLine("*******************************************************");

        //            Storage.Tasks.RemoveAt(i);
        //        }
        //    }
        //}

        public void DeleteByDeadline()
        {
            Console.Write($"Enter task deadline (in the format {Homework.DateFormat}): ");
            string inputDateString = Console.ReadLine();
            DateTime inputDate;

            if (!DateTime.TryParseExact(inputDateString, Homework.DateFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out inputDate))
            {
                Console.WriteLine($"Invalid date format. Please enter the date in {Homework.DateFormat} format.");
                return;
            }

            Console.WriteLine();
            List<Homework> tasksToDelete = new List<Homework>();

            // Find tasks with the same deadline and add them to tasksToDelete list
            for (int i = 0; i < Storage.GetTasks().Count; i++)
            {
                Homework task = Storage.GetTasks()[i];
                if (inputDate == task.Deadline)
                {
                    tasksToDelete.Add(task);
                }
            }

            if (tasksToDelete.Count == 0)
            {
                Console.WriteLine("No tasks found with the specified deadline.");
                return;
            }

            Console.WriteLine("Tasks with the specified deadline:");
            for (int i = 0; i < tasksToDelete.Count; i++)
            {
                Console.WriteLine($"[{i + 1}] Task number: {tasksToDelete[i].TaskNumber}");
                Console.WriteLine($"    Task deadline: {tasksToDelete[i].Deadline.ToString(Homework.DateFormat)}");
                Console.WriteLine($"    Task subject: {tasksToDelete[i].Subject}");
                Console.WriteLine($"    Task description: {tasksToDelete[i].TaskText}");
                Console.WriteLine($"    Task type: {tasksToDelete[i].TaskType}\n" +
                                  $"    Task done: {tasksToDelete[i].done}\n" +
                                  $"    Task expired: {tasksToDelete[i].IsExpired}\n");
                Console.WriteLine();
            }

            Console.Write("Enter the number of the task to delete: ");
            if (int.TryParse(Console.ReadLine(), out int selectedTaskIndex) && selectedTaskIndex >= 1 && selectedTaskIndex <= tasksToDelete.Count)
            {
                // Remove the selected task
                Storage.GetTasks().Remove(tasksToDelete[selectedTaskIndex - 1]);
                Console.WriteLine("Task deleted successfully.");
            }
            else
            {
                Console.WriteLine("Invalid input. Task was not deleted.");
            }
        }

        #region UI

        public void MenuModes()
        {
            Console.Clear();

            Console.WriteLine("" +
                   $"***************************************[Modes menu]***\n" +
                   $" 0 - Create task\n" +
                   $" 1 - Output tasks\n" +
                   $" 2 - Find task\n" +
                   $" 3 - Delete task \n" +
                   $" 4 - Close app \n" +
                   $"*******************************************************");
        }

        public ushort Input(string text, ushort up_range, ushort down_range)
        {
            while (true)
            {
                ushort input;

                try
                {
                    Console.Write(text);
                    input = Byte.Parse(Console.ReadLine());

                    if (input > up_range || input < down_range)
                        throw new Exception($"Value should be in range {down_range}-{up_range}.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"{ex.Message}");
                    continue;
                }
                Console.WriteLine();
                return input;
            }
        }
        public void PressEnter()
        {
            while (true)
            {
                Console.WriteLine("To continiue press Enter...");
                var key = Console.ReadKey(intercept: true);
                if (key.Key == ConsoleKey.Enter)
                {
                    Console.Clear();
                    break; // Выход из цикла, если нажата клавиша Enter
                }
                else Console.WriteLine("Pressed another key");
            }
        }
        #endregion
    }
}