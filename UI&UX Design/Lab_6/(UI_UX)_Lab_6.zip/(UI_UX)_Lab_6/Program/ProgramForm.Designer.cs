﻿namespace _UI_UX_Lab_6
{
    partial class ProgramForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProgramForm));
            Update_button = new Button();
            comboBox_Size = new ComboBox();
            label1 = new Label();
            menuStrip1 = new MenuStrip();
            файлToolStripMenuItem = new ToolStripMenuItem();
            відкритиToolStripMenuItem = new ToolStripMenuItem();
            зберегтиToolStripMenuItem = new ToolStripMenuItem();
            textBox1 = new TextBox();
            contextMenuStrip1 = new ContextMenuStrip(components);
            жирнийToolStripMenuItem = new ToolStripMenuItem();
            курсивToolStripMenuItem = new ToolStripMenuItem();
            моношириннийToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            contextMenuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // Update_button
            // 
            Update_button.Location = new Point(342, 247);
            Update_button.Name = "Update_button";
            Update_button.Size = new Size(123, 29);
            Update_button.TabIndex = 0;
            Update_button.Text = "Оновити зміни";
            Update_button.UseVisualStyleBackColor = true;
            Update_button.Click += Update_button_Click;
            // 
            // comboBox_Size
            // 
            comboBox_Size.FormattingEnabled = true;
            comboBox_Size.Items.AddRange(new object[] { "8", "10", "11", "12", "14", "16", "20" });
            comboBox_Size.Location = new Point(12, 247);
            comboBox_Size.Name = "comboBox_Size";
            comboBox_Size.Size = new Size(139, 28);
            comboBox_Size.TabIndex = 1;
            comboBox_Size.Text = "Оберіть розмір";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(83, 34);
            label1.Name = "label1";
            label1.Size = new Size(327, 40);
            label1.TabIndex = 3;
            label1.Text = "Програма дозволяє відкрити текстовий файл,\r\nзмінити його стиль та розмір\r\n";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { файлToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(490, 28);
            menuStrip1.TabIndex = 4;
            menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            файлToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { відкритиToolStripMenuItem, зберегтиToolStripMenuItem });
            файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            файлToolStripMenuItem.Size = new Size(59, 24);
            файлToolStripMenuItem.Text = "Файл";
            // 
            // відкритиToolStripMenuItem
            // 
            відкритиToolStripMenuItem.Name = "відкритиToolStripMenuItem";
            відкритиToolStripMenuItem.Size = new Size(224, 26);
            відкритиToolStripMenuItem.Text = "Відкрити";
            відкритиToolStripMenuItem.Click += ВідкритиToolStripMenuItem_Click;
            // 
            // зберегтиToolStripMenuItem
            // 
            зберегтиToolStripMenuItem.Name = "зберегтиToolStripMenuItem";
            зберегтиToolStripMenuItem.Size = new Size(224, 26);
            зберегтиToolStripMenuItem.Text = "Зберегти";
            зберегтиToolStripMenuItem.Click += ЗберегтиToolStripMenuItem_Click;
            // 
            // textBox1
            // 
            textBox1.ContextMenuStrip = contextMenuStrip1;
            textBox1.Location = new Point(12, 83);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.ScrollBars = ScrollBars.Vertical;
            textBox1.Size = new Size(466, 146);
            textBox1.TabIndex = 5;
            textBox1.Text = resources.GetString("textBox1.Text");
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.ImageScalingSize = new Size(20, 20);
            contextMenuStrip1.Items.AddRange(new ToolStripItem[] { жирнийToolStripMenuItem, курсивToolStripMenuItem, моношириннийToolStripMenuItem });
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(187, 76);
            // 
            // жирнийToolStripMenuItem
            // 
            жирнийToolStripMenuItem.Font = new Font("Segoe UI Black", 9F, FontStyle.Bold, GraphicsUnit.Point, 204);
            жирнийToolStripMenuItem.Name = "жирнийToolStripMenuItem";
            жирнийToolStripMenuItem.Size = new Size(186, 24);
            жирнийToolStripMenuItem.Text = "Жирний";
            жирнийToolStripMenuItem.Click += жирнийToolStripMenuItem_Click;
            // 
            // курсивToolStripMenuItem
            // 
            курсивToolStripMenuItem.Font = new Font("Segoe UI", 9F, FontStyle.Italic, GraphicsUnit.Point, 204);
            курсивToolStripMenuItem.Name = "курсивToolStripMenuItem";
            курсивToolStripMenuItem.Size = new Size(186, 24);
            курсивToolStripMenuItem.Text = "Курсив";
            курсивToolStripMenuItem.Click += курсивToolStripMenuItem_Click;
            // 
            // моношириннийToolStripMenuItem
            // 
            моношириннийToolStripMenuItem.Font = new Font("Cascadia Mono", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            моношириннийToolStripMenuItem.Name = "моношириннийToolStripMenuItem";
            моношириннийToolStripMenuItem.Size = new Size(186, 24);
            моношириннийToolStripMenuItem.Text = "Моноширинний";
            моношириннийToolStripMenuItem.Click += моношириннийToolStripMenuItem_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(490, 299);
            Controls.Add(textBox1);
            Controls.Add(label1);
            Controls.Add(comboBox_Size);
            Controls.Add(Update_button);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "UI/UX_Lab_6";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            contextMenuStrip1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Update_button;
        private ComboBox comboBox_Size;
        private Label label1;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem файлToolStripMenuItem;
        private ToolStripMenuItem відкритиToolStripMenuItem;
        private ToolStripMenuItem зберегтиToolStripMenuItem;
        private TextBox textBox1;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem жирнийToolStripMenuItem;
        private ToolStripMenuItem курсивToolStripMenuItem;
        private ToolStripMenuItem моношириннийToolStripMenuItem;
    }
}
