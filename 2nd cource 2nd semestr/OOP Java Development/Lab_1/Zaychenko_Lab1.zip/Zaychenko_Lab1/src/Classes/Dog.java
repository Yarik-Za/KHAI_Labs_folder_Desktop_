package Classes;

// властивості та поведінку собаки.
public class Dog extends Animal {
    //Конструктор з параметром ім'я.

    private Gender gen = Gender.UNKNOWN;

    // Другий конструктор з параметрами name, age та gender
    public Dog(String name, int age, Gender gender) {
        super(name, age);
        this.gen = gender;
    }

    public Dog(String name) {
        super(name);
    }

    @Override
    public void setAge(int age) throws IllegalArgumentException {
        if (age > 20) {
            throw new IllegalArgumentException("Вік собаки не може перевищувати 20 років.");
        }
        super.setAge(age); // Виклик сетера базового класу для встановлення віку
    }

    public Gender getGender() {
        return gen;
    }

    public void setGender(Gender Gender) {
        this.gen = Gender;
    }

    // Перевизначення методу toString() для зручного виведення даних
    @Override
    public String toString() {
        return "Dog{" +
                "name='" + getName() + '\'' +
                ", age=" + getAge() +
                ", gender=" + getGender() +
                '}';
    }

    //моделює стрибок собаки.
    public void jump() {
        System.out.println(getName() + " стрибає.");
    }

    //моделює біг собаки.
    public void run() {
        System.out.println(getName() + " бігає.");
    }

    //моделює укус собаки.
    public void bite() {
        System.out.println(getName() + " кусає.");
    }

    // зміна звуку для собаки
    @Override
    public void makeSound() {
        System.out.println("Собака гавкає.");
    }
}


