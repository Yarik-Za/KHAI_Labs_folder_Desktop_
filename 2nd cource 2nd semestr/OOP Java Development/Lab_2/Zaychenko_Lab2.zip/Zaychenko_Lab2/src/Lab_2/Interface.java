package Lab_2;

import Lab_2.Classes.Storages.AbstractStorage;
import Lab_2.Classes.Storages.DriversStorage;
import Lab_2.Classes.Storages.VehiclesStorage;
import Lab_2.Classes.Transport.*;
import Lab_2.Tests;

import java.util.Scanner;

public class Interface {
    Scanner scanner = new Scanner(System.in);
    DriversStorage dl = new DriversStorage();
    VehiclesStorage vl = new VehiclesStorage();


    Driver d5 = new Driver("Petro", "Petrovych", "Petrushenko", 34, dl);
    Driver d6 = new Driver("Maria", "Ivanivna", "Ivanenko", dl);
    Driver d7 = new Driver("Oksana", "Petrovna", "Petrovych", 23, dl);


    public void Menu() {
        while (true) {
            try {
                System.out.println("Меню:");
                System.out.println("1. Показати список об'єктів");
                System.out.println("2. Додати новий об'єкт");
                System.out.println("3. Видалити об'єкт");
                System.out.println("4. Додати водія до транспорту");
                System.out.println("5. Отримати хеш об'єкту");
                System.out.println("6. Порівнняння об'єктів");
                //System.out.println("10. Напівавтоматична перевірка всіх методів підряд");

                System.out.println("0. Вийти з програми");
                //System.out.print("Виберіть пункт меню: ");

                switch (ValidInput("Input your choise: ", 0, 10)) {
                    case 1:
                        showList();
                        break;
                    case 2:
                        addObj();
                        break;
                    case 3:
                        deleteObj();
                        break;
                    case 4:
                        giveDriver();
                        break;
                    case 5:
                        getHashedObj();
                        break;
                    case 6:
                        getComparedObj();
                        break;

                    case 10:
                        //Tests.TestActions();
                        Tests.testInterfaceMethods();
                        break;

                    case 0:
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Невірний вибір. Спробуйте ще раз.");
                        Menu();
                        break;
                }
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }
        }
    }


    public void showList() {
        while (true) {
            System.out.println("Вивести об'єкти на екран:");
            System.out.println("1. Показати список водіїв");
            System.out.println("2. Показати список транспорту");
            System.out.println("3. Повернутись до меню");
            try {
                switch (ValidInput("Input your choise: ", 1, 3)) {
                    case 1:
                        AllObjects(dl);
                        break;
                    case 2:
                        AllObjects(vl);
                        break;
                    case 3:
                        //break;
                        return;

                    default:
                        System.out.println("Невірний вибір. Спробуйте ще раз.");
                        Menu();
                        break;
                }
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }
        }
    }

    public void addObj() {
        while (true) {
            System.out.println("Додавання об'єктів в програму:");
            System.out.println("1. Додати водія");
            System.out.println("2. Додати транспорт");
            System.out.println("3. Повернутись до меню");

            try {
                switch (ValidInput("Input your choise: ", 1, 3)) {
                    case 1:
                        CreateDriver(dl);
                        break;
                    case 2:
                        CreateVehicle(vl);
                        break;
                    case 3:
                        return;

                    default:
                        System.out.println("Невірний вибір. Спробуйте ще раз.");
                        Menu();
                        break;
                }
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }
        }
    }

    public void CreateDriver(AbstractStorage s) {

        System.out.print("Введіть прізвище: ");
        String lastName = scanner.nextLine();

        System.out.print("Введіть ім'я: ");
        String firstName = scanner.nextLine();

        System.out.print("Введіть по батькові: ");
        String middleName = scanner.nextLine();

        int age = ValidInput("Введіть вік: ", 20, 100);

        try {
            Driver driver = new Driver(firstName, lastName, middleName, age, s);
            System.out.println("Новий водій створений: " + driver.getFullInfo());
        } catch (Exception e) {
            System.out.println("Помилка при створенні водія: " + e.getMessage());
        }
    }

    public void CreateVehicle(AbstractStorage s) {

        AbstractPublicTransport vehicle;

        EnumTransportType t = readTransportType();

        System.out.print("Введіть виробника: ");
        String manuf = scanner.nextLine();

        System.out.print("Введіть номер: ");
        String num = scanner.nextLine();

        System.out.print("Введіть першу зупинку маршруту: ");
        String r1 = scanner.nextLine();

        System.out.print("Введіть останню зупинку маршруту: ");
        String r2 = scanner.nextLine();

        System.out.print("Введіть місткість: ");
        int capac = Integer.parseInt(scanner.nextLine());

        switch (t) {
            case BUS:
                vehicle = new Bus(manuf, num, r1, r2, capac, s);
                break;
            case TRAM:
                vehicle = new Tram(manuf, num, r1, r2, capac, s);
                break;
            case TROLLEYBUS:
                vehicle = new TrolleyBus(manuf, num, r1, r2, capac, s);
                break;
            default:
                throw new RuntimeException("Unknown error occurred");

        }
        System.out.println("Створений транспорт: ");
        System.out.println(vehicle.toString());
    }

    // Метод для вибору типу транспорту
    private EnumTransportType readTransportType() {
        System.out.println("Оберіть тип транспорту:");
        System.out.println("1. Автобус");
        System.out.println("2. Трамвай");
        System.out.println("3. Тролейбус");

        switch (ValidInput("Input your choise: ", 1, 3)) {
            case 1:
                return EnumTransportType.BUS;
            case 2:
                return EnumTransportType.TRAM;
            case 3:
                return EnumTransportType.TROLLEYBUS;
            default:
                return EnumTransportType.DEFAULT;
        }
    }

    public void deleteObj() {
        AbstractStorage st;

        System.out.println("Видалення об'єктів в програму:");
        System.out.println("1. Видалити водія");
        System.out.println("2. Видалити транспорт");
        System.out.println("3. Повернутись до меню");

        int s = ValidInput("Input your choise: ", 1, 3);
        switch (s) {
            case 1:
                System.out.println(OutputByIndexes(dl));
                break;
            case 2:
                System.out.println(OutputByIndexes(vl));
                break;
            case 3:
                break;

            default:
                System.out.println("Невірний вибір. Спробуйте ще раз.");
                Menu();
                break;
        }
        switch (s) {
            case 1:
                st = dl;
                break;
            case 2:
                st = vl;
                break;
            default:
                return;
        }

        int ch = ValidInput("Input index of object to delete", 0, (st.getCount() - 1));
        removeObject(st, ch);
    }

    public void giveDriver() {
        System.out.println(OutputByIndexes(dl));
        int d_indx = ValidInput("Input driver`s index to assign to vehicle: ", 0, dl.getCount() - 1);

        Driver drv = (Driver) dl.get(d_indx);

        System.out.println(OutputByIndexes(vl));
        int v_indx = ValidInput("Input vehicle`s index to assign to : ", 0, vl.getCount() - 1);

        AbstractPublicTransport v = (AbstractPublicTransport) vl.get(v_indx);

        setDriver(v, drv);
    }

    public String OutputByIndexes(AbstractStorage s) {
        if (s.getCount() == 0) throw new RuntimeException("List is empty!");
        String str = "";
        for (int i = 0; i < s.getCount(); i++) {
            str += "i=" + i + ": " + s.get(i).toString() + '\n';

        }
        return str;
    }

    // Метод для перевірки, чи введене значення є цілим числом та в межах встановленого діапазону
    public int ValidInput(String inputTxt, int low, int up) {

        System.out.print(inputTxt);
        int input = Integer.MAX_VALUE;
        do {
            input = Integer.parseInt(scanner.nextLine());

            if (input >= low && input <= up) {
                return input;
            } else {
                throw new RuntimeException("Invalid input, try again");
            }
        } while (true);

    }

    // Виводимо повну інформацію
    public static void AllObjects(AbstractStorage s) {
        if (s.getCount() == 0) throw new RuntimeException("Список пустий!");
        if (s instanceof DriversStorage) {
            System.out.println("Drivers list:");
        } else if (s instanceof VehiclesStorage) {
            System.out.println("Vehicles list:");
        }

        System.out.println(s.getFullInformation());

    }

    public static void removeObject(AbstractStorage s, int index) {
        Object removedObject = s.get(index); // Отримати видалений об'єкт
        s.remove(index); // Видалити об'єкт зі списку
        if (s instanceof DriversStorage) {
            Driver rd = (Driver) removedObject;
            System.out.println("Driver removed successfully: " + rd.getFullInfo()); // Вивести інформацію про видаленого водія
        } else if (s instanceof VehiclesStorage) {
            AbstractPublicTransport rv = (AbstractPublicTransport) removedObject;
            System.out.println("Vehicle removed successfully: " + rv); // Вивести інформацію про видалений транспортний засіб
        }
    }

    public static void setDriver(AbstractPublicTransport v, Driver drv) {
        v.assignDriver(drv);
        System.out.println("Driver assignment ok!");
    }

    public void getComparedObj() {
        System.out.println("Оберіть об'єкт:\n1 - Водій\n2-Транспорт");
        AbstractStorage temp = null;
        switch (ValidInput("Оберіть: ", 1, 2)) {
            case 1:
                temp = dl;
                break;
            case 2:
                temp = vl;
                break;
        }
        System.out.println(OutputByIndexes(temp));
        Object obj1 = temp.get(ValidInput("Оберіть індекс першого об'єкту для порівняння: ", 0, temp.getCount() - 1));
        Object obj2 = temp.get(ValidInput("Оберіть індекс другого об'єкту для порівняння: ", 0, temp.getCount() - 1));
        boolean res = CompareObj(obj1, obj2);
        if (res == true) {
            System.out.println("Об'єкти однакові");
        } else {
            System.out.println("Об'єкти різні");
        }

    }

    public static boolean CompareObj(Object o1, Object o2) {
        if (o1 == null || o2 == null) {
            return false; // Если хотя бы один из объектов null, они не равны
        }
        return o1.equals(o2); // Сравниваем содержимое объектов
    }

    public void getHashedObj() {
        System.out.println("Оберіть об'єкт:\n1 - Водій\n2-Транспорт");
        AbstractStorage temp = null;
        switch (ValidInput("Оберіть: ", 1, 2)) {
            case 1:
                temp = dl;
                break;
            case 2:
                temp = vl;
                break;
        }
        System.out.println(OutputByIndexes(temp));
        Object obj = temp.get(ValidInput("Оберіть індекс обєкту для отримання хешу: ", 0, temp.getCount() - 1));
        System.out.println("Об'єкт: " + obj.toString() + " має такий хеш: [" + getHash(obj) + "]");
    }

    public static String getHash(Object o) {
        String hash = Integer.toString(o.hashCode());
        return hash;
    }
}