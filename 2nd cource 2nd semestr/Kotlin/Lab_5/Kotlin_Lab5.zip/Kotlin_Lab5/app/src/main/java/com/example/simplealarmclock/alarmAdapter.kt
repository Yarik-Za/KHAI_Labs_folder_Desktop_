package com.example.simplealarmclock

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AlarmAdapter(private val alarms: List<Alarm>) : RecyclerView.Adapter<AlarmAdapter.AlarmViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlarmViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.alarm_item, parent, false)
        return AlarmViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: AlarmViewHolder, position: Int) {
        val currentAlarm = alarms[position]
        holder.textViewAlarmName.text = currentAlarm.name
        holder.textViewAlarmTime.text = currentAlarm.time
        holder.textViewAlarmStatus.text = when (currentAlarm.status) {
            Alarm.AlarmStatus.ENABLED -> "Ввімкнений"
            Alarm.AlarmStatus.DISABLED -> "Вимкнений"
            Alarm.AlarmStatus.SNOOZED -> "Відкладено"
        }
    }

    override fun getItemCount() = alarms.size

    class AlarmViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textViewAlarmName: TextView = itemView.findViewById(R.id.textViewAlarmName)
        val textViewAlarmTime: TextView = itemView.findViewById(R.id.textViewAlarmTime)
        val textViewAlarmStatus: TextView = itemView.findViewById(R.id.textViewAlarmStatus)
    }
}
