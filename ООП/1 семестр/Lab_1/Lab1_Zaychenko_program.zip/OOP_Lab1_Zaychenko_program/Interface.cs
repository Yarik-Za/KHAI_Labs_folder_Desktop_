﻿using Microsoft.VisualBasic;
using System.Globalization;
using System.Transactions;

namespace Lab_1
{
    internal class Interface
    {
        public int QuantityMax;
        const string DateFormat = "dd-MM-yy";
        int count = 0;


        public void Create()
        {
            TaskType taskType = TaskType.Default;

            #region input
            if (count == QuantityMax) Console.WriteLine("Reached the max quantity of tasks creation");
            else QuantityMax = Input("Enter the quantity of hometasks: ", 10, 1);
            while (count < QuantityMax)
            {
                int taskNumber = Input("Enter task number: ", UInt16.MaxValue, 0);

                Console.Write("Enter deadline in format dd-mm-yy: ");

                DateTime mindeadline = new DateTime(2023, 09, 01);
                DateTime maxdeadline = new DateTime(2024, 12, 31);
                DateTime deadline = maxdeadline;

                bool deadlineIsValid = false;
                while (!deadlineIsValid)
                {
                    string input = Console.ReadLine();
                    Console.WriteLine();
                    DateTime.TryParseExact(input, DateFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out deadline);

                    if (deadline > maxdeadline || deadline < mindeadline)
                    {
                        Console.Write("Invalid date format. Please enter the date in dd-mm-yy format: ");
                        deadlineIsValid = false;
                    }
                    else deadlineIsValid = true;
                }

                string subject = "";
                bool isValidSubj = false;

                while (!isValidSubj)
                {
                    Console.Write("Enter subject: ");
                    subject = Console.ReadLine();

                    if (string.IsNullOrWhiteSpace(subject) || string.IsNullOrEmpty(subject))
                    {
                        Console.WriteLine("Subject cannot be empty. Please try again.");
                        continue;
                    }
                    if (subject.All(c => char.IsLetter(c) || char.IsSymbol(c)))
                        isValidSubj = true;
                    else Console.WriteLine("Invalid characters in the subject. Please use only letters or symbols.");
                }
                Console.WriteLine();

                while (true)
                {
                    Console.WriteLine($"***[Task Types]****************************************\r\n" +
                        $" 0 - Comp \r\n" +
                        $" 1 - Oral \r\n" +
                        $" 2 - Write");

                    Console.WriteLine($"*******************************************************");

                    while (true)
                    {
                        try
                        {
                            //Console.Write("Select task type: ");
                            //byte select = byte.Parse(Console.ReadLine());
                            //if (select >= 3) throw new Exception("Value should be in range 0-2");

                            byte select;
                            select = Convert.ToByte(Input("Select task type: ", 2, 0));
                            switch (select)
                            {
                                case 0: taskType = TaskType.Comp; break;
                                case 1: taskType = TaskType.Oral; break;
                                case 2: taskType = TaskType.Write; break;
                                default: Console.Write("Input error. Try again"); continue;
                            }
                            break;
                        }
                        catch (Exception ex) { Console.WriteLine($"{ex.Message}"); }
                    }
                    break;
                }
                //Console.WriteLine($"*******************************************************");

                Console.Write("Enter task description: ");
                string taskText = Console.ReadLine();
                Console.WriteLine();

                #endregion

                Homework task = new Homework(taskNumber, deadline, subject, taskType, taskText);
                Console.WriteLine("Task created successfuly"); count++;
            }
        }
        public void Output()
        {
            foreach (Homework task in Storage.Tasks)
            {
                Console.WriteLine("" +
                   $"*****************************************[Index: {Storage.Tasks.IndexOf(task)}]***\n" +
                   $" Task number: {task.taskNumber}\n" +
                   $" Task deadline: {task.deadline.ToString(DateFormat)}\n" +
                   $" Task subject: {task.subject}\n" +
                   $" Task description: {task.taskText}\n" +
                   $" Task type: {task.taskType}\n" +
                   $"*******************************************************\n");
            }
        }

        public void Find()
        {
            while (true)
            {
                Console.WriteLine($"Choose search option: \n" +
                    $" 0 - By task number\n" +
                    $" 1 - By deadline\n" +
                    $" 2 - Return to Menu\n");

                Console.Write("Select option: ");
                byte select = byte.Parse(Console.ReadLine());
                if (select >= 3) Console.WriteLine("Value should be in range 0-2");

                switch (select)
                {
                    case 0: FindByNumber(); break;
                    case 1: FindByDeadline(); break;
                    case 2: return;
                }
                break;
            }
        }
        public void FindByNumber()
        {
            Console.Write("Enter task number: ");
            int inputNumber = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine();

            foreach (Homework task in Storage.Tasks)
            {
                if (inputNumber == task.taskNumber)
                {
                    Console.WriteLine("" +
                           $"*****************************************[Index: {Storage.Tasks.IndexOf(task)}]***\n" +
                           $" Task number: {task.taskNumber.ToString()}\n" +
                           $" Task deadline: {task.deadline.ToString(DateFormat)}\n" +
                           $" Task subject: {task.subject}\n" +
                           $" Task description: {task.taskText}\n" +
                           $" Task type: {task.taskType}\n" +
                           $"*******************************************************\n");
                }
            }
        }
        public void FindByDeadline()
        {
            bool inputDateValid = false;
            while (!inputDateValid)
            {
                Console.Write("Enter task deadline (in the format dd-mm-yy): ");
                string inputDateString = Console.ReadLine();
                DateTime inputDate;

                if (DateTime.TryParseExact(inputDateString, DateFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out inputDate))
                {
                    inputDateValid = true;
                }
                else if (!DateTime.TryParseExact(inputDateString, DateFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out inputDate))
                {
                    Console.WriteLine("Invalid date format. Please enter the date in dd-mm-yy format.");
                    return;
                }
                Console.WriteLine();

                foreach (Homework task in Storage.Tasks)
                {
                    if (inputDate == task.deadline)
                    {
                        Console.WriteLine("" +
                               $"*****************************************[Index: {Storage.Tasks.IndexOf(task)}]***\n" +
                               $" Task number: {task.taskNumber}\n" +
                               $" Task deadline: {task.deadline.ToString(DateFormat)}\n" +
                               $" Task subject: {task.subject}\n" +
                               $" Task description: {task.taskText}\n" +
                               $" Task type: {task.taskType}\n" +
                               $"*******************************************************\n");
                    }
                }
            }
        }

        public void Delete()
        {
            while (true)
            {
                Console.WriteLine($"Choose delete option: \n" +
                    $" 0 - By task number\n" +
                    $" 1 - By deadline\n" +
                    $" 2 - Return to Menu\n");

                Console.Write("Select option: ");
                byte select = byte.Parse(Console.ReadLine());
                if (select >= 3) throw new Exception("Value should be in range 0-2");

                switch (select)
                {
                    case 0: DeleteByNumber(); break;
                    case 1: DeleteByDeadline(); break;
                    case 2: return;
                }
                break;
            }
        }
        public void DeleteByNumber()
        {
            bool found = false;
            int inputNumber = Input("Enter task number: ", UInt16.MaxValue, 1);
            Console.WriteLine();

            /*for (int i = Storage.Tasks.Count - 1; i >= 0; i--)
            {
                Homework task = Storage.Tasks[i];

                if (inputNumber == task.taskNumber)
                {
                    found = true;
                    Console.WriteLine("" +
                        $"*****************************************[Index: {i}]***\n" +
                        $" Task number: {task.taskNumber}\n" +
                        $" Task deadline: {task.deadline.ToString(DateFormat)}\n" +
                        $" Task subject: {task.subject}\n" +
                        $" Task description: {task.taskText}\n" +
                        $" Task type: {task.taskType}\n" +
                        $"*******************************************************\n");

                    Storage.Tasks.RemoveAt(i);
                }
            }
            if (!found)
            {
                Console.WriteLine("No tasks found with the specified task number.");
            }
            else
            {
                Console.WriteLine("Task(s) deleted successfully.");
            }*/

            List<Homework> tasksToDelete = new List<Homework>();

            // Find tasks with the same numbers and add them to tasksToDelete list
            for (int i = 0; i < Storage.Tasks.Count; i++)
            {
                Homework task = Storage.Tasks[i];
                if (inputNumber == task.taskNumber)
                {
                    tasksToDelete.Add(task);
                }
            }

            if (tasksToDelete.Count == 0)
            {
                Console.WriteLine("No tasks found with the specified number.");
                return;
            }

            Console.WriteLine("Tasks with the specified number:");
            for (int i = 0; i < tasksToDelete.Count; i++)
            {
                Console.WriteLine($"[{i + 1}] Task number: {tasksToDelete[i].taskNumber}");
                Console.WriteLine($"    Task deadline: {tasksToDelete[i].deadline.ToString(DateFormat)}");
                Console.WriteLine($"    Task subject: {tasksToDelete[i].subject}");
                Console.WriteLine($"    Task description: {tasksToDelete[i].taskText}");
                Console.WriteLine($"    Task type: {tasksToDelete[i].taskType}");
                Console.WriteLine();
            }

            Console.Write("Enter the number of the task to delete: ");
            if (int.TryParse(Console.ReadLine(), out int selectedTaskIndex) && selectedTaskIndex >= 1 && selectedTaskIndex <= tasksToDelete.Count)
            {
                // Remove the selected task
                Storage.Tasks.Remove(tasksToDelete[selectedTaskIndex - 1]);
                Console.WriteLine("Task deleted successfully.");
            }
            else
            {
                Console.WriteLine("Invalid input. Task was not deleted.");
            }
        }

        //public void DeleteByDeadline_noChoise()
        //{
        //    Console.Write("Enter task deadline (in the format dd-MM-yy): ");
        //    string inputDateString = Console.ReadLine();
        //    DateTime inputDate;

        //    if (!DateTime.TryParseExact(inputDateString, DateFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out inputDate))
        //    {
        //        Console.WriteLine("Invalid date format. Please enter the date in dd-MM-yy format.");
        //        return;
        //    }

        //    Console.WriteLine();

        //    for (int i = Storage.Tasks.Count - 1; i >= 0; i--)
        //    {
        //        Homework task = Storage.Tasks[i];
        //        if (inputDate == task.deadline)
        //        {
        //            Console.WriteLine($"*****************************************[Index: {i}]***");
        //            Console.WriteLine($" Task number: {task.taskNumber}");
        //            Console.WriteLine($" Task deadline: {task.deadline.ToString(DateFormat)}");
        //            Console.WriteLine($" Task subject: {task.subject}");
        //            Console.WriteLine($" Task description: {task.taskText}");
        //            Console.WriteLine($" Task type: {task.taskType}");
        //            Console.WriteLine("*******************************************************");

        //            Storage.Tasks.RemoveAt(i);
        //        }
        //    }
        //}

        public void DeleteByDeadline()
        {
            Console.Write("Enter task deadline (in the format dd-MM-yy): ");
            string inputDateString = Console.ReadLine();
            DateTime inputDate;

            if (!DateTime.TryParseExact(inputDateString, DateFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out inputDate))
            {
                Console.WriteLine("Invalid date format. Please enter the date in dd-MM-yy format.");
                return;
            }

            Console.WriteLine();
            List<Homework> tasksToDelete = new List<Homework>();

            // Find tasks with the same deadline and add them to tasksToDelete list
            for (int i = 0; i < Storage.Tasks.Count; i++)
            {
                Homework task = Storage.Tasks[i];
                if (inputDate == task.deadline)
                {
                    tasksToDelete.Add(task);
                }
            }

            if (tasksToDelete.Count == 0)
            {
                Console.WriteLine("No tasks found with the specified deadline.");
                return;
            }

            Console.WriteLine("Tasks with the specified deadline:");
            for (int i = 0; i < tasksToDelete.Count; i++)
            {
                Console.WriteLine($"[{i + 1}] Task number: {tasksToDelete[i].taskNumber}");
                Console.WriteLine($"    Task deadline: {tasksToDelete[i].deadline.ToString(DateFormat)}");
                Console.WriteLine($"    Task subject: {tasksToDelete[i].subject}");
                Console.WriteLine($"    Task description: {tasksToDelete[i].taskText}");
                Console.WriteLine($"    Task type: {tasksToDelete[i].taskType}");
                Console.WriteLine();
            }

            Console.Write("Enter the number of the task to delete: ");
            if (int.TryParse(Console.ReadLine(), out int selectedTaskIndex) && selectedTaskIndex >= 1 && selectedTaskIndex <= tasksToDelete.Count)
            {
                // Remove the selected task
                Storage.Tasks.Remove(tasksToDelete[selectedTaskIndex - 1]);
                Console.WriteLine("Task deleted successfully.");
            }
            else
            {
                Console.WriteLine("Invalid input. Task was not deleted.");
            }
        }

        #region UI

        public void MenuModes()
        {
            Console.Clear();

            Console.WriteLine("" +
                   $"***************************************[Modes menu]***\n" +
                   $" 0 - Create task\n" +
                   $" 1 - Output tasks\n" +
                   $" 2 - Find task\n" +
                   $" 3 - Delete task \n" +
                   $" 4 - Close app \n" +
                   $"*******************************************************");
        }

        public ushort Input(string text, ushort up_range, ushort down_range)
        {
            while (true)
            {
                ushort input;

                try
                {
                    Console.Write(text);
                    input = Byte.Parse(Console.ReadLine());

                    if (input > up_range || input < down_range)
                    {
                        throw new Exception($"Value should be in range {down_range}-{up_range}.");
                        Console.WriteLine();
                    }
                }

                catch (Exception ex)
                {
                    Console.WriteLine($"{ex.Message}");
                    continue;
                }
                Console.WriteLine();
                return input;
            }
        }
        public void PressEnter()
        {
            while (true)
            {
                Console.WriteLine("To continiue press Enter...");
                var key = Console.ReadKey(intercept: true);
                if (key.Key == ConsoleKey.Enter)
                {
                    Console.Clear();
                    break; // Выход из цикла, если нажата клавиша Enter
                }
                else Console.WriteLine("Pressed another key");
            }
        }
        #endregion
    }
}
