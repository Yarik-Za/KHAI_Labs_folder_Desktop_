import kotlin.math.*

class PracticeTask {
    fun Action() {
        println("Введіть початкове та кінцеве значення змінної Х. Якщо початкове значення буде більше за кінцеве - вони обміняються місцями")

        var smallStart = readln().toDouble()
        var BigEnd = readln().toDouble()

        val a = (1..10).random()

        if (BigEnd < smallStart) {
            BigEnd = smallStart.also { smallStart = BigEnd }
            println("Відбувся обмін")
        }

        var x = smallStart

        val step: Double

        var steps: Double = BigEnd - smallStart

        if (steps > 100) {
            step = (BigEnd - smallStart) / 100.0
            steps /= step
        } else step = 1.0

        println("Step = ${step.toInt()}, stepS = ${steps.toInt()}")

        for (i in 1..steps.toInt()) {
            val y = 1.0e5 * (x / 3).pow(2 / 7.0) + 9 / (3 * x / a) + sqrt(cos(x))

            println(
                //"iterator = $i --> x = $x, y = ${String.format("%.3f", y)}"
                "iterator = $i --> x = ${String.format("%.3f", x)}, y = ${String.format("%.3f", y)}"
            )//  Виведення числа з трьома знаками після коми

            x += step
        }
    }
}

// Зайченко Ярослав, Варіант 99, формула: 1.0e5*(x/3).pow(2/7.0) + 9/(3*x/a)+sqrt(cos(x))