package org.example;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        String line="   Hello   My    Name   Is   Olexander    ";
        String toreplace="\\s+";
        line=line.trim();
        line=line.replaceAll(toreplace," ");
        System.out.println(line);
    }
}