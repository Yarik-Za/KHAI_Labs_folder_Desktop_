package org.example;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        String[] array={"asfdla","afdxa","alsmfalla","alsmfalladas"};
        for (int i=array.length-1; i>-1;i--) {
            if((i-1>-1)&&array[i].length()<array[i-1].length()){
                String temp=array[i];
                array[i]=array[i-1];
                array[i-1]=temp;
            }
        }
        for(String line:array)
            System.out.println(line);
    }
}