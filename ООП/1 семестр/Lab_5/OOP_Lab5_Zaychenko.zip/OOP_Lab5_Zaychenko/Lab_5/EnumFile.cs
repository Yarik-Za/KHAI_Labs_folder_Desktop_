﻿using System.ComponentModel;

namespace Lab
{
    public enum TaskType
    {
        Comp,
        Oral,
        Write,
        Default
    };
}
