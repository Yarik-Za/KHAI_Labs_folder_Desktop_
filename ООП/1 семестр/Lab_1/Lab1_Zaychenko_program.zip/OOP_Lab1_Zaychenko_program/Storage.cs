﻿namespace Lab_1
{
    internal static class Storage
    {
        public static List<Homework> Tasks = new List<Homework>();
    }
}
