﻿using System.Globalization;
using System.Threading.Tasks;

namespace Lab_1
{
    public class Homework
    {
        public const string DateFormat = "dd.MM.yy";

        private int taskNumber;
        private DateTime deadline;
        private string subject;
        private TaskType taskType;
        private string taskText;
        public bool done { get; private set; } = false; // автовластивість

        public Homework() { }

        public Homework(int taskNumber, DateTime deadline, string subject, TaskType taskType, string taskText) //конструктор
        {
            this.taskNumber = taskNumber;
            this.deadline = deadline;
            this.subject = subject;
            this.taskType = taskType;
            this.taskText = taskText;
            this.AddToStorage();
        }

        public int TaskNumber
        {
            get { return taskNumber; }
            set
            {
                if (value > 0)
                    taskNumber = value;
                else throw new Exception("This value should be above 0");
            }
        }

        DateTime mindeadline = new DateTime(2023, 09, 01);
        DateTime maxdeadline = new DateTime(2024, 12, 31);
        public DateTime Deadline
        {
            get { return deadline; }
            set
            {
                if (DateTime.TryParseExact(value.ToString(DateFormat), DateFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime parsedDate))
                {
                    if (parsedDate >= mindeadline && parsedDate <= maxdeadline)
                        deadline = parsedDate;
                    else throw new Exception($"Date of deadline should be in range {mindeadline.ToString(DateFormat)} - {maxdeadline.ToString(DateFormat)}.");
                }
                else throw new Exception($"Invalid date format. Please use the '{DateFormat}' for input.");
            }
        }

        public string Subject
        {
            get { return subject; }
            set
            {
                if (string.IsNullOrEmpty(value) || string.IsNullOrWhiteSpace(value))
                    throw new Exception("Subject can`t be empty or contains numbers.");
                else if (value.Any(c => char.IsDigit(c)))
                    throw new Exception("Subject can`t contain numbers.");
                else subject = value;
            }
        }

        public TaskType TaskType
        {
            get { return taskType; }
            set { taskType = value; }
        }

        public string TaskText
        {
            get { return taskText; }
            set { taskText = value; }
        }

        public bool IsExpired
        {
            get { return Deadline < DateTime.Today; }
        }

        public void IsDone()
        {
            if (Deadline < DateTime.Today)
            {
                done = true;
            }
        }

        private void AddToStorage()
        {
            Storage.AddTask(this);
        }

    }
}