﻿using System;

namespace ASD_Lab_1
{
    public class Elem
    {
        public Elem _L, _R;
        public char _inf;

        public Elem(char inf)
        {
            this._inf = inf;
        }
    }

    public class Queue
    {
        Elem _Tail;
        Elem _Head;

        public void EnQueue(char inf)
        {
            Elem temp = new Elem(inf);
            if (_Tail != null)
            {
                _Tail._R = temp;
            }
            temp._L = _Tail;
            _Tail = temp;
            if (_Head == null)
            {
                _Head = _Tail;
            }
        }

        public char DeQueue()
        {
            if (_Head == null)
            {
                throw new InvalidOperationException("The queue is empty.");
            }

            char removedItem = _Head._inf;
            _Head = _Head._R;

            if (_Head != null)
            {
                _Head._L = null;
            }
            else
            {
                _Tail = null;
            }

            return removedItem;
        }


        public char FindMax()
        {
            if (_Head == null)
            {
                throw new InvalidOperationException("The queue is empty.");
            }

            char max = _Head._inf;
            Elem current = _Head;

            while (current != null)
            {
                if (current._inf > max)
                {
                    max = current._inf;
                }
                current = current._R;
            }

            return max;
        }

        public override string ToString()
        {
            string Res = "";
            Elem current = _Head;
            while (current != null)
            {
                Res += current._inf + "\t";
                current = current._R;
            }
            return Res;
        }

        public bool IsEmpty()
        {
            return _Head == null;
        }

        public int Count()
        {
            int count = 0;
            Elem current = _Head;
            while (current != null)
            {
                count++;
                current = current._R;
            }
            return count;
        }
        public char Peek()
        {
            if (_Head == null)
            {
                throw new InvalidOperationException("The queue is empty.");
            }

            return _Head._inf;
        }

    }
}
