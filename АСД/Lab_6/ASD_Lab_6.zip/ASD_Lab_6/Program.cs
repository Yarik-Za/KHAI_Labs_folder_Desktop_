﻿using System.Text;

Console.OutputEncoding = Encoding.UTF8;
Console.InputEncoding = Encoding.UTF8;

Console.WriteLine("Для виходу введіть \"-0\"\n");

while (true)
{
    try
    {
        int length = 0;

        Console.Write("Введіть довжину масиву: ");
        string input = Console.ReadLine();

        if (input == "-0") Environment.Exit(0);

        if (int.TryParse(input, out int temp))
            if (input != null && temp >= 2)
                length = temp;
            else throw new Exception("Помилка введення кількості елементів масиву");
        else throw new Exception("Помилка читання з рядка");

        int[] array = GenerateRandomArray(length);

        // Виведення початкового масиву
        PrintArr("Початковий масив: ", array);

        // Сортування масиву
        BatcherMSort(array, length);

        // Виведення відсортованого масиву
        PrintArr("Відсортований масив: ", array);
        Console.ReadLine();
    }
    catch (Exception ex) { Console.WriteLine(ex.Message); }
}

void PrintArr(string message, int[] array)
{
    Console.WriteLine(message);

    foreach (int el in array)
        Console.Write($"{el} ");
    Console.WriteLine();

}

static int[] GenerateRandomArray(int length)
{
    Random random = new Random();
    int[] array = new int[length];

    for (int i = 0; i < length; i++)
        array[i] = random.Next(1000); // Генеруємо випадкові числа в діапазоні [0, 1000)

    return array;
}

void BatcherMSort(int[] array, int length)
{
    int t = -1;
    int tempLength = length;

    while (tempLength > 0)
    {
        tempLength >>= 1;
        ++t;
    }

    int p0 = 1 << t;
    int p = p0;

    do
    {
        int q = p0;
        int r = 0;
        int d = p;

        while (r == 0 || q != p)
        {
            if (r != 0)
            {
                d = q - p;
                q >>= 1;
            }

            for (int i = 0; i < length - d; ++i)
            {
                if (((i & p) == r) && array[i] > array[i + d])
                {
                    int swap = array[i];
                    array[i] = array[i + d];
                    array[i + d] = swap;
                }
            }

            r = p;
        }

        p >>= 1;
    } while (p > 0);
}
