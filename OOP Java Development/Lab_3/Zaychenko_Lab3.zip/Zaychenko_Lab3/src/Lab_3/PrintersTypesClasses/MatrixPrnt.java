package Lab_3.PrintersTypesClasses;

import Lab_3.*;

// Підклас для матричного принтера
public class MatrixPrnt extends AbstractPrinter implements InkLevelMonitor {

    public MatrixPrnt(String modelType, String paperFormat, double weight, double price, int printSpeed,
                      String mode, String interfaceType, String state) {
        super(modelType, paperFormat, weight, price, printSpeed, mode, interfaceType, state);
        this.reloadInk();
    }

    @Override
    public String print(String document) {
        if(isLowInk()) throw new RuntimeException("Unable to print. Low Ink");
        decreaseInkLevel(document);
        return "..::* " + document + " *::..";
    }

    private double inkLevel;

    @Override
    public String getInkLevel() {
        return inkLevel + "%";
    }

    @Override
    public boolean isLowInk() {
        return inkLevel < 10;

    }

    @Override
    public void decreaseInkLevel(String doc) {
        int SymbCount = doc.length();
        double oneSymbInk=0.1;
        double inkSpend = SymbCount*oneSymbInk;
        inkLevel-=inkSpend;
    }

    @Override
    public void reloadInk() {
        this.inkLevel = 100;
    }
}
