import kotlin.math.*

class PracticeTask {
    fun Action() {
        println("Введіть початкове та кінцеве значення змінної Х. Якщо початкове значення буде більше за кінцеве - вони обміняються місцями")

        var smallStart = ex_input_check("Введіть початкове значення X ")
        var BigEnd = ex_input_check("Введіть кінцеве значення X ")

        val a = (1..10).random()

        if (BigEnd < smallStart) {
            BigEnd = smallStart.also { smallStart = BigEnd }
            println("Відбувся обмін")
        }

        var x = smallStart

        val step: Double

        var steps: Double = BigEnd - smallStart

        if (steps > 100) {
            step = (BigEnd - smallStart) / 100.0
            steps /= step
        } else step = 1.0

        println("Step = ${step.toInt()}, stepS = ${steps.toInt()}")

        val result_arr: Array<DoubleArray> = Array(100) { DoubleArray(2) }

        for (i in 1..steps.toInt()) {

            val y = y_formula(x, a)

            resultsToMatrix(result_arr, i, x, y)

            x += step
        }
        matrix_output(result_arr, steps.toInt())
    }

    fun y_formula(x: Double, random_a: Int) = 1.0e5 * (x / 3).pow(2 / 7.0) + 9 / (3 * x / random_a) + sqrt(cos(x))

    fun resultsToMatrix(resultArray: Array<DoubleArray>, iterator: Int, x: Double, y: Double) {
        resultArray[iterator - 1][0] = x
        resultArray[iterator - 1][1] = y
    }

    fun matrix_output(arr: Array<DoubleArray>, quantity: Int) {
        var count: Int = 0
        for ((index, row) in arr.withIndex()) {
            try {
                print("Step#${index + 1}\t")
                if (!row[1].isNaN()) { // Перевірка, чи не є значення ігрека NaN
                    println("${String.format("%.3f", row[0])}\t${String.format("%.3f", row[1])}")
                    count++
                    if (count >= quantity) return
                } else throw Exception("The Y value is Nan, line was ignored")
            } catch (e: Exception) {
                count++
                println(e.message)
            }
        }
    }

    fun ex_input_check(text: String = "Enter the value: "): Double {
        var in_num: Double = 0.0;
        while (true) {
            print(text)
            try {
                in_num = readln().toDouble()
                break
            } catch (e: NumberFormatException) {
                println("Error: Invalid value entered. Try again.")
            }
        }
        return in_num
    }
}
// Зайченко Ярослав, Варіант 99, формула: 1.0e5*(x/3).pow(2/7.0) + 9/(3*x/a)+sqrt(cos(x))