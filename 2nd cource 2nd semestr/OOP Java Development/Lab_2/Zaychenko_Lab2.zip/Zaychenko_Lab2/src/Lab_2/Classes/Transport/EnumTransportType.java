package Lab_2.Classes.Transport;
public enum EnumTransportType {
    BUS,
    TRAM,
    TROLLEYBUS,
    DEFAULT
}
