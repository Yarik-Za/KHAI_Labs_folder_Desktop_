﻿using System.Text;

namespace ASD_Lab5
{
    internal class Program
    {
        static void Main()
        {
            // Устанавливаем кодировку консоли на UTF-8
            Console.InputEncoding = Encoding.UTF8;
            Console.OutputEncoding = Encoding.UTF8;

            const string menu = ($"Введіть режим створення графу:\n" +
                $"  1 - введення з клавіатури\n" +
                $"  2 - зчитування з файлу graph.txt\n" +
                $"  0 - вихід\n");

            while (true)
            {
                try
                {
                    switch (Input_range(menu + "Оберіть режим: ", 2, 0))
                    {
                        case 0: Environment.Exit(0); break;
                        case 1:
                            Graph.currentEdgeCount = 0;
                            Graph keyboard_graph = new Graph();
                            Console.Write($"Введіть граф у форматі EL (Edge List).\n  - Зв'язок вершин записується через один пробіл\n  - Дуги відокремлюються крапкою з комою.\nГраф: ");
                            string input_keyboard = Console.ReadLine();

                            string[] graph_edges = ParseGraph(input_keyboard);
                            BuildGraph(keyboard_graph, graph_edges);

                            // Виведення внутрішнього представлення графа
                            PrintGraph(keyboard_graph);
                            break;
                        case 2:
                            Graph.currentEdgeCount = 0;
                            Graph file_graph = new Graph();
                            // зчитати граф з файлу
                            string inputFromFile = File.ReadAllText("graph.txt");
                            Console.WriteLine("Вміст файлу:\n" + inputFromFile);

                            string[] graph_edges_file = ParseGraph(inputFromFile);
                            Console.WriteLine("Зчитане подання графу у виді EdgeList (EL):\n" + ToString(graph_edges_file));
                            BuildGraph(file_graph, graph_edges_file);

                            // Виведення внутрішнього представлення графа
                            PrintGraph(file_graph);
                            break;
                    }

                    PressEnter();
                    Console.Clear();
                }
                catch (Exception ex) { Console.WriteLine(ex.Message); PressEnter(); }
            }
        }

        public static string ToString(string[] vector)
        {
            string res = null;
            foreach (var el in vector)
                res += el + ";";

            return res;
        }

        static string[] ParseGraph(string input_EL)
        {
            // Перевірка на порожній ввід
            if (string.IsNullOrWhiteSpace(input_EL))
                throw new Exception("Неправильний ввід.");

            string parced_input = null;

            foreach (var symb in input_EL)
                if (char.IsDigit(symb) || symb == ';' || symb == ' ')
                    parced_input += symb;

            // Розділення вводу на ребра за символом ';'
            string[] edges = parced_input.Split(';', StringSplitOptions.RemoveEmptyEntries);

            return edges;
        }

        static void BuildGraph(Graph graph, string[] edges)
        {
            foreach (string edgeStr in edges)
            {
                // Перевірка на порожній рядок
                if (string.IsNullOrWhiteSpace(edgeStr))
                    throw new Exception("Пустий рядок");


                string edgeStr_Trim = edgeStr.Trim();
                // Розділення ребра на початкову та кінцеву вершину за символом 'White_SPACE'
                string[] vertices = edgeStr_Trim.Split(' ');

                // Перевірка на правильність розділення ребра
                if (vertices.Length != 2)
                {
                    Console.WriteLine($"Помилка розділення рядка {edgeStr} за символом SPACE. Елемент пропущено.");
                    continue; // Пропустить некорректное ребро
                }
                // Перетворення рядків у числа
                if (int.TryParse(vertices[0], out int startValue) && int.TryParse(vertices[1], out int endValue))
                {

                    if (!CountOfVersh(edges))
                        throw new Exception("Граф містить меньше 11 або більше 20 вершин!");

                    Vershyna start = new Vershyna(startValue);
                    Vershyna end = new Vershyna(endValue);
                    Edge edge = new Edge(start, end);

                    // Додавання ребра до графа
                    if (Graph.currentEdgeCount <= 50)
                        graph.AddEdge(edge);
                    else throw new Exception("Граф має більше 50 зв'язків!");
                }
                else Console.WriteLine($"Помилка перетворення рядка {vertices[0]} або {vertices[1]} в число. Рядок пропущено");
            }
        }

        //static bool CountOfVersh(string[] edges)
        //{
        //    bool res = false;

        //    foreach (string el in edges)
        //    {
        //        string trimmedEl = el.Trim();
        //        string[] temp = trimmedEl.Split(' ');
        //        if (Convert.ToInt32(temp[1]) >= 11 && Convert.ToInt32(temp[0]) <= 20)
        //            res = true;
        //    }

        //    return res;
        //}

        static bool CountOfVersh(string[] edges)
        {
            bool res = false;

            foreach (string el in edges)
            {
                string trimmedEl = el.Trim();
                string[] temp = trimmedEl.Split(' ', StringSplitOptions.RemoveEmptyEntries);

                // Перевірка, чи вершини знаходяться в межах від 1 до 20
                if (Convert.ToInt32(temp[0]) < 1 || Convert.ToInt32(temp[0]) > 20 ||
                    Convert.ToInt32(temp[1]) < 1 || Convert.ToInt32(temp[1]) > 20)
                {
                    res = false;
                }

                // Перевірка, чи кількість вершин у ребрах знаходиться в інтервалі від 11 до 20
                if (Convert.ToInt32(temp[0]) >= 11 || Convert.ToInt32(temp[1]) >= 11 ||
                    Convert.ToInt32(temp[0]) <= 20 || Convert.ToInt32(temp[1]) <= 20)
                {
                    res = true;
                }
            }

            return res;
        }

        static void PrintGraph(Graph graph)
        {
            Console.WriteLine("\nВнутрішнє представлення графа:");

            Edge_LinkedList current = graph.Edges;
            while (current != null)
            {
                Console.WriteLine($"{current.Data.Start.inf} -> {current.Data.End.inf}");
                current = current.Next;
            }
        }

        public static void PressEnter()
        {
            while (true)
            {
                Console.WriteLine("To continiue press Enter...");
                var key = Console.ReadKey(intercept: true);
                if (key.Key == ConsoleKey.Enter)
                {
                    Console.Clear();
                    break; // Выход из цикла, если нажата клавиша Enter
                }
                else Console.WriteLine("Pressed another key");
            }
        }

        public static ushort Input_range(string text, ushort up_range, ushort down_range)
        {
            while (true)
            {
                ushort input;

                try
                {
                    Console.Write(text);
                    input = Byte.Parse(Console.ReadLine());

                    if (input > up_range || input < down_range)
                        throw new Exception($"Value should be in range {down_range}-{up_range}.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"{ex.Message}");
                    continue;
                }
                Console.WriteLine();
                return input;
            }
        }
    }
}