package Lab_3.PrintersTypesClasses;

import Lab_3.AbstractPrinter;

public class LEDPrnt extends AbstractPrinter implements DuplexPrinting, InkLevelMonitor {

    public LEDPrnt(String modelType, String paperFormat, double weight, double price, int printSpeed, String mode, String interfaceType, String state) {
        super(modelType, paperFormat, weight, price, printSpeed, mode, interfaceType, state);
        this.reloadInk();
    }

    @Override
    public String print(String document) {
        if(isLowInk()) throw new RuntimeException("Unable to print. Low Ink");
        decreaseInkLevel(document);
        String res ="";
        res+= "◍◍ " + document + " ◍◍";
        if (duplexPrintingEnabled)
            res +=DPrnt(document);
        return res;
    }

    @Override
    public String DPrnt(String doc) {
        String res = "";
        for (int i = doc.length() - 1; i >= 0; i--) {
            res += doc.charAt(i);
        }
        return res;
    }

    private boolean duplexPrintingEnabled = false;

    @Override
    public void enableDuplexPrinting() {
        duplexPrintingEnabled = true;
    }

    private double inkLevel;

    @Override
    public String getInkLevel() {
        return inkLevel + "%";
    }

    @Override
    public boolean isLowInk() {
        return inkLevel < 15;
    }

    @Override
    public void decreaseInkLevel(String doc) {
        int SymbCount = doc.length();
        double oneSymbInk = 0.3;
        double inkSpend = SymbCount * oneSymbInk;
        inkLevel -= inkSpend;
    }

    @Override
    public void reloadInk() {
        inkLevel = 100;
    }
}
