package com.example.simplealarmclock

import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.RadioGroup
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.timepicker.MaterialTimePicker
import com.google.android.material.timepicker.TimeFormat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var setAlarm: Button
    private lateinit var sdf: SimpleDateFormat
    private lateinit var alarmRecyclerView: RecyclerView
    private lateinit var alarmAdapter: AlarmAdapter
    private val alarmList = mutableListOf<Alarm>()

    override fun onCreate(savedInstanceState: Bundle?) {
        this.setTheme(R.style.AppTheme_Overlay)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        setAlarm = findViewById(R.id.addAlarmButton)
        alarmRecyclerView = findViewById(R.id.alarmRecyclerView)
        alarmAdapter = AlarmAdapter(alarmList)
        alarmRecyclerView.adapter = alarmAdapter
        alarmRecyclerView.layoutManager = LinearLayoutManager(this)

//        // Знаходимо RadioGroup і додаємо обробник подій
//        val themeRadioGroup: RadioGroup = findViewById(R.id.themeRadioGroup)
//        themeRadioGroup.setOnCheckedChangeListener { _, checkedId ->
//            when (checkedId) {
//                R.id.themeRadioButton1 -> setThemeAndRecreate(R.style.AppThemeL)
//                R.id.themeRadioButton2 -> setThemeAndRecreate(R.style.AppThemeD)
//                R.id.themeRadioButton3 -> setThemeAndRecreate(R.style.ThemeOverlay_AppTheme_MediumContrastOverlayOrange)
//            }
//        }
//        val themeRadioGroup: RadioGroup = findViewById(R.id.themeRadioGroup)
//
//        themeRadioGroup.setOnCheckedChangeListener { _, checkedId ->
//            if (checkedId == R.id.themeRadioButton1) {
//                setThemeAndRecreate(R.style.AppThemeL)
//            } else if (checkedId == R.id.themeRadioButton2) {
//                setThemeAndRecreate(R.style.AppThemeD)
//            } else if (checkedId == R.id.themeRadioButton3) {
//                setThemeAndRecreate(R.style.ThemeOverlay_AppTheme_MediumContrastOverlayOrange)
//            }
//        }

        setAlarm.setOnClickListener {
            val materialTimePicker = MaterialTimePicker.Builder()
                .setTimeFormat(TimeFormat.CLOCK_24H)
                .setHour(12)
                .setMinute(0)
                .setTitleText("Оберіть час для будильника")
                .build()
            materialTimePicker.addOnPositiveButtonClickListener {
                val calendar = Calendar.getInstance().apply {
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                    set(Calendar.MINUTE, materialTimePicker.minute)
                    set(Calendar.HOUR_OF_DAY, materialTimePicker.hour)
                }
                val alarmName = "Будильник ${alarmList.size + 1}" // Генерируем имя будильника
                val alarmTime = sdf.format(calendar.time) // Получаем время в формате HH:mm
                // Добавляем новый будильник в список с начальным статусом "Включен"
                alarmList.add(Alarm(alarmName, alarmTime, Alarm.AlarmStatus.ENABLED))
                alarmAdapter.notifyDataSetChanged()
                val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val alarmClockInfo = AlarmManager.AlarmClockInfo(
                    calendar.timeInMillis,
                    getAlarmInfoPendingIntent(alarmList.size - 1) // Вставляем индекс сюда
                )
                alarmManager.setAlarmClock(alarmClockInfo, getAlarmActionPendingIntent())
                // Показываем уведомление
                Toast.makeText(this, "Будильник встановлено на $alarmTime", Toast.LENGTH_SHORT).show()
            }
            materialTimePicker.show(supportFragmentManager, "tag_picker")
        }
    }

    private fun getAlarmInfoPendingIntent(alarmIndex: Int): PendingIntent {
        val alarmInfoIntent = Intent(this, AlarmActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
            putExtra("alarmIndex", alarmIndex) // Добавляем индекс в Intent
        }
        return PendingIntent.getActivity(this, alarmIndex, alarmInfoIntent, PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun getAlarmActionPendingIntent(): PendingIntent {
        val intent = Intent(this, AlarmActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return PendingIntent.getActivity(this, 1, intent, PendingIntent.FLAG_UPDATE_CURRENT)
    }

//    private fun setThemeAndRecreate(themeId: Int) {
//        setTheme(themeId)
//        recreate()
//    }

}

