package Classes;

//властивості та поведінкa цуценяти.

public class Puppy extends Dog {
    private String color;
    public Puppy(String name)
    {
        super(name);
    }
    // Конструктор з параметрами ім'я, вік, колір та стать
    public Puppy(String name, int age, String color, Gender gender) {
        super(name, age, gender);
        this.color = color;
    }

    // Конструктор з параметрами ім'я та вік (колір і стать встановлюються за замовчуванням)
    public Puppy(String name, int age) {
        super(name, age, Gender.UNKNOWN);
        this.color = "Невідомий";
    }


    // Метод для отримання інформації про ім'я та колір цуценяти
    public String getInfo() {
       String result = ("Цуценя має ім'я: " + getName() +", йому "+getAge()+" років, "+" колір: " + color + " стать:"+getGender().toString());
       return result;
    }

    public void askName() {
        System.out.println( "Цуценя має ім'я: " + super.getName());
    }

    @Override
    public void makeSound() {
        System.out.println(super.getName() +" скиглить");
    }
}

