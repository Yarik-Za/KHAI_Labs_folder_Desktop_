﻿using System;
using System.Globalization;
using System.Threading.Tasks;

namespace Lab_1
{
    public class Homework
    {
        public const string DateFormat = "dd.MM.yy";

        private int taskNumber;
        private DateTime deadline;
        private string subject;
        private TaskType taskType;
        private string taskText;
        public bool done { get; private set; } = false; // автовластивість

        #region Constructors_Lab2
        //public Homework() { } // конструктор за замовчуванням

        //public Homework(int taskNumber, DateTime deadline, string subject, TaskType taskType, string taskText) //конструктор зі всіма полями
        //{
        //    this.taskNumber = taskNumber;
        //    this.deadline = deadline;
        //    this.subject = subject;
        //    this.taskType = taskType;
        //    this.taskText = taskText;
        //    this.AddToStorage();
        //}
        #endregion

        #region Constructors_Lab3
        public Homework() // без параметрів
        {
            this.taskNumber = 0;
            this.deadline = DateTime.Today;
            this.subject = "no_subj";
            this.taskType = TaskType.Default;
            this.taskText = "nothing ¯\\_(ツ)_/¯";
            this.DoTask();
            //this.AddToStorage();
        }

        //конструктор, який викликає інший конструктор класу
        public Homework(int taskNumber, DateTime deadline, string subject, TaskType taskType, string taskText)
        : this()
        {
            this.taskNumber = taskNumber;
            this.deadline = deadline;
            this.subject = subject;
            this.taskType = taskType;
            this.taskText = taskText;
            
            this.DoTask();
            this.AddToStorage();
        }

        //конструктор тільки з текстом завдання
        public Homework(string taskText)
        : this(GenerateDefaultTaskNumber(), DateTime.Today, "---", TaskType.Default, taskText)
        {
            this.done = false;
            this.taskText = taskText;
        }

        private static int GenerateDefaultTaskNumber()
        {
            int max_num = -1;

            for (int i = 0; i < Storage.GetTasks().Count; i++)
            {
                Homework tsk = Storage.GetTasks()[i];
                if (max_num < tsk.TaskNumber)
                    max_num = tsk.TaskNumber;
            }
            return max_num + 1;
        }
        #endregion

        public int TaskNumber
        {
            get { return taskNumber; }
            set
            {
                if (value > 0)
                    taskNumber = value;
                else throw new Exception("This value should be above 0");
            }
        }

        DateTime mindeadline = new DateTime(2023, 09, 01);
        DateTime maxdeadline = new DateTime(2024, 12, 31);
        public DateTime Deadline
        {
            get { return deadline; }
            set
            {
                if (DateTime.TryParseExact(value.ToString(DateFormat), DateFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime parsedDate))
                {
                    if (parsedDate >= mindeadline && parsedDate <= maxdeadline)
                        deadline = parsedDate;
                    else throw new Exception($"Date of deadline should be in range {mindeadline.ToString(DateFormat)} - {maxdeadline.ToString(DateFormat)}.");
                }
                else throw new Exception($"Invalid date format. Please use the '{DateFormat}' for input.");
            }
        }

        public string Subject
        {
            get { return subject; }
            set
            {
                if (string.IsNullOrEmpty(value) || string.IsNullOrWhiteSpace(value))
                    throw new Exception("Subject can`t be empty.");
                else if (value.Any(c => char.IsDigit(c)))
                    throw new Exception("Subject can`t contain numbers.");
                else subject = value;
            }
        }

        public TaskType TaskType
        {
            get { return taskType; }
            set { taskType = value; }
        }

        public string TaskText
        {
            get { return taskText; }
            set { taskText = value; }
        }

        public bool IsExpired
        {
            get { return Deadline < DateTime.Today; }
        }

        #region overloaded_methods

        public void DoTask()// Реалізація методу без параметрів
        {
            if (Deadline < DateTime.Today)
            {
                done = true;
            }
        }

        public void DoTask(int nuber_of_tsk)// Реалізація методу з параметром номеру завдання
        {
            if (this.TaskNumber == nuber_of_tsk)
                this.done = true;
        }

        public bool DoTask(string subj)// Реалізація методу з параметром предмету
        {
            if (this.Subject == subj)
            {
                this.done = true;
                return true;
            }
            else return false;
        }

        public bool DoTask(DateTime date)// Реалізація методу з параметром терміну виконання
        {
            if (this.Deadline == date)
            {
                this.done = true;
                return true;
            }
             else return false;
        }
        #endregion

        private void AddToStorage()
        {
            Storage.AddTask(this);
        }
    }
}