package org.example;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        String line="asldasfajsfnkansfapsmkpamfka";
        String result="";
        for(int i=2; i<line.length();i+=3){
            result+=line.charAt(i)+ " ";
        }
        System.out.println(result);
    }
}