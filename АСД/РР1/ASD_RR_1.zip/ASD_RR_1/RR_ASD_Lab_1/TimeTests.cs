﻿namespace ASD_Lab_1
{
    public class TimeTests
    {
        private static System.Diagnostics.Stopwatch watch = new System.Diagnostics.Stopwatch();

        public static void PerformSQueueOperations<T>(T queue, int count)
        {
            EnqueueEl(queue, count);
            DequeueEl(queue, count);
        }

        private static void EnqueueEl<T>(T queue, int count)
        {

            watch.Restart();
            for (int i = 0; i < count; i++)
            {
                dynamic dynamicQueue = queue;
                dynamicQueue.Enqueue(new KeyValue { Key = i, Value = (char)('A' + i % 26) });
            }
            watch.Stop();
            Console.WriteLine($"Час додавання {count} елементів у {GetQueueTypeName(queue)} чергу: {watch.ElapsedTicks} одиниць");
        }

        private static void DequeueEl<T>(T queue, int count)
        {
            watch.Restart();
            for (int i = 0; i < count; i++)
            {
                dynamic dynamicQueue = queue;
                dynamicQueue.Dequeue();
            }
            watch.Stop();
            Console.WriteLine($"Час видалення {count} елементів у {GetQueueTypeName(queue)} чергу: {watch.ElapsedTicks} одиниць");
        }

        public static void PerformMyQueueOperations(MyQueue queue, int count)
        {
            EnQueueT(queue, count);
            DeQueueT(queue, count);
        }
        private static void EnQueueT(MyQueue queue, int count)
        {
            watch.Restart();
            for (int i = 0; i < count; i++)

                queue.EnQueue(new KeyValue { Key = i, Value = (char)('A' + i % 26) });

            watch.Stop();
            Console.WriteLine($"Час додавання {count} елементів у власну написану чергу: {watch.ElapsedTicks} одиниць");
        }

        private static void DeQueueT(MyQueue queue, int count)
        {
            watch.Restart();
            for (int i = 0; i < count; i++)

                queue.DeQueue();

            watch.Stop();
            Console.WriteLine($"Час видалення {count} елементів у власну написану чергу: {watch.ElapsedTicks} одиниць");
        }

        private static string GetQueueTypeName<T>(T queue)
        {
            Type type = queue.GetType();

            if (type.IsGenericType)
                return "узагальнену";
            else return "неузагальнену";
        }
    }
}