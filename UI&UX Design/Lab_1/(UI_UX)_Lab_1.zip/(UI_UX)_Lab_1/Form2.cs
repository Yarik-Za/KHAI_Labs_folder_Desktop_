﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _UI_UX__Lab_1
{
    public partial class FormWithLogo : Form
    {

        public FormWithLogo()
        {
            InitializeComponent();
            timer1.Start();
        }

        int sec = 0;
        Main_Form f1;
        public void SetMainForm(Main_Form mainForm)
        {
            f1 = mainForm;
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            sec++;
            if (sec == 10)
            {
               
                timer1.Stop();
                this.Close();
                f1.Show();
            }
        }
    }
}
