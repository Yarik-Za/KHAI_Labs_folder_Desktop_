﻿namespace Lab_1
{
    public class Homework
    {
        public int taskNumber;
        public DateTime deadline;
        public string subject;
        public TaskType taskType;
        public string taskText;

        public Homework(int taskNumber, DateTime deadline, string subject, TaskType taskType, string taskText)
        {
            this.taskNumber = taskNumber;
            this.deadline = deadline;
            this.subject = subject;
            this.taskType = taskType;
            this.taskText = taskText;

            Storage.Tasks.Add(this);
        }
    }
}
