package Lab_2.Classes.Transport;

import Lab_2.Classes.Storages.AbstractStorage;

public class Driver {
    protected int years;
    private final String[] fullName = new String[3];

    public Driver(String name, String secondName, String middleName, AbstractStorage storage) {
        this(name, secondName, middleName, 0, storage);
    }

    // Конструктор з чотири параметри
    public Driver(String name, String secondName, String middleName, int age, AbstractStorage storage) {
        this.fullName[0] = secondName;
        this.fullName[1] = name;
        this.fullName[2] = middleName;
        try {
            setAge(age);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        storage.add(this);
    }



    private void setAge(int age) throws Exception {
        if (age == 0 )
            this.years = age;
        else if (age < 20 || age > 100)
            throw new Exception("Invalid age parameters");
        else this.years = age;
    }

    public int getAge() throws Exception {
        if (this.years != 0)
            return this.years;
        else
            throw new Exception("Age haven`t been set");
    }

    public String getFullInfo() {
        if (this.years == 0) {
            return this.toString();
        } else return this.toString() + ", Years: " + this.years;
    }

    @Override
    public String toString() {
        return String.join(" ", this.fullName);
    }
}
