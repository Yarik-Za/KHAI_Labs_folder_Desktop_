package org.example;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        String line1="masdannwkdm";
        String line2="f as famsklfm";
        int bigger=1;
        int count= (line1.length()-line2.length());
        if(count<0)
        {
            count*=-1;
            bigger=2;
        }
        for(int i=0; i<count; i++){
            if(bigger==1){
                System.out.println(line1);
            }
            else
                System.out.println(line2);
        }
    }
}