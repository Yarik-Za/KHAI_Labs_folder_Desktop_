﻿using System.Threading.Tasks;

namespace Lab_1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //debug list
            //var homework1 = new Homework(1, DateTime.Parse("2023-10-10"), "Math", TaskType.Comp, "Solve equations");
            //var homework2 = new Homework(2, DateTime.Parse("2023-10-12"), "History", TaskType.Oral, "Prepare a presentation");
            //var homework3 = new Homework(3, DateTime.Parse("2023-10-15"), "English", TaskType.Write, "Write an essay");
            //var homework4 = new Homework(4, DateTime.Parse("2023-10-17"), "Science", TaskType.Default, "Read a chapter");
            //var homework5 = new Homework(5, DateTime.Parse("2023-10-20"), "Art", TaskType.Oral, "Discuss an artwork");

            var homework1 = new Homework(1, DateTime.Parse("2023-10-10"), "Math", TaskType.Write, "Solve equations");
            var homework3 = new Homework(2, DateTime.Parse("2023-10-15"), "English", TaskType.Oral, "Write an essay");

            Interface ui = new();
            
            ui.QuantityMax = 5;

            while (true)
            {
                ui.MenuModes();
                switch (ui.Input("Enter choise: ", 5, 0))
                {
                    case 0: ui.Create(); ui.PressEnter(); break;
                    case 1: ui.Output(); ui.PressEnter(); break;
                    case 2: ui.Find(); ui.PressEnter(); break;
                    case 3: ui.Delete(); ui.PressEnter(); break;
                    case 4: Environment.Exit(0); ui.PressEnter(); break;
                }
            }
        }
    }
}

