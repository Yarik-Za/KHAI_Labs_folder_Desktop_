package Lab_2.Classes.Storages;

import java.util.ArrayList;

public abstract class AbstractStorage {
    protected ArrayList<Object> list = new ArrayList<>();

    // Метод для додавання об'єкта в список
    public void add(Object item) {
        list.add(item);
    }

    // Метод для видалення об'єкта зі списку
    public void remove(int index) {
        list.remove(index);
    }

    // Метод для отримання об'єкта за індексом
    public Object get(int index) {
        return list.get(index);
    }

    public int getCount() {
        int counter = 0;
        for (Object o : list) {
            counter++;
        }
        return counter;
    }

    // Абстрактний метод, який потрібно реалізувати в підкласах
    public abstract String getFullInformation();

}
