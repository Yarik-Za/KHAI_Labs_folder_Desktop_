document.addEventListener('DOMContentLoaded', () => {
    let remainingTime = parseInt(document.getElementById('timer').getAttribute('data-remaining-time'), 10);

    function updateTimer() {
        if (remainingTime <= 0) {
            location.reload(); // Перезагрузка страницы после истечения времени
            return;
        }

        const minutes = Math.floor(remainingTime / 60);
        const seconds = remainingTime % 60;

        document.getElementById('timer').textContent = `${minutes} хв ${seconds} сек`;
        remainingTime--;
    }

    updateTimer();
    setInterval(updateTimer, 1000);
});
