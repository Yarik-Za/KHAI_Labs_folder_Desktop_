package org.example;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        String line="sk1 123  sda 12";
        int count=0;
        for(int i=0; i<line.length();i++){
            if(Character.isDigit(line.charAt(i))){
                count++;
            }
        }
        System.out.println(count);
    }
}