package org.example;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        String line="dajbwdnawmfaos";
        System.out.println(line);
        char[] array;
        array=line.toCharArray();
        for (int i=1; i<array.length;i+=2){
            if(line.charAt(i)=='a'||line.charAt(i)=='b'){
                array[i]='c';
                continue;
            }
            else{
                array[i]='a';
            }
        }
        line="";
        for (char c:array) {
            line+=c;
        }
        System.out.println(line);
    }
}