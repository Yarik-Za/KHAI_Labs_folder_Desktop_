﻿using System.Linq.Expressions;
using System.Text;

namespace ASD_Lab_4
{
    internal class Program
    {
        static void Main(string[] args)
        {

            // Устанавливаем кодировку консоли на UTF-8
            Console.InputEncoding = Encoding.UTF8;
            Console.OutputEncoding = Encoding.UTF8;

            Tree myTree = null;
            string Menu = "1 Початкова ініціалізація дерева\n" +
                            "2 Перевірка дерева на пустоту\n" +
                            "3 Додавання вузла дерева (нового нащадка)\n" +
                            "4 Видалення вузла дерева\n" +
                            "5 Пошук вузла в дереві\n" +
                            "6 Виведення дерева на екран\n" +
                            "7 Ініціалізувати ціле дерево за варіантом\n" +
                            "0 Вихід";

            while (true)
            {
                try
                {
                    Console.WriteLine(Menu);
                    switch (Input_range("Оберіть операцію: ", 7, 0))
                    {
                        case 0: Environment.Exit(0); break;
                        case 1:
                            Console.WriteLine("Введіть корінь дерева");
                            string korin = Console.ReadLine();
                            myTree = new Tree(korin);
                            Console.WriteLine($"Корінь дерева {myTree.T.inf} створено успішно"); PressEnter();
                            break;
                        case 2:
                            if (myTree == null) { Console.WriteLine("Дерево не існує."); PressEnter(); break; }

                            if (myTree.TreeExists()) Console.WriteLine("Дерево існує.");
                            else Console.WriteLine("Дерево не існує."); PressEnter(); break;
                        case 3:
                            Console.WriteLine("Введіть інформацію для нового елементу:");
                            string info = Console.ReadLine();

                            Console.WriteLine("Виберіть батьківський елемент:");
                            string parentInfo = Console.ReadLine();

                            Console.WriteLine("Виберіть напрям для нового елементу (L - ліво, R - право):");
                            char direction;

                            if (!char.TryParse(Console.ReadLine().ToUpper(), out direction) || (direction != 'L' && direction != 'R'))
                                Console.WriteLine("Введіть коректне значення для напряму (L або R).");

                            ElTree parentNode = myTree.Find(myTree.T, parentInfo);

                            if (parentNode == null)
                                Console.WriteLine($"Батьківський елемент з інформацією '{parentInfo}' не знайдений.");

                            if (myTree.Add(parentNode, info, direction))
                                Console.WriteLine($"Елемент з інформацією '{info}' доданий до дерева.");
                            else
                                Console.WriteLine("Додавання не вдалося. Можливо, елемент вже існує або напрям вже зайнятий.");
                            PressEnter(); break;
                        case 4:
                            Console.WriteLine("Введіть інформацію з елементу дерева для видалення");
                            string del_el = Console.ReadLine();
                            if (myTree.Remove(ref myTree.T, del_el))
                                Console.WriteLine($"Видалення {del_el} успішно!");
                            else Console.WriteLine("Елемент не був видалений!");
                            PressEnter(); break;
                        case 5:
                            Console.WriteLine("Введіть інформацію з елементу дерева для пошуку");
                            string find_el = Console.ReadLine();
                            ElTree el = myTree.Find(myTree.T, find_el);

                            if (el != null)
                            {
                                ElTree el_father = myTree.Find_Father(myTree.T, el.inf);
                                Console.WriteLine($"Eлемент {el.inf} знайдено успішно! Батько: {el_father?.inf ?? "Немає батька"} ");
                            }
                            else Console.WriteLine("Елемент не було знайдено");

                            PressEnter(); break;
                        case 6:
                            string res = "";
                            myTree.TreeInString(myTree.T, ref res);
                            Console.WriteLine("Дерево -> " + res);
                            PressEnter(); break;
                        case 7:
                            myTree = Initalized_tree();
                            Console.WriteLine("Process OK!");
                            PressEnter(); break;
                    }
                }
                catch (Exception ex) { Console.WriteLine(ex.Message); }
            }

            #region debug-first-version
            //ElTree temp = myTree.T;
            //string res = "";
            //myTree.TreeInString(temp, ref res);
            //Console.WriteLine("Tree information -> " + res);

            //ElTree el = myTree.Find(myTree.T, "Підрозділ 1");
            //if (el != null) Console.WriteLine("Element was found succesfully!");
            //else Console.WriteLine("Element was NOT found!");

            //ElTree el_Father = myTree.Find_Father(myTree.T, "Відділ реклами");
            //if (el_Father != null) Console.WriteLine("Father element was found succesfully! It`s " + el_Father.inf);
            //else Console.WriteLine("Father element was NOT found!");

            //if (myTree.Remove(ref myTree.T, "Відділ інвестицій"))
            //    Console.WriteLine("Element was found succesfully!");
            //else Console.WriteLine("Element was NOT found!");

            //if (myTree.Remove(ref myTree.T, "Підрозділ 3"))
            //    Console.WriteLine("Element was removed succesfully!");
            //else Console.WriteLine("Element was NOT removed!");

            //res = "";
            //myTree.TreeInString(myTree.T, ref res);
            //Console.WriteLine("Tree information -> " + res);
            //Console.ReadLine();
            #endregion

        }

        public static Tree Initalized_tree()
        {
            Tree myTr = new Tree("Керівник"); //створюємо кореневий елемент

            ElTree temp = myTr.T;

            myTr.Add(temp, "Підрозділ 1", 'L');
            temp = temp.L;
            myTr.Add(temp, "Відділ виробництва", 'L');
            myTr.Add(temp, "Підрозділ 2", 'R');

            temp = temp.L;
            myTr.Add(temp, "Відділ якості", 'R');
            temp = temp.R;
            myTr.Add(temp, "Відділ безпеки", 'R');

            temp = myTr.T.L.R;
            myTr.Add(temp, "Відділ маркетингу", 'L');
            myTr.Add(temp, "Підрозділ 3", 'R');

            temp = temp.L;
            myTr.Add(temp, "Відділ продажів", 'R');
            temp = temp.R;
            myTr.Add(temp, "Відділ реклами", 'R');

            temp = myTr.T.L.R.R;
            myTr.Add(temp, "Відділ фінансів", 'L');
            temp = temp.L;
            myTr.Add(temp, "Відділ бухгалтерії", 'R');
            temp = temp.R;
            myTr.Add(temp, "Відділ інвестицій", 'R');

            return myTr;
        }

        public static ushort Input_range(string text, ushort up_range, ushort down_range)
        {
            while (true)
            {
                ushort input;

                try
                {
                    Console.Write(text);
                    input = Byte.Parse(Console.ReadLine());

                    if (input > up_range || input < down_range)
                        throw new Exception($"Value should be in range {down_range}-{up_range}.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"{ex.Message}");
                    continue;
                }
                Console.WriteLine();
                return input;
            }
        }

        public static void PressEnter()
        {
            while (true)
            {
                Console.WriteLine("To continiue press Enter...");
                var key = Console.ReadKey(intercept: true);
                if (key.Key == ConsoleKey.Enter)
                {
                    Console.Clear();
                    break; // Выход из цикла, если нажата клавиша Enter
                }
                else Console.WriteLine("Pressed another key");
            }
        }

        #region reference
        /*
         
              - Начальник(Керівник)

        - Підрозділ 1
          - Відділ виробництва
          - Відділ якості
          - Відділ безпеки
        - Підрозділ 2
          - Відділ маркетингу
          - Відділ продажів
          - Відділ реклами
        - Підрозділ 3
          - Відділ фінансів
          - Відділ бухгалтерії
          - Відділ інвестицій
        
                      Керівник
                    /    |     \
                  П1     П2     П3
                 /|\    /|\     /|\
                В Я Б  М П Р   Ф Б І

        */
        #endregion

    }
}