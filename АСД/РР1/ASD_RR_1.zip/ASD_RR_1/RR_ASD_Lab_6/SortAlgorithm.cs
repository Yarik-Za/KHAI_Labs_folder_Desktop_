﻿namespace ASD_RR1
{
    public static class SortAlgorithm
    {
        public static void MSort(KeyValue[] array)
        {
            int iteration = 1;

            int N = array.Length;
            int t = (int)Math.Ceiling(Math.Log2(N));
            int p = (int)Math.Pow(2, t - 1); // початкова установка p   M1

            Console.WriteLine($"\nПочаткове встановлення M1: p = {p}");

            do
            {
                Console.WriteLine($"\nІтерація: {iteration}");

                int q = (int)Math.Pow(2, t - 1); // початкова установка q, r, d   M2
                int r = 0;
                int d = p;

                do
                {
                    Console.WriteLine($"M2: q = {q}, r = {r}, d = {d}");

                    for (int i = 0; i <= N - d - 1; i++) // цикл по i   M3
                    {
                        Console.WriteLine($"M3: i = {i}");

                        if (i + d < N && i < N - d && array[i].Key > array[i + d].Key && ((i & p) == r)) // порівняння\обмін елементів масиву   M4
                        {
                            Console.WriteLine($"M4: Обмін {array[i].Key} <-> {array[i + d].Key}");
                            KeyValue temp_swap = array[i];
                            array[i] = array[i + d];
                            array[i + d] = temp_swap;

                            UI.PrintColorArr("Результат перестановки:", array, i, i + d);
                        }
                        else Console.WriteLine($"M4: Обмін не потрібний {array[i].Key} < {array[i + d].Key}");
                    }

                    if (q != p)
                    {
                        d = q - p;
                        q /= 2;
                        r = p;
                    }
                    else
                    {
                        Console.WriteLine($"M5: Вихід з циклу, оскільки q == p ({q}={p})");
                        break; // вихід з циклу, якщо q=p
                    }
                } while (q > 0);// цикл по q   M5

                p /= 2;
                Console.WriteLine($"M6: p = {p}");
                iteration++;
            } while (p > 0);// цикл по p   M6
        }
    }
}
