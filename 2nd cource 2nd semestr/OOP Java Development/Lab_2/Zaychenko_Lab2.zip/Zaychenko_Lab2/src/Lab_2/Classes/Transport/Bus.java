package Lab_2.Classes.Transport;
import Lab_2.Classes.Storages.AbstractStorage;

import java.util.Arrays;
import java.util.Objects;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class Bus extends AbstractPublicTransport {
    public Bus(String manufacturer, String number, String route_start, String route_end, int capacity, AbstractStorage storage) {

        super(EnumTransportType.BUS, "", manufacturer, number, route_start, route_end, capacity);
       assignModel();
       storage.add(this);
    }

    @Override
    public void assignDriver(Driver driver) {
        this.driver=driver;
    }

    @Override
    public void assignModel() {
        // Створюємо рандомну цифру в діапазоні від 11 до 99
        int randomNumber = ThreadLocalRandom.current().nextInt(11, 100);

        // Створюємо рандомний рядок з латинських символів (a-z) довжиною 2 символи
        StringBuilder randomLetters = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 2; i++) {
            char letter = (char) ('a' + random.nextInt(26));
            randomLetters.append(letter);
        }

        String model = "BS-" + randomNumber + randomLetters.toString();

        this.modelType=model;
    }

    // Перевизначення методу equals()
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Bus bus = (Bus) o;
        return Objects.equals(this.type, bus.type) &&
                Objects.equals(this.modelType, bus.modelType) &&
                Objects.equals(this.manufacturer, bus.manufacturer) &&
                Objects.equals(this.number, bus.number) &&
                Arrays.equals(this.route, bus.route) &&
                this.capacity == bus.capacity &&
                Objects.equals(this.driver, bus.driver) &&
                Objects.equals(this.stopped, bus.stopped);
    }

    // Перевизначення методу hashCode()
    @Override
    public int hashCode() {
        return Objects.hash(this.type, this.modelType, this.manufacturer, this.number, Arrays.hashCode(this.route), this.capacity, this.driver, this.stopped);
    }


}
