<?php

function generateSquares($n) {
    echo "<!DOCTYPE html>";
    echo "<html lang='en'>";
    echo "<head>";
    echo "<meta charset='UTF-8'>";
    echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
    echo "<style>";
    echo "body { background-color: black; margin: 0; padding: 0; overflow: hidden; }";
    echo ".square { position: absolute; background-color: red; }";
    echo "</style>";
    echo "<title>Random Squares</title>";
    echo "</head>";
    echo "<body>";

    echo "<script>";
    echo "const n = $n;"; // кількість квадратів
    echo "for (let i = 0; i < n; i++) {";
    echo "  const square = document.createElement('div');";
    echo "  const size = Math.floor(Math.random() * 100) + 20;"; // випадковий розмір від 20 до 120 пікселів
    echo "  const x = Math.floor(Math.random() * window.innerWidth);"; // випадкова позиція по осі X
    echo "  const y = Math.floor(Math.random() * window.innerHeight);"; // випадкова позиція по осі Y
    echo "  square.style.width = size + 'px';";
    echo "  square.style.height = size + 'px';";
    echo "  square.style.left = x + 'px';";
    echo "  square.style.top = y + 'px';";
    echo "  square.classList.add('square');";
    echo "  document.body.appendChild(square);";
    echo "}";
    echo "</script>";

    echo "</body>";
    echo "</html>";
}

generateSquares(10);

?>
