package Lab_3.PrintersTypesClasses;

import Lab_3.AbstractPrinter;

public class InkjetPrnt extends AbstractPrinter implements InkLevelMonitor{
    public InkjetPrnt(String modelType, String paperFormat, double weight, double price, int printSpeed, String mode, String interfaceType, String state) {
        super(modelType, paperFormat, weight, price, printSpeed, mode, interfaceType, state);
        this.reloadInk();
    }
    public static final String YELLOW = "\033[0;33m";  // Жовтий

    @Override
    public String print(String document) {
        if(isLowInk()) throw new RuntimeException("Unable to print. Low Ink");
        decreaseInkLevel(document);
        return  YELLOW+document+RESET;
    }

    private double inkLevel;
    @Override
    public String getInkLevel() {
        return inkLevel+"%";
    }

    @Override
    public boolean isLowInk() {
        return inkLevel<30;
    }

    @Override
    public void decreaseInkLevel(String doc) {
        int SymbCount = doc.length();
        double oneSymbInk=0.8;
        double inkSpend = SymbCount*oneSymbInk;
        inkLevel-=inkSpend;
    }

    @Override
    public void reloadInk() {
        inkLevel=100;
    }
}
