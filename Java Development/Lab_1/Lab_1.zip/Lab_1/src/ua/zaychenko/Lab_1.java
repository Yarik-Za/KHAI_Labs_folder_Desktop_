package ua.zaychenko;

import java.util.Scanner;

public class Lab_1 {
    // Однорядковий коментар
    public static void main (String[] args) {

        /* Багато-
        рядковий
        коментар */

        System.out.println("Hello and welcome!");
        System.out.print("Введіть ціле число: ");

        Scanner scanner = new Scanner(System.in);
        int input_numb = scanner.nextInt();
        scanner.close();

        System.out.println("Результат переведення десяткового чивла в інші системи числення");
        System.out.println("Двійкова: " + Integer.toBinaryString(input_numb));
        System.out.println("Вісімкова: " + Integer.toOctalString(input_numb));
        System.out.println("Десяткова: " + input_numb);
        System.out.println("Шістнадцяткова: " + Integer.toHexString(input_numb));
    }
}