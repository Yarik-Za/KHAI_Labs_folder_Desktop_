package org.example;

import java.util.Random;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        Random random = new Random();
        String line = "alsldmasmdap";
        String[] lines = {line.substring(0, 3), line.substring(3, 6), line.substring(6, 9)};
        for(String elem: lines){
            System.out.println(elem);
            while(true) {
                char newchar=(char)random.nextInt();
                if(elem.contains(""+newchar)){
                    continue;
                }
                elem=elem.replace(elem.charAt(1),newchar);
                break;
            }
            System.out.println(elem);
        }

    }
}