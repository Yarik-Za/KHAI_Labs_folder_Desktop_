package Lab_2;

import Lab_2.Classes.Storages.DriversStorage;
import Lab_2.Classes.Transport.Driver;

public class Main {
    public static void main(String[] args) {

        Interface ui = new Interface();
        ui.Menu();

        //Tests.TestActions();
        //Lab_2.Tests.testInterfaceMethods();

    }
}
