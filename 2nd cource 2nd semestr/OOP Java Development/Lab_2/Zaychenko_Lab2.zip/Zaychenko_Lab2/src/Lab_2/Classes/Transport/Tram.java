package Lab_2.Classes.Transport;
import Lab_2.Classes.Storages.AbstractStorage;

import java.util.Arrays;
import java.util.Objects;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class Tram extends AbstractPublicTransport {
    public Tram(String manufacturer, String number, String route_start, String route_end, int capacity, AbstractStorage storage) {
        super(EnumTransportType.TRAM, "", manufacturer, number, route_start, route_end, capacity);
        assignModel();
        storage.add(this);
    }

    @Override
    public void assignDriver(Driver driver) {
        this.driver=driver;
    }

    @Override
    public void assignModel() {
        int randomNumber = ThreadLocalRandom.current().nextInt(111, 300);

        StringBuilder randomLetters = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 2; i++) {
            char letter = (char) ('a' + random.nextInt(26));
            randomLetters.append(letter);
        }

        String model = "TR-" + randomNumber + randomLetters.toString();

        this.modelType = model;
    }

    // Перевизначення методу equals()
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Tram tram = (Tram) o;
        return Objects.equals(this.type, tram.type) &&
                Objects.equals(this.modelType, tram.modelType) &&
                Objects.equals(this.manufacturer, tram.manufacturer) &&
                Objects.equals(this.number, tram.number) &&
                Arrays.equals(this.route, tram.route) &&
                this.capacity == tram.capacity &&
                Objects.equals(this.driver, tram.driver) &&
                Objects.equals(this.stopped, tram.stopped);
    }

    // Перевизначення методу hashCode()
    @Override
    public int hashCode() {
        return Objects.hash(this.type, this.modelType, this.manufacturer, this.number, Arrays.hashCode(this.route), this.capacity, this.driver, this.stopped);
    }
}

