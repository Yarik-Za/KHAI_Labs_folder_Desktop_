package org.example;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        String[] words={"dollar", "gryvnia"};
        char[] letters=new char[words[0].length()+words[1].length()];
        String result="";
        int j=0;
        for(String word:words){
            for(int i=0, count=0; i<word.length();i++){
                for (int k=0; k<word.length();k++){
                    if(word.charAt(k)==word.charAt(i)&&k!=i)
                        count++;
                }
                if (count>1)
                    word=word.replace(""+word.charAt(i),"");
            }
            for(int i=0; i<word.length(); i++, j++){
                letters[j]=word.charAt(i);
            }
        }
        for(char letter:letters) {
            int count=0;
            for(int i=0; i<letters.length; i++) {
                if (letter==letters[i]){
                    count++;
                }
            }
            if(count==2&&!result.contains(""+letter))
                result+=letter;
        }
        System.out.println(result.trim());
    }
}