package Lab_2.Classes.Transport;
import Lab_2.Classes.Storages.AbstractStorage;

import java.util.Arrays;
import java.util.Objects;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class TrolleyBus extends AbstractPublicTransport {
    public TrolleyBus(String manufacturer, String number, String route_start, String route_end, int capacity, AbstractStorage storage) {
        super(EnumTransportType.TROLLEYBUS, "", manufacturer, number, route_start, route_end, capacity);
        assignModel();
        storage.add(this);
    }

    @Override
    public void assignDriver(Driver driver) {
        setAssignedDriver(driver);
    }

    @Override
    public void assignModel() {
        int randomNumber = ThreadLocalRandom.current().nextInt(500, 900);

        StringBuilder randomLetters = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 2; i++) {
            char letter = (char) ('a' + random.nextInt(26));
            randomLetters.append(letter);
        }

        String model = "TB-" + randomNumber + randomLetters.toString();

        this.modelType = model;
    }

    // Перевизначення методу equals()
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TrolleyBus bus = (TrolleyBus) o;
        return Objects.equals(this.type, bus.type) &&
                Objects.equals(this.modelType, bus.modelType) &&
                Objects.equals(this.manufacturer, bus.manufacturer) &&
                Objects.equals(this.number, bus.number) &&
                Arrays.equals(this.route, bus.route) &&
                this.capacity == bus.capacity &&
                Objects.equals(this.driver, bus.driver) &&
                Objects.equals(this.stopped, bus.stopped);
    }

    // Перевизначення методу hashCode()
    @Override
    public int hashCode() {
        return Objects.hash(this.type, this.modelType, this.manufacturer, this.number, Arrays.hashCode(this.route), this.capacity, this.driver, this.stopped);
    }
}

