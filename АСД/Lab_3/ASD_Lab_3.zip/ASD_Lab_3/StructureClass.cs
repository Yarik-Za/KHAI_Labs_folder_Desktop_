﻿using System;
using System.Collections;

namespace ASD_Lab_3
{
    public class El_Down // елемент підсписку
    {
        public int key;
        public string inf;

        public El_Down(int key, string inf)
        {
            this.key = key;
            this.inf = inf;
        }

        public override string ToString()
        {
            string res = "Значення=" + key.ToString() + "; inf=" + inf + "  ";
            return res;
        }
    }

    public class Down // елемент типу стек <T> - цілий підсписок
    {
        public int L_inf;
        public Stack<El_Down> Down_St;

        public Down(int inf)
        {
            L_inf = inf;
            Down_St = new Stack<El_Down>();
        }

        public void Add_El_to_Down(El_Down El)
        {
            Down_St.Push(El);
        }

        public void Remove_El_Down()
        {
            if (Down_St.Count > 0)
                Down_St.Pop();
            else throw new Exception("Підсписок пустий");
        }

        // Возвращает верхний элемент подсписка без удаления
        public El_Down Peek()
        {
            if (Down_St.Count > 0)
                return Down_St.Peek();
            else throw new Exception("Підсписок пустий");
        }

        // Возвращает количество элементов в подсписке
        public int Count()
        {
            return Down_St.Count;
        }

        // Очищает весь подсписок
        public void Clear()
        {
            Down_St.Clear();
        }

        public override string ToString()
        {
            string res = "\nСписок " + L_inf.ToString() + "\t-->    V V V V V V V V V V V V V V\n";
            foreach (El_Down El in Down_St)
                res += El.ToString();
            return res + '\n';
        }
    }

    public class Up_ArLst // основний список Ерей ліст, який містить в собі стеки <T>
    {
        public ArrayList UP_ArLst;

        public Up_ArLst()
        {
            UP_ArLst = new ArrayList();
        }

        public void Add_Down_to_ArLst(Down El_St)
        {
            UP_ArLst.Add(El_St);
        }

        public void Remove_Down_St(Down El_St)
        {
            if (El_St.Down_St.Count != 0)
                El_St.Down_St.Clear();
            UP_ArLst.Remove(El_St);
        }

        public void Remove_Down_El(int Arr_id)
        {
            if (Arr_id >= 0 && Arr_id < UP_ArLst.Count)
            {
                Down down = UP_ArLst[Arr_id] as Down;
                if (down != null)
                {
                    if (down.Down_St.Count > 0)
                    {
                        down.Remove_El_Down(); // Удаляем элемент из стека
                    }
                    else
                    {
                        throw new Exception("Стек пустий.");
                    }
                }
                else throw new Exception("Елемент з вказаним індексом в основному списку не підписок");
            }
            else throw new Exception("Індекс елемента в основному списку недопустимий");
        }

        public void Remove_UP(int id)
        {
            if (id >= 0 && id < UP_ArLst.Count)
            {
                UP_ArLst.RemoveAt(id);
            }
            else
            {
                throw new Exception("Індекс елемента в основному списку недопустимий.");
            }
        }

        public void Reverse_UP()
        {
            UP_ArLst.Reverse();
        }

        public override string ToString()
        {
            string res = "";
            if (UP_ArLst.Count != 0)
                foreach (object El in UP_ArLst)
                    res += El.ToString();
            return res;
        }
    }
}