package org.example;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        String line="word%wordadasword@word";
        String[] separators={"%","adas","@"};
        for(int i=0; i<separators.length; i++){
            line=line.replaceAll(separators[i], " ");
        }
        System.out.println(line);
    }
}