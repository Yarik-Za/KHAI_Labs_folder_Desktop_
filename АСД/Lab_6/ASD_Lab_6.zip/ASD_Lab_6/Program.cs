﻿using System.Text;

Console.OutputEncoding = Encoding.UTF8;
Console.InputEncoding = Encoding.UTF8;

Console.WriteLine("Для виходу введіть \"-0\"\n");

while (true)
{
    try
    {
        int length = 0;

        Console.Write("Введіть довжину масиву: ");
        string input = Console.ReadLine();

        if (input == "-0") Environment.Exit(0);

        if (int.TryParse(input, out int temp))
            if (input != null && temp >= 2)
                length = temp;
            else throw new Exception("Помилка введення кількості елементів масиву");
        else throw new Exception("Помилка читання з рядка");

        int[] array = GenerateRandomArray(length);

        #region debug
        //int[] array = new int[] { 8,7,6,5,4,3,2,1};
        //int[] array = new int[] { 4, 3, 2, 1 };
        //int[] array = new int[] { 28, 600, 350 };
        //int[] array = new int[] { 32, 12, -5 };
        //int[] array = new int[] { -5, 32, 12 };
        //int[] array = new int[] { 503, 087, 512, 061, 908, 170, 897, 275, 653, 426, 154, 509, 612, 677, 765, 703 };
        #endregion

        // Виведення початкового масиву
        PrintArr("Початковий масив: ", array);

        // Сортування масиву
        MSort(array);

        // Виведення відсортованого масиву
        PrintArr("Відсортований масив: ", array);
        Console.ReadLine();
    }
    catch (Exception ex) { Console.WriteLine(ex.Message); }
}
static int[] GenerateRandomArray(int length)
{
    Random random = new Random();
    int[] array = new int[length];

    for (int i = 0; i < length; i++)
        array[i] = random.Next(-1000, 1000); // Генеруємо випадкові числа в діапазоні (-1000, 1000)

    return array;
}

void PrintArr(string message, int[] array)
{
    Console.WriteLine(message);

    foreach (int el in array)
        Console.Write($"{el} ");
    Console.WriteLine();
}

void MSort(int[] array)
{
    int iteration = 1;

    int N = array.Length;
    int t = (int)Math.Ceiling(Math.Log2(N));
    int p = (int)Math.Pow(2, t - 1); // початкова установка p   M1

    Console.WriteLine($"\nПочаткове встановлення M1: p = {p}");

    do
    {
        Console.WriteLine($"\nІтерація: {iteration}");

        int q = (int)Math.Pow(2, t - 1); // початкова установка q, r, d   M2
        int r = 0;
        int d = p;

        do
        {
            Console.WriteLine($"M2: q = {q}, r = {r}, d = {d}");

            for (int i = 0; i <= N - d - 1; i++) // цикл по i   M3
            {
                Console.WriteLine($"M3: i = {i}");

                if (i + d < N && i < N - d && array[i] > array[i + d] && ((i & p) == r)) // порівняння\обмін елементів масиву   M4
                {
                    Console.WriteLine($"M4: Обмін {array[i]} <-> {array[i + d]}");
                    int temp_swap = array[i];
                    array[i] = array[i + d];
                    array[i + d] = temp_swap;

                    PrintColorArr("Результат перестановки:", array, i, i + d);
                }
                else Console.WriteLine($"M4: Обмін не потрібний {array[i]} < {array[i + d]}");
            }

            if (q != p)
            {
                d = q - p;
                q /= 2;
                r = p;
            }
            else
            {
                Console.WriteLine($"M5: Вихід з циклу, оскільки q == p ({q}={p})");
                break; // вихід з циклу, якщо q=p
            }
        } while (q > 0);// цикл по q   M5

        p /= 2;
        Console.WriteLine($"M6: p = {p}");
        iteration++;
    } while (p > 0);// цикл по p   M6
}

void PrintColorArr(string message, int[] array, int highlightIndex1 = -1, int highlightIndex2 = -1)
{
    Console.WriteLine(message);

    for (int i = 0; i < array.Length; i++)
    {
        if (i == highlightIndex1 || i == highlightIndex2)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write($"{array[i]} ");
            Console.ResetColor();
        }
        else
        {
            Console.Write($"{array[i]} ");
        }
    }
    Console.WriteLine();
}

