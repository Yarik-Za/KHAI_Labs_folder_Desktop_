package Lab_2.Classes.Storages;

import Lab_2.Classes.Transport.Driver;

public class DriversStorage extends AbstractStorage {
    public DriversStorage() {
        super();
    }

    @Override
    public String getFullInformation() {
        //if (super.getCount()==0) throw new RuntimeException("List is empty");
        // Виводимо інформацію про всіх водіїв, які містяться у списку
        String res = "";

        for (Object obj : super.list) {
            Driver temp_drv = (Driver) obj;
            res += temp_drv.getFullInfo() + '\n';
        }
        return res;
    }
}
