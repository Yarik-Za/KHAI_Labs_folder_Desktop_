﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASD_Lab_1
{
    public class KeyValue
    {
        public int Key { get; set; }
        public char Value { get; set; }
    }
}
