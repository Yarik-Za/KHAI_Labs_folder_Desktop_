package org.example;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        String line="apaksfopaspabaasmdaba";
        int count=0;
        for(int i=0; i<line.length(); i++){
            if (i+2<line.length()&&line.charAt(i)=='a'
                    &&line.charAt(i+1)=='b'&&line.charAt(i+2)=='a'){
                count++;
            }
        }
        System.out.println(count);
    }
}