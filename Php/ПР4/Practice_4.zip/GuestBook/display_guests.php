<?php
header("Content-Type: text/html; charset=utf-8");

$guestList = "";
if (file_exists('guests.txt')) {
    $guestRecords = file('guests.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $guestRecords = array_reverse($guestRecords);

    if (!empty($guestRecords)) {
        echo "<ul>";
        foreach ($guestRecords as $record) {
            list($email, $message, $date) = explode('|', $record);
            echo "<li><strong>" . htmlspecialchars($email) . "</strong>: " .
                 htmlspecialchars($message) . " <em>(" . htmlspecialchars($date) . ")</em></li>";
        }
        echo "</ul>";
    } else {
        echo "<p>Записів поки немає.</p>";
    }
} else {
    echo "<p>Файл з гостями ще не створено.</p>";
}
?>
