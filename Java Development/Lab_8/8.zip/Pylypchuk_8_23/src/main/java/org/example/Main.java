package org.example;

import java.io.Console;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        String line="12312124adasd123123";
        int count=0;
        for (int i=0; i<line.length();i++){
            if (Character.isDigit(line.charAt(i))){
                count+=Integer.parseInt(""+ line.charAt(i));
            }
        }
        System.out.println(count);
    }
}