namespace Lab_1_Form
{
    internal static partial class Program
    {

        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new Lab_1());
        }
    }
}