package Lab_3.PrintersTypesClasses;

// Інтерфейс для моніторингу рівня чорнила або тонера
public interface InkLevelMonitor {
    String getInkLevel(); // Метод для отримання рівня чорнила або тонера (у відсотках)

    boolean isLowInk(); // Метод для перевірки, чи є рівень чорнила або тонера низьким

    void decreaseInkLevel(String doc); // Метод для зменшення рівня чорнила на величину inkSpend

    void reloadInk(); // Заправка чорнил
}

