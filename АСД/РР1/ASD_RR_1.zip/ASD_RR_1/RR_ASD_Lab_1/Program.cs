﻿using System;
using System.Collections;
using System.Diagnostics;
using System.Text;

namespace ASD_Lab_1
{
    internal class Program
    {
        static void PressEnter()
        {
            while (true)
            {
                Console.WriteLine("Для продовження натисніть Enter...");
                var key = Console.ReadKey(intercept: true);
                if (key.Key == ConsoleKey.Enter)
                {
                    Console.Clear();
                    break; // Выход из цикла, если нажата клавиша Enter
                }
                else Console.WriteLine("Була натиснута інша клавіша");
                Console.Clear();
            }
        }
        static void Main(string[] args)
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            Console.InputEncoding = System.Text.Encoding.GetEncoding(1251);
            Console.OutputEncoding = System.Text.Encoding.GetEncoding(1251);

            MyQueue list = new MyQueue();

            char choice;
            int key = 0;
            int count_of_el;
            do
            {
                Console.WriteLine("Лінійний двонаправлений список символів");
                Console.WriteLine("\nМеню:");
                Console.WriteLine("1. Додати символ до списку");
                Console.WriteLine("2. Видалити перший символ зі списку");
                Console.WriteLine("3. Знайти найбільший символ у списку");
                Console.WriteLine("4. Переглянути перший символ у списку");
                Console.WriteLine("5. Перевірити, чи список порожній");
                Console.WriteLine("6. Вивести структуру на екран");
                Console.WriteLine("7. Підрахувати кількість елементів у списку");
                Console.WriteLine("8. Тест власної черги");
                Console.WriteLine("9. Тест системних структур черг");
                Console.WriteLine("0. Вийти");
                Console.Write("Введіть номер операції: ");
                choice = Console.ReadKey().KeyChar;
                Console.WriteLine();
                Console.Clear();
                try
                {
                    switch (choice)
                    {
                        #region Lab_1
                        case '1':
                            Console.Write("Введіть символ для додавання: ");
                            char value = Console.ReadKey().KeyChar;
                            KeyValue itemToAdd = new KeyValue { Key = key++, Value = value };
                            list.EnQueue(itemToAdd);
                            Console.WriteLine($"\nЕлемент ({itemToAdd.Key}, {itemToAdd.Value}) додано до списку.");
                            PressEnter();
                            break;

                        case '2':
                            KeyValue removedItem = list.DeQueue();
                            Console.WriteLine($"Видалено: ({removedItem.Key}, {removedItem.Value})");
                            PressEnter();
                            break;

                        case '3':
                            if (!list.IsEmpty())
                            {
                                KeyValue maxItem = list.FindMax();
                                Console.WriteLine($"Найбільший елемент: ({maxItem.Key}, {maxItem.Value})");
                            }
                            else Console.WriteLine("Список порожній.");

                            PressEnter();
                            break;

                        case '4':
                            if (!list.IsEmpty())
                            {
                                KeyValue firstItem = list.Peek();
                                Console.WriteLine($"Перший елемент: ({firstItem.Key}, {firstItem.Value})");
                            }
                            else Console.WriteLine("Список порожній.");
                            PressEnter();
                            break;

                        case '5':
                            bool isEmpty = list.IsEmpty();
                            Console.WriteLine("Список порожній: " + isEmpty);
                            PressEnter();
                            break;

                        case '6':
                            Console.WriteLine("Список: ");
                            Console.WriteLine(list.ToString());
                            PressEnter();
                            break;

                        case '7':
                            int itemCount = list.Count();
                            Console.WriteLine($"Кількість елементів у списку: {itemCount}");
                            PressEnter();
                            break;
                        #endregion

                        #region TimeTests_RR
                        case '8':
                            count_of_el = BigNumInp();

                            MyQueue myQueue = new MyQueue();
                            TimeTests.PerformMyQueueOperations(myQueue, count_of_el);

                            PressEnter();
                            break;

                        case '9':
                            count_of_el = BigNumInp();

                            Queue<KeyValue> genericQueue = new Queue<KeyValue>();
                            TimeTests.PerformSQueueOperations(genericQueue, count_of_el);

                            Queue nonGenericQueue = new Queue();
                            TimeTests.PerformSQueueOperations(nonGenericQueue, count_of_el);

                            PressEnter();
                            break;

                        #endregion

                        case '0':
                            break;

                        default:
                            Console.WriteLine("Неправильний вибір. Спробуйте ще раз.");
                            break;
                    }
                }
                catch (InvalidOperationException ex)
                {
                    Console.WriteLine("Помилка: " + ex.Message);
                }

            } while (choice != '0');
        }

        public static int BigNumInp()
        {
            Console.WriteLine("Введіть кількість елементів більше 10 000");
            while (true)
            {
                if (int.TryParse(Console.ReadLine(), out int temp_inp))
                {
                    if (temp_inp >= 10000)
                        return temp_inp;
                    else { Console.Clear(); Console.WriteLine("Помилка, введіть ще раз"); }
                }
            }
        }
    }
}