package org.example;

import java.util.Arrays;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        String[] we = {"0", "123", "45", "678"};
        String then =we[0]+ we[1]+ we[2] + we[3];
        System.out.println(then.equals("012345678"));
        }
    }