﻿namespace ASD_Lab_4
{
    public class ElTree
    {
        public ElTree L, R; //покажчик на піддерева
        public string inf;
        public ElTree(string inf)
        {
            this.inf = inf;
            this.L = null;  // Початково обидва піддерева пусті
            this.R = null;
        }
    }

    public class Tree
    {
        public ElTree T;
        public Tree(string inf)
        {
            T = new ElTree(inf);
        }

        public ElTree Find(ElTree V, string inf) //пошук вузла з інформацією
        {
            if (V != null)
            {
                if (V.inf == inf) return V;
                ElTree temp = Find(V.L, inf);
                if (temp != null)
                    return temp;
                return temp = Find(V.R, inf);
            }
            return null;
        }

        //public ElTree Find(ElTree current, string target)
        //{
        //    if (current == null) return null;

        //    if (current.inf == target) return current;

        //    ElTree leftResult = Find(current.L, target);
        //    if (leftResult != null)
        //        return leftResult;

        //    ElTree rightResult = Find(current.R, target);
        //    if (rightResult != null)
        //        return rightResult;

        //    return null;
        //}

        public ElTree Find_Father(ElTree V, string inf)//пошук предка вузла з інформацією 
        {
            if (V != null)
            {
                if ((V.L != null) && (V.L.inf == inf)) return V;
                if ((V.R != null) && (V.R.inf == inf)) return V;
                //return Find_Father(V.L, inf);
                ElTree temp = Find_Father(V.L, inf);
                if (temp != null)
                    return temp;

                return Find_Father(V.R, inf);
                //return temp = Find(V.R, inf);
            }
            return null;
        }
        public bool Add(ElTree V, string inf, char S)//додавання вузла з інформацією вліво/вправо s=L/R.
        {
            ElTree temp = new ElTree(inf);
            switch (S)
            {
                case 'L':
                    if (V.L == null)
                    {
                        V.L = temp;
                        return true;
                    }
                    else return false;
                case 'R':
                    if (V.R == null)
                    {
                        V.R = temp;
                        return true;
                    }
                    else return false;
            }
            return false;
        }
        public bool Remove(ref ElTree V, string inf)//видалення вузла з інформацією
        {
            ElTree father;
            ElTree temp = Find(V, inf);//шукаємо вузол
            if (temp == null) return false; //вузла не існує
            father = Find_Father(V, inf); //шукаємо предка
            if (father == null)
            {
                //видаляємо корінь
                V = null;
                return true;
            }
            if ((father.L != null) && (father.L.inf == inf))
            {
                //видаляємо лівого потомка
                father.L = null;
                return true;
            }
            //видаляємо правого потомка
            father.R = null;
            return true;
        }
        public void TreeInString(ElTree V, ref string s)
        {
            if (V == null)
                return;

            Stack<ElTree> stack = new Stack<ElTree>();
            stack.Push(V);

            Stack<string> outputStack = new Stack<string>(); // Для збереження виводу у зворотньому порядку

            while (stack.Count > 0)
            {
                ElTree current = stack.Pop();
                outputStack.Push(current.inf); // Додаємо поточний вузол до стеку виводу

                if (current.L != null)
                    stack.Push(current.L);
                if (current.R != null)
                    stack.Push(current.R);
            }

            // Виводимо вміст стеку у зворотньому порядку до рядка
            while (outputStack.Count > 0)
                s += outputStack.Pop()+" ";
        }
        public bool TreeExists()
        {
            return T != null;
        }

    }
}
