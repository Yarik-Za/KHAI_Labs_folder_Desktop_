package org.example;
// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        String line="kabcsfasdabc1kmalksmabc34";
        String patternString = "abc(?=\\d)";
        line=line.replaceAll(patternString, (""+line.charAt(line.indexOf(patternString)+3)));
        System.out.println(line);
    }
}